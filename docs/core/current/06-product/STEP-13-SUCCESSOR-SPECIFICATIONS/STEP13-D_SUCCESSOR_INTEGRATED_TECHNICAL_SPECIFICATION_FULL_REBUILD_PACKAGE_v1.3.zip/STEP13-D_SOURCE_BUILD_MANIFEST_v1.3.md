# STEP13-D SOURCE BUILD MANIFEST v1.3

## Current uploaded source boundary
- STEP13-D_SUCCESSOR_INTEGRATED_TECHNICAL_SPECIFICATION_FULL_REBUILD_PACKAGE_v1.1.zip
- pre-00 gate(20260907-023531).zip
- step12 sync core(1).zip
- step13 sync core.zip
- Step11 Sync core(10).zip
- STEP SYNC CORE(20260907-030419).zip
- Utama core RUMAHAGEN_WIREFRAME_CORE_FINAL_SOURCE_PACK_v1.3(9)_GOVERNANCE_CORRECTED_STEP0_RESIDUAL_FIXED(20260907-030418).zip

## Output
- STEP13-D_SUCCESSOR_INTEGRATED_TECHNICAL_SPECIFICATION_FULL_v1.3.md
- SHA256: 01ec2d14cd8d2f97dc94b537e412d8e6bb8db87eabec7855d74cbe0e95045118

## Scan
- Recursive archive/member instances: 1,822
- Nested ZIPs: 104
- Leaf members: 1,718
- Text-readable members: 1,484
- Decoded text: ~74,282,630 chars
- Errors: 0

## Build rule
Full rebuild only. No patch/append semantics. Core v1.3 is immutable/frozen.
