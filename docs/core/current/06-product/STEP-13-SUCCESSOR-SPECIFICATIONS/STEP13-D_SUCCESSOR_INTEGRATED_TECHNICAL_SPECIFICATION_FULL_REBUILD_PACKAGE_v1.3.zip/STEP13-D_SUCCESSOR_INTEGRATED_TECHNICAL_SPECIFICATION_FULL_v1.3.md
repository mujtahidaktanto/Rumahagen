# RUMAHAGEN — SUCCESSOR INTEGRATED TECHNICAL SPECIFICATION
## STEP13-D — Successor Integrated Technical Implementation Contract

**Version:** 1.3 — STEP13-D CORRECTED FULL REBUILD
**Date:** 7 September 2026
**Status:** **SUCCESSOR INTEGRATED TECHNICAL SPECIFICATION — FULL REBUILD v1.3 / CORRECTED / CONTROLLED RESIDUALS**
**Predecessor:** W4-02A.6.19 Technical Specification v2.1 + STEP13-A v3.7 + STEP13-B v2.3 + STEP13-C v1.1
**Document type:** **FULL CONSOLIDATED MASTER — NOT PATCH / NOT ADDENDUM / NOT MAEP-ONLY**  
**Implementation authorization:** **NOT GRANTED by this document**  
**Production authorization:** **NOT GRANTED**  
**Runtime claim:** This document records the latest evidence state; it does not convert Development/runtime evidence into production authorization.

> This document is the single current technical implementation contract for the W4-02A.6 synchronized RumahAgen baseline. It preserves the unaffected legacy M01–M13 technical behavior and incorporates the governed Commercial/Payment, Learning Economy, Learning Session, Organization, Authorization, Title/Awarding, SEO/Analytics and cross-domain changes. It also reconciles the current TECH execution chain without silently promoting candidate SQL, Development-only corrections, or historical runtime evidence into the canonical production baseline.

---

# 0. EXECUTION / AUTHORITY RULES

1. Approved Owner Decision / MADCR / ADR is the highest authority.
2. Master BR-001–BR-151 remains normative for business behavior; MBR-COM-001–013 is CLOSED — OWNER APPROVED where relevant.
3. W4-02A.6.11 PRD v2.1 is the current product requirement authority.
4. W4-02A.6.12 User Flow v2.1 is the current journey/state authority.
5. Entity Mapping v2.0 remains the conceptual entity authority.
6. W4-02A.6.13 ERD v2.1 is the relationship authority.
7. W4-02A.6.14 Database Dictionary v2.2 is the logical-to-physical meaning authority.
8. W4-02A.6.15 Database Schema v2.7 is the current physical schema reference layer.
9. W4-02A.6.16 API v2.1 is the current interaction/API contract authority.
10. W4-02A.6.17 RBAC/Permission/RLS v2.1 is the current authorization contract authority.
11. W4-02A.6.18 Functional Specification v2.1 is the current functional implementation contract.
12. SEO/Analytics v2.0 remains the M11 public-discovery/measurement authority.
13. W4-02A.6.5 System Architecture v1.8 is the current architecture authority.
14. W4-02A.6.6 Technical Decisions v1.6 is the current technology-consequence authority.
15. W4-01E remains frozen physical design authority and W4-02 remains the sole executable physical baseline.
14. TECH-01…TECH-29A are technical evidence and execution-gate sources.
15. Historical artifacts remain provenance and do not override later closure.
16. A technical implementation detail may not create a new semantic authority.
17. Cross-domain mutation must use an owning-domain contract.
18. Client-side claims are never authoritative.
19. Production execution requires a separate authorization gate.
20. Development runtime evidence does not equal canonical repository state.
21. Static SQL review does not equal runtime verification.
22. GitHub synchronization does not equal staging/runtime verification.
23. No technical artifact may reopen an approved MADCR/ADR without new evidence.
24. No new TECH number may be invented merely to continue an existing gate.
25. The technical specification must describe both affected and unaffected product areas.
26. Exact values intentionally left configurable by BR/product policy are not silently hard-coded here.
27. Candidate SQL and migration files are implementation candidates until the applicable execution gate explicitly promotes them.
28. Historical migration files are not rewritten to make later corrections appear historical.

---



# STEP13-D INTEGRATION CONTROL — SUCCESSOR REBUILD

## D-00 Authority and source boundary
This artifact is a **new Successor Integrated Technical Specification**. Core v1.3 remains immutable/frozen reference; it is not edited in place. Valid technical detail is inherited from the frozen Core and current technical baseline, then reconciled with the current M01–M15 semantic authority and STEP13-A/B/C.

Current technical authority chain used for this rebuild:

`M01–M15 current semantic authority → Core v1.3 valid technical detail → STEP09 Architecture/Dependencies → STEP10 Data/ERD/Dictionary/Schema → STEP11 API → STEP12 Authorization → STEP13-A PRD v3.7 → STEP13-B Functional v2.3 → STEP13-C User Flow v1.1 → STEP13-D`

No outside source was used for this rebuild.

## D-01 Inheritance classification

| Classification | STEP13-D treatment |
|---|---|
| PRESERVE | Valid unaffected technical behavior from Core/technical v2.1 is retained. |
| AUGMENT | Valid new M01–M15 / STEP13-A/B/C detail is added without deleting valid predecessor behavior. |
| UPDATE-RECONCILE | Technical behavior is reconciled where current semantic decisions changed or clarified the contract. |
| ADD-NEW | New capability technical representation is introduced only where supported by current source evidence. |
| SUPERSEDED | Used only where later governing material explicitly replaces an earlier semantic/technical rule. |

`Update ≠ replacement`; `Synchronization ≠ deletion`. Historical wording remains provenance unless a later governing decision explicitly supersedes it.

## D-02 Semantic / technical / physical / runtime separation
The technical contract may define implementation behavior, interfaces, data meaning, authorization enforcement concepts, state transitions, error/idempotency/retry behavior, and implementation constraints. It does **not** claim that a physical migration, deployed endpoint, production authorization, RLS runtime, or production runtime test has been executed unless the supplied corpus explicitly proves that state.

Missing physical/runtime proof is therefore a **controlled downstream verification residual**, not a semantic rejection criterion.

## D-03 Cross-domain authority enforcement
The technical implementation follows the established authority model:

- M01 owns identity/authentication/activation.
- M02 owns profile/public visibility/reviews/outcome presentation.
- M03 owns Listing lifecycle and Refresh action enforcement.
- M04 owns Learning/Learning Economy/Learning Session.
- M05 owns Event/Registration.
- M06 owns Developer/Project/Media/Marketing Kit/Claim.
- M07 owns DBR.
- M08 owns dashboard/notification projection.
- M09 owns administration/configuration/content and administrative audit/export.
- M10 owns authorization/RBAC/RLS.
- M11 owns public discovery/SEO/measurement.
- M12 owns Organization/Membership/Context.
- M13 owns Provider Catalogue/BYOK.
- M14 owns commercial/payment/entitlement/quota/promotion and configurable commercial Refresh allowance.
- M15 owns Qualification/Evidence/Award/Title.

Cross-domain mutation must invoke the owning-domain contract; technical implementation cannot create a parallel semantic authority.

## D-04 STEP13-A/B/C technical propagation

### M01
Conditional KTP/deferred verification is represented as an eligibility/requirement flow, not as a new RBAC permission. Successful OTP activation remains `ACCOUNT=ACTIVE → HOME`. Verification Document role-scope/private handling remains within M01; no public exposure is inferred.

### M02
Review AUTO-APPROVE remains `Published/Viewable` without converting moderation into a pre-publication approval gate. Public CTA is explicit opt-in; Superadmin override remains administrative. Visibility states remain distinct from authorization.

### M03
Listing lifecycle remains M03-owned. Ordinary update is owner-only. After first successful Publish, Address, Property Type, Land Size, and Building Size are publish-locked. Suspended is distinct from ordinary expiry/closure. Sold/Rented Listings are excluded from public search where governed.

Refresh technical behavior: default configured allowance 5 successful Refreshes/Agent/operational day; no carry-forward; maximum one successful Refresh per Listing/day; failed Refresh consumes no allowance; successful Refresh updates authoritative timestamp/state and audit provenance; repositioning remains District-local. Boundary: M14 owns commercial allowance, M03 owns action enforcement, M10 owns authorization. Asia/Jakarta operational day remains the governing operational-day interpretation.

### M04
Learning Economy remains M04-owned. Learning activity completion is the reward boundary; LP earning/redemption and assessment remain M04 semantics. Learning Session taxonomy remains `BROADCAST / INTERACTIVE / ON_DEMAND`; provider switching is explicit/manual and no automatic failover is invented. M15 consumes M04-owned learning evidence rather than redefining Learning.

### M05
Guest registration remains supported. Guest email is a notification/contact destination, not canonical identity. Event-start notifications and session/event links are only used where an actual link is available; no link is fabricated.

### M06
Developer includes company logo and free-text “Tentang Developer”. Project Media semantic boundary is photo/video. Developer Project is compatible as a source for Listing M03 semantics without transferring Listing action authority. Marketing Kit permissions remain Developer own CRUD; Admin/Superadmin All; Manager/Agent View+Download; Buyer/Partner none. Claim approval may initialize an Agent-owned Listing but does not itself grant ordinary M03 Create/Update/Publish/Refresh authority.

### M07
DBR remains M07-owned. Bank Master physical realization remains evidence-gated; no new physical table is invented solely to close a documentation gap.

### M08
Dashboard, notification, and analytics surfaces remain projections/communication surfaces and do not acquire business mutation authority.

### M09
M09 remains administration/configuration/content authority without becoming a super-domain business authority. Administrative Review/Escalate/Manual Correction remain distinct. Superadmin-only administrative export/audit behavior is preserved where governed.

### M10
Authorization resolution remains: `Authenticated Account → Role/actor grouping → baseline Role Permission → optional Permission Preset targeted to that existing Role → scope/ownership/domain conditions → effective authorization`. Permission Preset cannot become a new Role, create capabilities outside the target Role baseline, or bypass ownership/organization/domain constraints. RLS is an enforcement layer; runtime RLS is not claimed verified.

### M11
M11 discovery/measurement covers the ten mandatory public surfaces: Homepage, Listing, Agent, Organization, Developer/Project, Event, Learning, Learning Session, Static Public Content, Announcement/Promotion. Lifecycle/configuration of Static Public Content and Announcement/Promotion remains with M09 or the applicable authoritative domain. Canonical URL/discovery controls remain M11-owned.

### M12
Organization context is distinct from Personal Context. Invitation lifecycle and Join Request lifecycle are preserved. Membership does not itself create ownership, entitlement, Host, Instructor, or management authority. Lead Exit follows `CLOSING → CLOSED`; no successor/Lead Transfer privilege inheritance is invented. Listing transfer/closure follows M03 ownership rules.

### M13
Provider connection lifecycle remains governed, including CREATE → UNVERIFIED → VALID/ACTIVE and DISABLED/INVALID/ERROR/REVOKED/DISCONNECTED/DELETED outcomes as applicable. Temporary provider outage does not automatically transfer ownership or revoke authorization. Provider retirement may system-disconnect the connection where governed. BYOK ownership remains Agent/User own-scope.

### M14
Commercial technical lifecycle remains `Product/Offer → Order/Checkout → Pending Payment → Processing → Confirmed/Failed/Expired/Cancelled → Fulfillment → Entitlement → Quota/Benefit`, with reconciliation and refund/chargeback handling. Purchase snapshot is immutable. `confirmed_at` is set only after trusted verification. Provider callback/webhook evidence does not itself equal confirmation. M14 owns commercial Refresh allowance; M03 enforces the action. Q01–Q64 remain M14 and are not reassigned to M15.

### M15
M15 owns Qualification/Evidence/Award/Title. Developer Learning evidence path is `M04 Learning-owned evidence → M15 Qualification Evidence → Qualification/Award/Title`, without redefining M04 Learning. M15 does not absorb M14 Q01–Q64.

## D-04A M01–M15 technical completeness reconciliation

The following technical obligations are explicitly carried into the successor contract. This section closes a prior completeness gap where some current module changes were named in D-04 but were not represented with sufficient technical contract detail.

| Module | Technical scope carried into STEP13-D | Treatment |
|---|---|---|
| M01 | OTP activation; Conditional KTP/deferred verification; Verification Document private/non-public handling; secure legal-document path; no KTP-derived RBAC permission | UPDATE-RECONCILE / AUGMENT |
| M02 | Profile public/private representation; Review AUTO-APPROVE publication behavior; post-publication moderation; explicit CTA opt-in; Superadmin administrative override; visibility ≠ authorization | UPDATE-RECONCILE / AUGMENT |
| M03 | Listing lifecycle; publish locks; Suspended/Sold/Rented state distinction; owner-only ordinary update; Refresh allowance consumption/enforcement; District-local repositioning; Asia/Jakarta operational day; no regional quota; audit provenance | UPDATE-RECONCILE / AUGMENT |
| M04 | Learning Economy completion/reward boundary; LP ledger/redemption; assessment; Learning Session taxonomy; explicit provider switching; no automatic failover; M04 evidence consumed by M15 | UPDATE-RECONCILE / AUGMENT |
| M05 | Guest registration; guest email as contact/notification destination; Event/Registration ≠ Session Enrollment; event-start notification/link behavior | UPDATE-RECONCILE / AUGMENT |
| M06 | Developer company_logo and “Tentang Developer”; Project semantic source compatibility with M03; Project Media photo/video; Marketing Kit actor/scope matrix; approved Claim → Agent-owned Listing initialization dependency without granting M03 CRUD/publish/refresh authority | UPDATE-RECONCILE / AUGMENT |
| M07 | DBR ownership; bank-master configuration; maximum-four displayed-bank rule; fixed 10pp interpretation; physical Bank Master representation remains evidence-gated | PRESERVE / CONTROLLED |
| M08 | Dashboard/notification/analytics as projection and communication only; no business mutation authority | PRESERVE |
| M09 | System configuration; administrative audit/export; Review/Escalate/Manual Correction separation; no super-domain business authority | UPDATE-RECONCILE |
| M10 | Role/Role Permission baseline; optional Permission Preset targeted to existing Role; preset cannot create new capabilities/Role; scope/ownership/domain checks; RLS as enforcement layer only | UPDATE-RECONCILE / AUGMENT |
| M11 | Ten mandatory public discovery surfaces; canonical URL/discovery controls; lifecycle/configuration delegated to M09/applicable authority; measurement remains non-authoritative | UPDATE-RECONCILE / AUGMENT |
| M12 | Personal vs Organization Context; Invitation/Join Request lifecycle; membership ≠ ownership/entitlement/Host/Instructor; Lead Exit/CLOSING/CLOSED; listing transfer/closure resolution; no successor privilege inheritance | UPDATE-RECONCILE / AUGMENT |
| M13 | Provider Catalogue mutation authority; BYOK own-scope; connection lifecycle; retirement/system disconnect; temporary outage preserves ownership/authorization; explicit provider reachability behavior | UPDATE-RECONCILE |
| M14 | Product/Offer; Order/Checkout; immutable purchase snapshot; payment evidence/trusted verification; confirmed_at; idempotent fulfillment; Entitlement; Capacity→Pool→Allocation→Usage; Promotion; Refund/Chargeback; Reconciliation; configurable Refresh Allowance; Q01–Q64 remain M14 | UPDATE-RECONCILE / ADD-NEW |
| M15 | Qualification Evidence; Rule Version; Award issuance/history; Developer Learning evidence originates in M04 and is consumed by M15; qualification ≠ authorization; M14 Q01–Q64 excluded | UPDATE-RECONCILE / AUGMENT |

### D-04A.1 Cross-module technical authority invariants

- M14 commercial Refresh allowance is an entitlement/configuration input to M03; M03 owns Refresh action/eligibility/consumption; M10 owns authorization. M14 does not receive a Refresh permission merely because it owns the allowance.
- M04 owns Learning and Learning Economy. M15 consumes M04-owned evidence for qualification/awarding and does not redefine Learning activity, LP, or Session semantics.
- M06 Project compatibility with Listing does not transfer Listing action authority from M03.
- M12 Organization context and membership do not create commercial quota, ownership, Host, Instructor, or successor privilege.
- M11 discovery/measurement does not mutate business state; public content lifecycle remains with M09 or the applicable authoritative domain.
- M08 is projection/communication only.

### D-04A.2 Physical/runtime evidence boundary

Physical schema, migration, deployed endpoint, RLS execution, webhook execution, provider reachability, and production authorization remain evidence-gated. Their absence may create a controlled implementation/verification residual, but cannot invalidate an already-resolved semantic or technical contract unless the source explicitly establishes a semantic conflict.

## D-05 API reconciliation contract
Existing exact API capability inventory is preserved. New endpoint identifiers are not fabricated. Where current semantic requirements require a capability but the supplied current API inventory does not establish an exact endpoint identifier, the capability remains a **controlled API residual** pending implementation evidence. Request/response semantics, state transitions, errors, idempotency, retry and ownership must follow the domain authority. Current M14 commercial capabilities such as order/checkout, entitlement, quota, reconciliation, and payment webhook are preserved when exact current identifiers are evidenced in the source corpus; no new identifier is invented for Refresh merely because M14 owns its commercial allowance.

Known controlled examples from the current corpus include Refresh and administration/configuration capability gaps; these are tracked rather than invented.

## D-06 Data reconciliation contract
Technical data behavior follows current ERD/dictionary/schema meaning while preserving the distinction between logical data contract and physical implementation. Ownership, lifecycle, relationship direction, immutable purchase snapshot, audit/provenance and state/history are retained where governed. Physical table names, migrations, SQL execution, or production schema state are not inferred when evidence is absent.

## D-07 Authorization / RLS reconciliation
The technical layer consumes the STEP12 authorization contract. It does not create new roles or permissions merely to satisfy a technical implementation gap. RLS mappings may be described conceptually where the authorization contract supports them; runtime verification remains evidence-gated.

## D-08 State / error / idempotency / retry
For mutation and callback flows, technical behavior must prevent duplicate successful effects, preserve authoritative state transitions, and reconcile asynchronous evidence. Retries must be safe according to the domain contract. Failed operations do not consume business allowance unless the governing semantic rule explicitly says so. Payment callbacks are evidence; confirmation requires trusted verification. Refund/chargeback outcomes are reconciled rather than treated as ordinary successful fulfillment.

## D-09 Traceability

`PRD → Functional → User Flow → API → Data → Authorization → Technical Behavior`

The traceability objective is coverage and consistency, not invention. A requirement with no proven physical implementation is retained with a controlled technical/physical/runtime status.

## D-10 Controlled residual register

| ID | Residual | Layer | Status | Treatment |
|---|---|---|---|---|
| D-R01 | Exact endpoint identifiers for any newly required capability not proven in current API inventory | API | CONTROLLED | Do not invent endpoint IDs; carry as implementation/API residual. |
| D-R02 | Physical Bank Master realization | Data/Physical | CONTROLLED | Preserve semantic Bank Master use; no table invention. |
| D-R03 | Final RLS runtime evidence | Runtime | CONTROLLED | Not verified; cannot block semantic integration. |
| D-R04 | Production authorization/runtime execution evidence | Runtime | CONTROLLED | Separate execution/authorization gate required. |
| D-R05 | Provider-specific OAuth/webhook/deployment bindings | Physical/Runtime | CONTROLLED | Define contract; require implementation evidence downstream. |
| D-R06 | Permission seed/migration execution | Physical/Runtime | CONTROLLED | Authorization contract remains valid; execution proof downstream. |
| D-R07 | Historical OPEN/physical/runtime wording in predecessor artifacts | Provenance | CONTROLLED | Preserve as history; later closure governs current status. |

## D-10A STEP12 / PRE-00 CONTROLLED TECHNICAL RESIDUAL CARRY-FORWARD

The current STEP12-H and PRE-00 evidence identifies controlled API/physical/runtime residuals that are technically relevant to STEP13-D. These are carried forward explicitly rather than collapsed into a generic residual.

| ID | Technical residual | Authority / source boundary | STEP13-D disposition |
|---|---|---|---|
| D-R08 | M03 Refresh canonical endpoint `POST /listings/{id}/refresh` is an established current API contract; canonical endpoint inventory reconciliation remains traceable to API-237. | M03 action authority + STEP11 API evidence | **ACCOUNTED / PRESERVE**; do not invent a replacement endpoint. |
| D-R09 | M09 System Configuration exact current API contract `GET/PUT /admin/config/system` is registered as API-238/API-239 in current STEP11 evidence, while earlier canonical tables combined it. | M09 administrative authority + STEP11/STEP12 reconciliation | **ACCOUNTED / UPDATE-RECONCILE**; preserve M09 authority and the separate current API records where evidenced. |
| D-R10 | M04 Skill Verify / Issue / Manage capabilities are semantically locked but exact current route identifiers are not evidenced. | M04 authority + STEP11/STEP12 controlled API evidence | **CONTROLLED API RESIDUAL**; preserve capability, do not fabricate route IDs. |
| D-R11 | M04 Learning Economy Redemption is semantically locked but exact current route identifier is not evidenced. | M04 authority + STEP11/STEP12 controlled API evidence | **CONTROLLED API RESIDUAL**; preserve LP redemption semantics, defer exact route. |
| D-R12 | Other exact M04 LearningPath Configure / Progression Manage / Credential Issue-Manage / Learning Reconciliation routes remain evidence-gated where not proven. | M04 + STEP11/STEP12 | **CONTROLLED API RESIDUAL**; no invented endpoints. |
| D-R13 | M10 Permission Preset semantic model is current, but `permission_presets`, `permission_preset_items`, and `user_permission_presets` are not established in the current W4-02 physical baseline. | M10 authority + STEP12-H | **CONTROLLED FUTURE PHYSICAL DELTA**; preserve target-role containment, assignment and no-role-change invariants. |
| D-R14 | M10 exact Permission Preset endpoint/storage identifiers remain controlled where not evidenced. | M10 + STEP12-B/H | **CONTROLLED**; no invented IDs/tables/routes. |
| D-R15 | STEP12-H records additional exact-route/physical associations across M01/M04/M05/M06/M09/M10/M11/M12/M13/M14/M15 as downstream evidence-state residuals. | Current STEP12-H handoff | **CONTROLLED DOWNSTREAM**; semantic capabilities remain integrated. |
| D-R16 | Runtime authorization/RLS correctness is not established by the supplied corpus. | STEP12-H | **NOT VERIFIED / NON-BLOCKING**; no runtime PASS claim. |
| D-R17 | Current physical RLS evidence contains RLS-enabled surfaces without complete explicit policy-row evidence. | STEP12-H | **CONTROLLED READINESS**; no semantic authorization contradiction inferred. |
| D-R18 | Provider-specific OAuth/webhook/deployment bindings and M13 force-revoke/force-disconnect/force-disable exact route details remain implementation-evidence gated. | M13 + STEP11/STEP12 | **CONTROLLED**; preserve provider lifecycle/authority semantics. |
| D-R19 | M12 Invitation Revoke, Join Request Cancel, closure-confirm-OTP, Organization Settings and related exact route details remain evidence-gated where not proven. | M12 + STEP11/STEP12 | **CONTROLLED**; preserve M12 lifecycle/authority semantics. |

These rows do not create new business rules. They make the current upstream technical/API residual state explicit so that STEP13-D does not accidentally mark an unresolved exact technical association as absent, deleted, or invented.

## D-10A.1 M05 PARTICIPANT-MODE TECHNICAL PROPAGATION

M05 Event/Registration technical behavior explicitly carries the accepted `participant_mode` semantic. `participant_mode` is preserved as a participant/registration contract field where supported by the accepted upstream Functional and User Flow baselines.

The technical contract does not reinterpret `participant_mode` as:
- canonical identity;
- RBAC role;
- Session Enrollment;
- ownership;
- or a new authorization capability.

Guest registration remains a supported registration path. Guest email remains a notification/contact destination rather than canonical identity. Event/Registration remains distinct from Learning Session Enrollment.

Exact physical column/table realization for `participant_mode` is not invented where the current physical evidence does not establish it; any such physical mapping remains evidence-gated.

## D-10B CORE v1.3 TECHNICAL SCOPE COVERAGE CONTROL

The Core v1.3 technical baseline remains the inheritance source. The STEP13-D contract must preserve valid technical detail unless current authoritative evidence explicitly supersedes it. The supplied current corpus was checked for silent loss of the predecessor technical sections and for STEP13-D deltas affecting them.

**Result:** no valid Core v1.3 technical section was identified as semantically deleted by STEP13-D. However, current STEP11/STEP12 technical/API reconciliation items above are now explicitly carried into the successor contract as controlled or accounted residuals.

## D-11 Acceptance rule
STEP13-D is accepted only if no unresolved semantic conflict, authority inversion, unsupported semantic decision, or unresolved semantic dependency remains in the successor technical contract. Physical/runtime proof gaps may remain only as controlled residuals. No fabricated endpoint ID, permission ID, table, SQL/RLS policy, migration execution, deployment state, concurrency guarantee, or runtime proof may be asserted.


# 1. CURRENT DECISION / OPEN-STATE GATE

## 1.1 Owner-level decision state

**Current unresolved Owner-level MADCR / OD required for Step 3.11: 0.**

The current Wave 3 chain already records the governing decisions:

| Decision | Current state | Technical consequence |
|---|---|---|
| Agency = Organization | CLOSED / GOVERNING | One Organization authority/context; no parallel Agency authority. |
| MADCR-010 | APPROVED / GOVERNING | Commercial Entitlement owns commercial access/quota capacity. |
| MADCR-011 | APPROVED / GOVERNING | Payment belongs to M14 Commercial. |
| MADCR-002 | APPROVED / GOVERNING | Provider-independent Payment Core + Provider Adapter. |
| MADCR-003 | APPROVED / GOVERNING | Verified payment + idempotent fulfillment. |
| MADCR-005 | APPROVED / GOVERNING | Reconciliation is first-class. |
| MADCR-036 | APPROVED / GOVERNING | Title Definition ≠ Award Instance. |
| MADCR-049 | APPROVED / GOVERNING — Option A | Learning Activity is completion/reward boundary. |
| MADCR-053 | APPROVED / GOVERNING | Authorization = Capability + Permission + Scope. |
| MADCR-054 | APPROVED / GOVERNING | Host and Instructor are separate capabilities. |
| OPEN-C01 / MADCR-012 | CLOSED / GOVERNING | Commercial architecture remains complementary with explicit authority boundaries. |
| AEP3-OD-01 | CLOSED — Option B | Stable Title Identity; no Title Identity Version entity. |
| AEP3-OD-02 | CLOSED | One authority source at a time. |
| AEP3-OD-03 | CLOSED / GOVERNING | Existing audit/history is reused. |
| AEP3-OD-04 | CLOSED | Version/history without mandatory parent Rule Version lineage. |
| AEP3-OD-05 | CLOSED | Qualification selects applicable Rule Version; Award snapshots it. |
| AEP4-OD-08 | CLOSED / GOVERNING | No automatic Learning Session provider failover; manual/admin switching. |
| AEP4-OD-16 | APPROVED | Session enrollment/access has semantic lifecycle. |
| AEP4-OD-17 | APPROVED | Session Enrollment = PENDING → ACTIVE → COMPLETED. |
| TECH-27 / TECH-28 | CLOSED / FROZEN | Existing Instructor role receives Session learning permission family; Host remains resource capability. |
| MADCR-058 | CLOSED / GOVERNING | Midtrans is MVP payment provider behind Provider Adapter. |
| MBR-COM-001–013 | OWNER APPROVED / CLOSED | Commercial BR baseline is normative. |

The current Technical Decisions artifact explicitly states that it is a synchronized technical-consequence baseline, not a new technology-selection exercise, and that older OPEN classifications are not current authority.

## 1.2 All remaining “OPEN” wording

The corpus still contains OPEN/DEFERRED wording in historical System Architecture, Technical Decisions, TECH-19, TECH-25, TECH-28 and older governance documents.

These have been classified into three groups:

### A. Closed by later governing decision
Examples:

- AEP3-OD-03;
- AEP4-OD-08;
- MADCR-058;
- MBR-COM-001–013;
- Instructor mapping;
- Session physical relationship direction.

These are **not reopened**.

### B. Controlled technical residual
Examples:

- exact provider OAuth/webhook implementation;
- exact attendance configuration;
- recording retention implementation;
- final RLS runtime evidence;
- final permission seed execution;
- production provider binding;
- migration promotion;
- application runtime discovery.

These are downstream execution/evidence gates, not unanswered Owner decisions.

### C. Historical checkpoint
Examples:

- TECH-29 v1.1 “Supabase provisioned/empty” state;
- TECH-22 original Option A decision;
- earlier TECH-19 permission evidence gap;
- older AEP4 failover wording.

These remain provenance.

---

# 2. SOURCE-CORPUS RECONCILIATION

## 2.1 Immediate W4-02A.6 chain

```text
Owner Decision / MADCR / ADR
        ↓
Master BR / Commercial BR
        ↓
6.11 PRD v2.1
        ↓
6.12 User Flow v2.1
        ↓
6.13 ERD v2.1
        ↓
6.14 Database Dictionary v2.2
        ↓
6.15 Database Schema v2.7
        ↓
6.16 API v2.1
        ↓
6.17 RBAC / Permission / RLS v2.1
        ↓
6.18 Functional Specification v2.1
        ↓
THIS 6.19 TECHNICAL SPECIFICATION v2.1
        ↓
6.20 UI / UX Specification
```

The current Entity Mapping is explicitly a full conceptual registrar and not an implementation authorization.

The current User Flow explicitly preserves exact physical API payloads, permission IDs, RLS SQL, migration execution and provider runtime evidence as downstream technical concerns unless already frozen.

## 2.2 Technical source chain

The technical baseline was reconciled against:

- current Project Constitution;
- current Dependency Manifest;
- current System Architecture v1.7;
- current Technical Decisions v1.6;
- legacy Technical Specification v1.0;
- legacy Development Blueprint;
- current Database Dictionary;
- current API;
- current RBAC/RLS;
- TECH-01 through TECH-29A;
- AEP1–AEP4;
- MAEP / Cross-AEP;
- Master BR;
- Owner Decision Freeze;
- post-Wave-1 Decision Closure;
- GitHub repository;
- uploaded Wave 3 partial package.

The repository exposes a dedicated `08-technical-spec/Technical-Specification-RUMAHAGEN-v1.0-FINAL.md` plus current governance, architecture, database, API, security, UX and technical-sync directories.

---

# 3. CURRENT TECHNICAL STATUS — IMPORTANT RECONCILIATION

There are two TECH-29-era states in the corpus.

## 3.1 Historical TECH-29 checkpoint

TECH-29 v1.1 states:

```text
Supabase project       PROVISIONED / EMPTY
Staging environment    NOT YET ESTABLISHED
Runtime verification   BLOCKED — ENVIRONMENT
Production             NOT AUTHORIZED
```

It also explicitly says no new architecture decision exists at that checkpoint.

This remains valid **as historical checkpoint evidence**.

## 3.2 Later TECH-29A state

The later TECH-29A reconciliation states:

```text
TECH-28
  ↓ PASS
TECH-29
  ↓
TECH-29A
  ├─ A-01 Environment & Access Readiness PASS
  ├─ A-02 Candidate Freeze PASS
  ├─ A-03 Controlled Execution Plan PASS
  ├─ A-03 execution/evidence COMPLETED
  │
  ├─ Canonical reconciliation of 4 corrections HOLD
  │
  └─ Application Runtime Discovery CURRENT BLOCKER
       ↓
    Auth Smoke Test PENDING
       ↓
    RBAC Test PENDING
       ↓
    Domain Runtime Test PENDING
```

The same artifact records four Development execution corrections that have not yet been promoted to `main`.

Therefore the current technical specification adopts:

> **Development technical evidence exists and has progressed beyond the historical empty-environment checkpoint, but the four runtime corrections remain under canonical reconciliation and the application runtime entry point remains unverified.**

This is the current technical state.

---

## 3.3 W4-02A.6 current downstream reconciliation

The W4-02A.6.10–6.18 chain is now the direct current downstream contract set consumed by this artifact:

- Business Rules v1.2 establishes the normative BR traceability baseline.
- PRD v2.1 establishes current product requirements.
- User Flow v2.1 establishes current cross-domain journey/state behavior.
- ERD v2.1 establishes current logical relationships.
- Database Dictionary v2.2 establishes current logical-to-physical meaning.
- Database Schema v2.7 reconciles the 86-table current physical reference to W4-01E and W4-02.
- API v2.1 establishes the current API resource/interaction contract.
- RBAC/Permission/RLS v2.1 establishes current Capability + Permission + Scope semantics and the RLS boundary.
- Functional Specification v2.1 establishes the current functional implementation contract.

The Technical Specification therefore describes **how the current approved functional/contractual behavior is technically realized within the existing integrated RumahAgen platform**. It must not invent an alternate domain model, API vocabulary, permission taxonomy, physical schema, provider authority or runtime state.

The current 86-table physical reference is a reference layer. W4-01E remains frozen physical design authority and W4-02 remains the sole executable SQL baseline. W4-02A.6.19 does not authorize migration execution or silently modify W4-02.

# 4. CORE TECHNOLOGY STACK

The current Technical Decisions v1.6 explicitly preserves the existing technology stack without introducing a new core service.

| Layer | Canonical technology | Technical rule |
|---|---|---|
| Frontend | Next.js App Router | Server-first rendering; Client Components only where browser interaction requires. |
| Language | TypeScript | Strict type safety and shared contracts. |
| UI | shadcn/ui | Reusable accessible components. |
| CSS | Tailwind CSS | Utility-based design system. |
| Backend/API | Next.js Route Handlers / thin BFF | No separate Node.js backend service. |
| Database | PostgreSQL / Supabase | Primary relational authority. |
| Authentication | Supabase Auth | Authentication abstraction. |
| Authorization | Application RBAC + Supabase RLS | Two-layer enforcement. |
| Storage | Supabase Storage | Controlled private/public buckets. |
| Hosting | Vercel | Serverless/edge hosting. |
| Repository | GitHub | Source/provenance repository. |
| Search | PostgreSQL FTS + `pg_trgm` | MVP search engine. |
| Scheduler | Vercel Cron + Postgres Trigger / Database Webhook | Native-first job strategy. |
| Rate limiting | Supabase Postgres `rate_limit_log` | Phase 1; no Redis dependency. |
| Maps rendering | Leaflet + OpenStreetMap | Client-side map rendering. |
| Maps geocoding | LocationIQ primary + Geoapify approved alternative | Server-side abstraction. |
| AI | Curated BYOK providers | Backend-proxied, secret-isolated. |
| Testing | Vitest + React Testing Library + Playwright | Unit/component/E2E coverage. |

No new backend runtime, database engine, queue vendor, cache vendor or payment provider is introduced by Step 3.11.

The current architecture confirms all 28 ADRs are Approved or Approved With Notes and that no architecture ADR remains OPEN.

---

## 4.1 Current technology-decision propagation

The current Technical Decisions v1.6 confirms:

- the existing Next.js/TypeScript/Supabase/Vercel architecture remains the core stack;
- no new independent backend service is introduced;
- provider-independent integration boundaries remain mandatory where approved;
- Midtrans is the selected MVP payment implementation provider behind the Provider Adapter, not a Payment Core authority;
- Learning Session providers remain behind provider-neutral boundaries and no automatic provider failover is required;
- authorization remains Capability + Permission + Scope with RLS as an enforcement layer;
- Commercial Entitlement remains distinct from RBAC;
- Learning Activity remains the completion/reward boundary;
- Title Definition remains distinct from Award Instance;
- no new Rule Lineage Engine, Temporal Rule Engine, Awarding service, or separate tenancy platform is introduced.

These are technology consequences of governing decisions, not new semantic decisions.

# 5. APPLICATION ARCHITECTURE

## 5.1 Logical topology

```text
Browser
  │
  ├── Public SSR/SSG
  │
  └── Authenticated App Router
          │
          ↓
     Next.js Route Handlers / Thin BFF
          │
     ┌────┼──────────────────────────────┐
     ↓    ↓              ↓               ↓
 Supabase Auth      Domain Services   External Adapters
     │                  │               │
     │                  ├─ Commercial   ├─ Payment Provider
     │                  ├─ Learning     ├─ Session Provider
     │                  ├─ Listing      ├─ Maps Provider
     │                  ├─ Org          └─ AI Provider
     │                  ├─ Awarding
     │                  └─ Authorization
     ↓
 PostgreSQL
     │
     ├─ RLS
     ├─ DB constraints
     ├─ indexes
     ├─ triggers
     ├─ audit/history
     └─ scheduled/async support
```

## 5.2 Thin BFF rule

The BFF/Route Handler layer:

- authenticates;
- validates input;
- resolves permission/scope;
- invokes domain logic;
- invokes adapters;
- returns canonical result;
- never becomes a second business authority.

## 5.3 No cross-domain direct mutation

Incorrect:

```text
Session → directly UPDATE LP
Payment → directly UPDATE Award
UI → directly UPDATE entitlement
```

Correct:

```text
Session
  ↓
canonical completion
  ↓
Learning Activity
  ↓
Learning Economy
```

```text
Payment
  ↓
verified commercial outcome
  ↓
fulfillment
  ↓
Entitlement / LP grant
```

```text
Qualification
  ↓
Awarding authority
  ↓
Award Instance
```

---

# 6. FRONTEND TECHNICAL STRUCTURE

Canonical App Router organization:

```text
app/
├── (auth)/
│   ├── login/
│   ├── register/
│   ├── verify-otp/
│   ├── forgot-password/
│   └── reset-password/
│
├── (public)/
│   ├── listings/
│   ├── agents/
│   ├── developers/
│   ├── learning/
│   └── events/
│
├── dashboard/
├── listings/
├── learning/
├── sessions/
├── organization/
├── commercial/
├── awards/
├── tools/
│   ├── dbr/
│   └── ai/
│
├── admin/
│
└── api/
    ├── auth/
    ├── listings/
    ├── learning/
    ├── sessions/
    ├── organizations/
    ├── commercial/
    ├── awards/
    ├── search/
    ├── maps/
    └── cron/
```

This structure preserves the legacy modules while adding governed Wave 3 surfaces.

## 6.1 Server vs Client Components

Default:

```text
Server Component
```

Use Client Component only for:

- interactive forms;
- maps;
- drag/drop media;
- charts;
- live session controls;
- rich editor;
- client-only provider SDK interaction where required.

Maps must be client-only because Leaflet requires browser DOM. The project blueprint explicitly prohibits putting LocationIQ/Geoapify secrets in client code.

---

# 7. FRONTEND DATA / STATE MANAGEMENT

## 7.1 Server state

Authoritative domain state is fetched from server/API.

## 7.2 Client state

Use client state only for:

- form draft;
- UI filters;
- modal/drawer;
- temporary wizard state;
- optimistic cosmetic changes;
- transient AI chat content.

## 7.3 No authoritative optimistic state

Never optimistically display:

- Payment Confirmed;
- Listing Published;
- LP Granted;
- Award Issued;
- Session Completed;
- Attendance Passed;
- Entitlement Fulfilled.

until server authority confirms.

---

# 8. API / BFF TECHNICAL CONTRACT

## 8.1 Request pipeline

```text
HTTP Request
   ↓
route validation
   ↓
authentication
   ↓
permission
   ↓
scope
   ↓
Organization authority if applicable
   ↓
resource capability if applicable
   ↓
business-rule validation
   ↓
idempotency where required
   ↓
domain service
   ↓
transaction / external adapter
   ↓
audit/provenance
   ↓
canonical response
```

The current RBAC baseline uses the same authorization ordering and treats provider ingress separately through authentication, normalization, idempotency and canonical evidence persistence.

## 8.2 API versioning

Current Wave 3 API contract is v2.0.

No endpoint should be duplicated merely because an AEP added a new field.

Prefer:

```text
existing endpoint + evolved response/request
```

where semantics remain compatible.

Introduce a new endpoint only when a new resource/action boundary exists.

## 8.3 Pagination

All list endpoints:

```text
limit
cursor/page
sort
filter
```

No unrestricted full-table response.

## 8.4 Idempotency

Required for retry-sensitive mutations including:

- payment confirmation/fulfillment;
- LP grant;
- commercial fulfillment;
- session provider evidence;
- assignment mutation where applicable;
- webhook/event ingestion.

---

# 9. DATABASE TECHNICAL BASELINE

## 9.1 PostgreSQL conventions

Reuse:

```text
UUID primary keys
TIMESTAMPTZ timestamps
created_at
updated_at
deleted_at where lifecycle requires
explicit foreign keys
named indexes
CHECK constraints
UNIQUE constraints
RLS
```

The source corpus describes UUID + `gen_random_uuid()`, TIMESTAMPTZ, explicit FK policy, named indexes and RLS as technical conventions; STEP13-D does not independently promote these to runtime verification.

## 9.2 Database authority

PostgreSQL is the canonical persistence authority.

Application code must not duplicate constraints that should also exist in the database.

## 9.3 Transaction boundary

Use database transaction for:

```text
validate
→ mutate related authoritative rows
→ write audit/provenance
```

where atomicity is required.

External provider calls must not be held inside long-running database transactions.

---

# 10. LEGACY M01–M13 TECHNICAL PRESERVATION

## M01 — Authentication

Technical requirements:

- Supabase Auth;
- email/password;
- OTP;
- Google OAuth;
- refresh/session handling;
- logout;
- forgot/reset password;
- verification workflow;
- secure legal document upload.

Google OAuth `id_token` must be verified server-side; raw client token is never trusted. Secrets remain server-side.

Apple SSO is not active MVP functionality.

## M02 — Agent Profile

Preserve:

- profile CRUD;
- public/private representation;
- review moderation;
- sensitive-field approval;
- aggregate statistics;
- badge/achievement projection.

## M03 — Listing

Preserve:

- Primary/Secondary;
- Sell/Rent;
- location hierarchy;
- media;
- legal metadata;
- price history;
- lead event;
- WhatsApp CTA;
- duplicate-photo detection;
- moderation;
- Personal/Organization context.

Listing ownership remains Agent-owned.

## M04 — Learning

Preserve:

- Course;
- Lesson;
- Quiz;
- Quiz Question;
- Quiz Option;
- Enrollment;
- Attempt;
- Certificate.

Add synchronized:

- Learning Path;
- Learning Activity;
- Learning Activity Completion;
- LP transaction;
- Learning Session.

## M05 — Event

Preserve:

- Event;
- Event Registration.

Do not repurpose Event Registration for Session Enrollment.

## M06 — Developer

Preserve:

- Developer Partner;
- Developer Project;
- Project Media;
- Agent Project Claim.

No MVP exclusivity.

## M07 — DBR

Preserve:

- DBR simulation;
- Admin-configured bank master;
- maximum four displayed banks;
- fixed 10pp interpretation bands.

## M08 — Dashboard/Notification

Preserve aggregation and notification projections.

## M09 — Admin

Preserve:

- moderation;
- system configuration;
- audit;
- administrative queues.

## M10 — RBAC

Preserve:

- Role;
- Permission;
- RolePermission;
- scope model.

Extend with:

- Session permission family;
- resource-level Session capability assignment.

## M11 — SEO/Analytics

Preserve:

- public SSR/SSG;
- metadata;
- structured data;
- sitemap;
- GA4/GTM/Search Console configuration;
- analytics event collection.

Analytics never becomes business authority.

## M12 — Organization

Preserve:

- Organization;
- Organization Member;
- Invitation;
- Organization-scoped authorization.

Personal Context remains intact.

## M13 — AI BYOK

Preserve:

- curated provider catalogue;
- encrypted API key storage;
- backend proxy;
- transient conversation;
- provider-specific tab/thread behavior;
- rate limiting.

The PRD explicitly requires API keys never to be sent to client-side code and conversation history not to be persisted server-side.

---

# 10A. CURRENT M01–M06 TECHNICAL DELTAS

## 10A.1 M01 Conditional KTP / Verification Document

The verification document is private/non-public and role/scope controlled. The deferred path is:

```text
OTP success
  → ACCOUNT = ACTIVE
  → Verification Document may remain DEFERRED / NOT_PROVIDED
  → HOME
```

`ISI NANTI` is the user-facing deferred branch where governed by the M01 flow. Deferred KTP does not create a default Pending Review state and does not create an RBAC permission.

## 10A.2 M02 visibility / review / CTA

Review AUTO-APPROVE yields `Published/Viewable` without a normal pre-publication review gate. Administrative moderation may occur post-publication. Public CTA behavior is explicit opt-in; Superadmin override is administrative only. Visibility state is never used as a substitute for authorization.

## 10A.3 M03 publish / Refresh technical contract

After first successful Publish, Address, Property Type, Land Size and Building Size are publish-locked. Ordinary update remains owner-only. Suspended is distinct from expiry/closure, and Sold/Rented listings are excluded from public search where governed.

Refresh enforcement uses the M14 allowance contract described in §15.2B while M03 remains action owner and M10 remains authorization owner. Server transaction time is authoritative for the operational-day and one-refresh-per-listing rules.

## 10A.4 M04 / M05 session-event boundary

Learning Session remains M04-owned with `BROADCAST`, `INTERACTIVE`, and `ON_DEMAND` types. Provider switching is explicit/manual; automatic failover is not introduced. Event Registration remains distinct from Session Enrollment, and Guest email is a notification/contact destination rather than canonical identity.

## 10A.5 M06 Developer / Project / Marketing Kit / Claim

Developer technical representation includes `company_logo` and free-text `Tentang Developer`. Project Media is semantically photo/video. Developer Project may provide compatible source data for Listing M03 without acquiring M03 action authority.

Marketing Kit scope remains:

| Actor | Scope |
|---|---|
| Developer | Own CRUD + View |
| Admin / Superadmin | All |
| Manager / Agent | View + Download |
| Buyer / Partner | None |

Approved Claim may initialize an Agent-owned Listing, but Claim approval does not itself grant ordinary M03 Create/Update/Publish/Refresh capability.

# 11. LEARNING ECONOMY TECHNICAL DESIGN

## 11.1 Completion boundary

```text
Learning Activity
      ↓
Completion Validation
      ↓
Learning Activity Completion
      ↓
Reward Evaluation
      ↓
LP Transaction if eligible
```

Course is content/product structure.

Activity is completion/reward boundary.

## 11.2 LP ledger

Use immutable transaction-oriented records.

Conceptual transaction types:

```text
EARNED
PURCHASED
REDEEMED
ADJUSTMENT
REVERSAL
```

The balance is derived/projection state.

Transaction provenance remains authoritative.

## 11.3 Purchased LP

```text
Commercial Order
   ↓
Payment verification
   ↓
Fulfillment
   ↓
Purchased LP grant
   ↓
LP transaction
```

Retry must not duplicate the grant.

## 11.4 LP cannot purchase competency

LP may unlock eligible learning content/path.

LP cannot bypass:

- required assessment;
- qualification;
- Awarding authority.

---

# 12. LEARNING SESSION TECHNICAL DESIGN

## 12.1 Canonical resources

```text
LearningSession
SessionEnrollment
SessionProviderBinding
SessionParticipationEvidence
SessionAttendanceEvaluation
SessionCompletionOutcome
SessionArtifact
LearningSessionAssignment
```

## 12.2 Session semantic types

```text
BROADCAST
INTERACTIVE
ON_DEMAND
```

## 12.3 Session relationships

Current physical decisions:

```text
Session → Organization = 0..1 nullable
Session → Event        = 0..1 nullable
Session → Partner      = no physical MVP relation
PRIVATE audience       = no dedicated audience table MVP
```

These were closed by later TECH-09/TECH-10 evidence and are reflected in the current ERD.

## 12.4 Enrollment

```text
PENDING
  ↓
ACTIVE
  ↓
COMPLETED
```

Learner cannot self-mutate ACTIVE or COMPLETED.

## 12.5 Provider abstraction

```text
LearningSession
      ↓
ProviderBinding
      ↓
ProviderAdapter
      ↓
External Provider
```

Provider Session ID is not the RumahAgen Session ID.

## 12.6 Evidence pipeline

```text
Provider Event
   ↓
Verify provider
   ↓
Normalize
   ↓
Idempotency
   ↓
Persist evidence
   ↓
Attendance Evaluation
   ↓
Completion Evaluation
```

## 12.7 Provider failover

For Learning Session:

```text
NO automatic failover
```

Switching is manual/admin-controlled.

This is the closed AEP4-OD-08 state.

Note: Maps has its own provider abstraction and fallback strategy; that is a separate domain and must not be confused with Learning Session provider failover. The Maps ADR keeps LocationIQ primary with Geoapify as approved alternative.

---

# 13. SESSION ASSIGNMENT / HOST / INSTRUCTOR

## 13.1 Physical candidate

Current frozen candidate:

```text
learning_session_assignments
```

Conceptual fields:

```text
session_id
actor_id
capability
status
created_at
created_by
revoked_at
revoked_by
```

with:

```text
capability ∈ { HOST, INSTRUCTOR }
status     ∈ { ACTIVE, REVOKED }
```

Actor references canonical `users.id`.

TECH-24 confirms this candidate and the actor identity convention.

## 13.2 Integrity

```text
UNIQUE ACTIVE(session_id, actor_id, capability)
```

Same actor may hold:

```text
HOST
+
INSTRUCTOR
```

on one Session.

No maximum Host/Instructor count is invented because no source-backed maximum exists.

## 13.3 Authorization

Assignment is not enough.

Required:

```text
platform permission
+
resource assignment
+
applicable scope
```

Host/Instructor assignment cannot be derived from:

- Organization membership;
- provider credential;
- global role alone.

---

# 14. RBAC / RLS TECHNICAL DESIGN

## 14.1 Authorization order

```text
1. authenticate
2. resolve role
3. resolve permission
4. resolve granted_scope
5. resolve Organization authority
6. resolve resource capability
7. validate state transition
8. execute RLS-protected operation
9. persist audit
10. return canonical result
```

This ordering is already frozen in the current RBAC/RLS baseline.

## 14.2 Role model

Existing roles remain.

No new:

- Host role;
- Session Manager role;
- Issuer role;
- Provider Admin role;
- Organization Admin role.

## 14.3 Instructor

Instructor receives the Session learning permission family according to TECH-28.

Instructor does not automatically receive:

- Host;
- Assign-LearningSession;
- Manage-SessionProvider.

## 14.4 Agent

Agent receives own learner/session paths.

Agent does not receive assignment mutation.

## 14.5 Manager/Admin

Manager/Admin receive the approved Session permission family at their authorized scope.

## 14.6 RLS

RLS is second-layer enforcement.

Application authorization must still execute.

Client-supplied:

```text
actor_id
scope
organization_id
capability
```

is never accepted as authorization proof.

---

# 15. COMMERCIAL / PAYMENT TECHNICAL DESIGN

## 15.1 Commercial boundary

```text
Commercial
├── Product/Offer
├── Order
├── Payment
├── Entitlement
├── Quota
├── Promotion
└── Reconciliation
```

## 15.2 Payment boundary

```text
Payment Core
      ↓
Provider Adapter
      ↓
Midtrans (MVP)
```

The selected provider is implementation detail behind the provider-independent contract.

## 15.2A Commercial state and data invariants

The technical contract preserves the current commercial chain:

```text
Product/Offer
  → Order/Checkout
  → Pending Payment
  → Processing
  → Confirmed / Failed / Expired / Cancelled
  → Fulfillment
  → Entitlement
  → Quota / Benefit
```

Required invariants:

- The purchase snapshot is immutable after the order is created; later catalog changes do not rewrite historical purchase terms.
- `confirmed_at` is authoritative only after trusted payment verification.
- Provider callback/webhook/result is evidence input and is not itself equivalent to confirmation.
- Fulfillment is idempotent and must not create duplicate authoritative commercial outcomes.
- Quota follows the commercial capacity chain `Capacity → Operational Pool → Allocation → Usage`; quota is not an RBAC permission.
- Refund and chargeback remain distinguishable commercial/reconciliation states and do not silently mutate unrelated domain authority.
- Reconciliation compares expected versus observed state and requires governed resolution for mismatches.
- Q01–Q64, including Q40, Q54, Q61 and Q62, remain within M14 scope and are not transferred to M15.

## 15.2B Refresh Allowance technical contract

```text
M14 commercial entitlement/configuration
        ↓
daily_refresh_allowance
        ↓
M03 Refresh eligibility / action / consumption
        ↓
M10 authorization
```

The current governed contract is:

- default allowance: 5 successful Refreshes per Agent per Asia/Jakarta operational day;
- no carry-forward;
- maximum one successful Refresh per Listing per day;
- failed Refresh does not consume allowance;
- successful Refresh consumes one allowance unit and updates authoritative refresh provenance/timestamp;
- allowance may be distributed across eligible Listings by the Agent;
- repositioning is District-local;
- no regional Refresh quota is introduced;
- Organization membership alone does not create Organization Refresh quota;
- Refresh allowance is not a new M14 permission;
- no new public Refresh endpoint is invented solely by this commercial contract.

Physical representation of `daily_refresh_allowance` remains implementation/evidence-gated; the technical contract does not invent a table or migration solely to represent it.

## 15.3 Payment verification

```text
Client
 ↓
Payment initiation
 ↓
Provider
 ↓
Trusted callback/status verification
 ↓
Idempotency
 ↓
Payment confirmed
 ↓
Fulfillment
```

Client return URL alone is not payment confirmation.

## 15.4 Fulfillment

```text
Payment confirmed
   ↓
Commercial fulfillment
   ├─ Entitlement
   ├─ Quota
   ├─ Promotion
   └─ LP grant where applicable
```

Fulfillment is idempotent.

## 15.5 Reconciliation

Reconciliation compares:

```text
Expected
vs
Observed
```

It must not silently mutate business state without governed resolution.

## 15.6 MVP commercial products

Exactly:

1. Listing quota add-ons;
2. Learning Point packages;
3. Free membership;
4. Pro monthly;
5. Pro annual;
6. Paid listing boost/premium promotion;
7. Paid internal RumahAgen Learning classes;
8. Paid partner Learning classes.

No additional monetization mechanism is introduced.

---

# 15A. M11–M13 CURRENT TECHNICAL DELTAS

## 15A.1 M11 public discovery surface contract

M11 covers exactly ten mandatory public surfaces: Homepage, Listing, Agent, Organization, Developer/Project, Event, Learning, Learning Session, Static Public Content, and Announcement/Promotion. Canonical URL/discovery/measurement behavior remains M11-owned. Static Public Content and Announcement/Promotion lifecycle/configuration remains with M09 or the applicable authoritative domain.

## 15A.2 M12 organization lifecycle contract

Personal Context and Organization Context remain distinct. Invitation and Join Request have separate lifecycles. Membership alone does not create ownership, entitlement, Host, Instructor, or management authority. Lead Exit/closure follows `CLOSING → CLOSED`; CLOSED is irreversible where governed. No successor/Lead Transfer privilege inheritance is inferred. Organization Listing transfer/forfeiture/ownership resolution follows the applicable M03 ownership contract.

## 15A.3 M13 provider lifecycle contract

Provider Catalogue mutation is Superadmin-only. Agent/User owns its own BYOK/provider connection. Connection lifecycle includes `UNVERIFIED → VALID/ACTIVE` and governed `DISABLED`, `INVALID/ERROR`, `REVOKED/FORCE DISCONNECTED`, and `DISCONNECTED/DELETED` outcomes. Provider retirement may system-disconnect affected connections. Temporary provider outage does not transfer ownership or automatically revoke authorization. Explicit provider switching is required; automatic failover is not introduced.

# 16. TITLE / AWARDING TECHNICAL DESIGN

## 16.1 Boundaries

```text
Title Definition
    ≠
Qualification
    ≠
Award Instance
```

## 16.2 Rule Version

Qualification selects the applicable Rule Version.

Award snapshots the Rule Version used.

No mandatory parent Rule Version lineage is introduced.

## 16.3 Award issuance

```text
Evidence
 ↓
Qualification
 ↓
Awarding authority
 ↓
Award Instance
```

No direct:

```text
Payment → Award
LP → Award
Learning completion → Award
```

without qualification.

## 16.4 History

Reuse existing audit/history.

No separate appeal/history engine.

---

# 17. ORGANIZATION / MULTI-TENANCY TECHNICAL DESIGN

## 17.1 Context model

```text
User
 ├── Personal Context
 └── Organization Context(s)
```

Organization membership does not replace Personal Context.

## 17.2 Organization authority

Organization is a second-layer domain authority.

It is not:

- RBAC;
- entitlement;
- listing ownership;
- Session Host authority.

## 17.3 Listing

A Listing has one active context:

```text
PERSONAL
OR
ORGANIZATION
```

Historical origin remains explainable.

## 17.4 Session

Session may reference one Organization.

Membership does not automatically grant Session capabilities.

## 17.5 RLS

Organization boundary must be enforced through authoritative membership/context checks.

The project has explicitly identified and corrected an `organization_members` RLS recursion issue during Development execution; that correction remains a canonical-reconciliation item and must not be silently promoted into historical migration history.

---

# 18. SEARCH TECHNICAL DESIGN

## 18.1 MVP

```text
PostgreSQL FTS
+
pg_trgm
```

Use for:

- listing title;
- location;
- description;
- relevant project/agent searchable fields.

## 18.2 Threshold migration

Migration to a dedicated search engine is conditional.

Do not introduce Typesense or another search vendor before approved threshold criteria are met.

## 18.3 Query requirements

All search endpoints:

- paginated;
- indexed;
- bounded;
- parameterized;
- protected against injection;
- observable.

---

# 19. MAPS / LOCATION TECHNICAL DESIGN

## 19.1 Rendering

```text
Leaflet
+
OpenStreetMap tiles
```

Client-only rendering.

## 19.2 Geocoding

```text
LocationIQ
   ↓ primary
Geoapify
   ↓ approved alternative
Offline/manual fallback
```

through a `MapsProvider` abstraction.

The Maps ADR explicitly requires the abstraction layer and keeps LocationIQ as Primary.

## 19.3 Cache

Use PostgreSQL `geocode_cache`.

Approximate TTL:

```text
~90 days
```

for stable geocoding results.

## 19.4 Rate limits

Maps rate limiting is independently scoped.

The project source records:

```text
Autocomplete: 20/min/IP
Geocode:      10/min/IP
```

through `api_rate_limits`.

These limits are distinct from general application rate limiting.

## 19.5 Secrets

Never send:

```text
LOCATIONIQ_API_KEY
GEOAPIFY_API_KEY
```

to client-side JavaScript.

---

# 20. CACHING / RATE LIMITING / ASYNC

## 20.1 Application rate limiting

Phase 1:

```text
PostgreSQL rate_limit_log
```

No Redis.

## 20.2 Migration to Redis

Upstash Redis is a conditional Phase 2 migration.

Trigger criteria include:

- sensitive endpoint request volume >10,000/min combined;
- rate-limit queries >15% database load;
- need for generic application cache.

The current architecture explicitly records these thresholds.

## 20.3 Async jobs

Use:

```text
Vercel Cron
+
Postgres Trigger / Database Webhook
```

Examples:

- expiry processing;
- reminders;
- sitemap regeneration;
- denormalized counter synchronization;
- housekeeping.

Do not introduce BullMQ/Redis worker infrastructure for MVP.

## 20.4 Heavy operations

Heavy operations should be asynchronous.

Do not keep a serverless request open for long processing.

---

# 21. STORAGE / MEDIA

## 21.1 Supabase Storage

Use controlled buckets.

Separate:

```text
public media
private legal documents
private provider credentials/artifacts
```

## 21.2 Image pipeline

Use:

```text
client validation/compression
→ Storage
→ transform/resize
→ optimized delivery
```

Next Image and WebP/AVIF are preferred where applicable.

## 21.3 Legal documents

KTP/NPWP/legal files:

- private;
- authorized access only;
- never indexed;
- never included in public analytics;
- never exposed through public URL without controlled authorization.

---

# 22. AI BYOK TECHNICAL DESIGN

## 22.1 Data path

```text
Browser
  ↓
Route Handler
  ↓
retrieve encrypted provider credential
  ↓
provider adapter
  ↓
AI Provider
  ↓
response
  ↓
browser
```

API key never reaches browser.

## 22.2 Persistence

Persist:

```text
provider connection metadata
encrypted API credential
```

Do not persist:

```text
conversation history
```

unless a future explicit product decision changes this.

## 22.3 Disconnect

Disconnect must hard-delete the encrypted API key material according to the current architecture baseline.

## 22.4 Provider catalogue

Admin-curated providers.

No arbitrary client-supplied provider endpoint is allowed.

---

# 23. NOTIFICATION TECHNICAL DESIGN

## 23.1 Event-driven projection

Domain mutation:

```text
business state
 ↓
domain event/status
 ↓
notification
```

Notification is not authority.

## 23.2 Categories

```text
Account
Listing
Learning
Session
Organization
Commercial
Awarding
System
```

## 23.3 Delivery

Use approved notification strategy.

Do not introduce a second notification platform without a new approved architecture decision.

---

# 24. SEO / ANALYTICS TECHNICAL DESIGN

## 24.1 Public SEO

SSR/SSG for:

- Listing;
- Agent;
- Organization;
- Developer/Project;
- appropriate public Learning/Event pages.

## 24.2 Protected surfaces

No public indexing for:

- dashboard;
- admin;
- payment;
- authorization;
- private Learning;
- private Session;
- private Organization;
- sensitive documents.

## 24.3 Analytics

Analytics is observational.

Example:

```text
whatsapp_cta_click
```

does not become:

```text
confirmed_lead
```

Analytics cannot:

- grant LP;
- mark attendance;
- confirm payment;
- publish Listing;
- issue Award.

---

# 25. SECURITY BASELINE

## 25.1 Secrets

Never expose:

- Supabase service role key;
- provider server keys;
- Maps server keys;
- BYOK credentials;
- payment secrets;
- signing secrets.

The development blueprint explicitly prohibits bundling server/service-role secrets into client-side JavaScript.

## 25.2 Authentication

- Supabase Auth;
- secure session handling;
- server-side OAuth token validation;
- protected Route Handlers.

## 25.3 Authorization

Two-layer:

```text
Application Authorization
+
Database RLS
```

## 25.4 Input validation

Validate:

```text
client
+
server
+
database constraints where applicable
```

Never trust client validation alone.

## 25.5 Audit

Audit security-sensitive operations:

- role changes;
- permission changes;
- membership changes;
- assignment changes;
- provider binding;
- payment reconciliation;
- awarding;
- administrative mutations.

Reuse existing audit/history mechanism.

---

# 26. ERROR HANDLING

## 26.1 API errors

Canonical categories:

```text
400 validation
401 authentication
403 authorization
404 resource/non-disclosure aware
409 state/conflict/idempotency
422 semantic validation where applicable
429 rate limit
500 unexpected
502/503 provider dependency
```

## 26.2 Provider errors

Normalize external errors.

Do not expose raw provider secrets or internal payloads.

## 26.3 Retry

Retry only when:

- operation is idempotent;
- error is transient;
- retry policy allows.

Never automatically retry a potentially non-idempotent mutation without idempotency protection.

---

# 27. OBSERVABILITY / LOGGING

## 27.1 Structured logs

Log:

- request correlation ID;
- actor ID where safe;
- route/action;
- result;
- latency;
- error category;
- provider adapter result;
- idempotency key/reference where applicable.

Do not log secrets or full private documents.

## 27.2 Metrics

Monitor:

- API latency;
- error rate;
- database latency;
- RLS denial patterns;
- payment reconciliation exceptions;
- Session provider errors;
- LP grant duplication attempts;
- notification failures;
- rate-limit blocks;
- job failures.

## 27.3 Traceability

Each cross-domain mutation should be reconstructable through:

```text
request
→ domain result
→ audit/provenance
→ downstream event
```

---

# 28. PERFORMANCE BASELINE

Current architecture requires:

- SSR/edge caching for public pages where appropriate;
- pagination;
- database indexes;
- denormalized counters where justified;
- lazy loading;
- image optimization;
- code splitting;
- client-only loading of heavy browser components;
- asynchronous heavy work.

The current System Architecture explicitly defines edge caching, PostgreSQL application rate limiting, geocode caching, image optimization, pagination, index-first design, counter denormalization and serverless execution budgets.

---

# 29. TESTING STRATEGY

## 29.1 Unit

Use Vitest.

Cover:

- business-rule functions;
- state transitions;
- permission resolution;
- scope resolution;
- idempotency;
- normalization;
- adapter contracts;
- calculators;
- validation.

## 29.2 Component

Use React Testing Library.

Cover:

- form behavior;
- state presentation;
- permission-aware UI;
- loading/error/empty states.

## 29.3 E2E

Use Playwright.

Core journeys:

- registration;
- login;
- listing;
- Organization;
- Learning;
- Session;
- Commercial checkout;
- payment state;
- LP;
- awarding;
- DBR;
- AI BYOK;
- Admin moderation.

## 29.4 Database / RLS

Use controlled SQL fixtures.

Never claim RLS PASS from static inspection alone.

## 29.5 Provider adapter contract tests

Mock provider boundary.

Test:

- success;
- timeout;
- invalid signature;
- duplicate webhook;
- malformed payload;
- provider unavailable;
- manual switching.

---

# 30. TECH-29 RUNTIME TEST FAMILIES

When the controlled runtime gate is exercised, the current source defines families A–H:

| Family | Verification |
|---|---|
| A | Permission seed integrity and duplicate prevention |
| B | Session assignment integrity |
| C | Host/Instructor separation |
| D | Assignment mutation authorization |
| E | Visibility/Organization boundary |
| F | Learner lifecycle protection |
| G | Provider operation authorization |
| H | Database-level RLS enforcement |

The current TECH-29 source describes these families and states that runtime PASS would require actual PostgreSQL/Supabase execution; STEP13-D therefore records runtime verification as evidence-gated and not verified here.

---

# 31. CURRENT TECH-29A CONTROLLED CORRECTIONS

The latest TECH-29A reconciliation identifies four Development-only corrections:

1. M01–M03 dependency-order correction.
2. M12 `organization_members` RLS recursion correction.
3. Session assignment mutation RLS candidate.
4. Provider mutation RLS candidate.

Current treatment:

```text
Development evidence
       ↓
Canonical reconciliation
       ↓
Clean-reset verification
       ↓
Candidate promotion decision
```

Do not:

- silently merge;
- rewrite historical migrations;
- claim production;
- claim canonical repository parity.

The current TECH-29A artifact explicitly marks these four corrections as a HOLD for canonical reconciliation.

---

# 32. APPLICATION RUNTIME DISCOVERY

## 32.1 Current blocker

The latest TECH-29A source states that a verified executable RumahAgen frontend was not identified in the recursively inspected corpus/repository.

Missing verified evidence:

- `package.json`;
- Vite/Next configuration;
- frontend source tree;
- TSX/JSX/Vue application source;
- deployment manifest.

Therefore:

> **Application Runtime Discovery is a real evidence blocker, not a new architecture decision.**

## 32.2 Required discovery

The next runtime continuation must identify:

1. frontend source;
2. package manager/build system;
3. Supabase client;
4. environment mapping;
5. deployment URL;
6. Development mapping;
7. absence of production credentials;
8. runnable application;
9. login page.

No new TECH number is created.

---

# 33. TECH-29B NAMING COLLISION

The corpus contains:

```text
TECH-29B-03A
```

for an earlier Regional Reference Data Assessment.

A later runtime handoff uses:

```text
TECH-29B
```

for Auth Smoke Test.

Canonical treatment:

- historical `TECH-29B-03A` remains provenance;
- later runtime handoff meaning is operationally current;
- no new `TECH-29B-*` artifact is created to resolve the collision;
- nomenclature cleanup belongs to controlled technical/document reconciliation.

This is a provenance/naming issue, not an Owner decision.

---

# 34. DEPLOYMENT ARCHITECTURE

## 34.1 Environments

Minimum conceptual separation:

```text
Development
Staging / controlled non-production
Production
```

## 34.2 Development

May contain:

- controlled fixtures;
- runtime technical evidence;
- candidate corrections.

Must not be treated as production.

## 34.3 Staging

Must be:

- non-production;
- disposable/resettable;
- isolated from production traffic;
- populated with controlled fixtures;
- suitable for migration/RLS/runtime testing.

## 34.4 Production

Production authorization remains separate.

No migration is promoted merely because:

- SQL passes static inspection;
- GitHub is synchronized;
- Development tests pass.

---

# 35. MIGRATION TECHNICAL RULES

## 35.1 Migration properties

Migrations must be:

- ordered;
- deterministic;
- reviewable;
- idempotent where safe;
- reversible where feasible;
- provenance-preserving.

## 35.2 Migration order

At high level:

```text
Foundation
  ↓
Identity/Auth
  ↓
RBAC
  ↓
Core domain
  ↓
Organization
  ↓
Learning
  ↓
Session
  ↓
Authorization seed
  ↓
RLS
  ↓
Commercial
  ↓
Awarding
  ↓
Indexes/triggers/supporting structures
```

Exact executable order must come from the canonical migration package, not be invented by this document.

## 35.3 No historical rewrite

If a later correction fixes an earlier migration:

```text
preserve original
+
add controlled corrective migration
```

Do not rewrite historical migration contents.

---

# 36. TECH-13 → TECH-29A HANDOFF

The current technical chain is:

```text
TECH-13
Final Session migration candidate
        ↓
TECH-14
Static/runtime readiness
        ↓
TECH-15-R1
Permission reconciliation
        ↓
TECH-16-R1
Provider capability
        ↓
TECH-17
Session technical residual closure
        ↓
TECH-18
Technical execution authorization consolidation
        ↓
TECH-19-R1
Physical authorization/RLS design
        ↓
TECH-20
Authorization catalogue closure
        ↓
TECH-21
Session permission catalogue
        ↓
TECH-22
Resource-level Session authorization
        ↓
TECH-23
Assignment schema/RLS
        ↓
TECH-24
Assignment migration/RLS candidate
        ↓
TECH-25
Consolidated Session migration candidate
        ↓
TECH-26
Authorization seed reconciliation
        ↓
TECH-27
Final authorization seed gate
        ↓
TECH-28
Authorization seed freeze / RLS mapping
        ↓
TECH-29
Runtime verification checkpoint
        ↓
TECH-29A
Environment / candidate / execution / runtime continuation
```

TECH-22’s original physical-design decision is already closed by later Option A implementation evidence. TECH-24 confirms the candidate structure and `users.id` actor reference.

---

# 37. LEGACY TECHNICAL SPECIFICATION PRESERVATION

The legacy Technical Specification v1.0 remains useful as provenance for:

- architecture overview;
- module technical responsibilities;
- API/backend structure;
- database integration;
- security;
- deployment;
- testing;
- operational constraints.

This Step 3.11 supersedes it as the current technical baseline only after absorbing its unaffected valid content.

No legacy technical capability is removed merely because it was not changed by MAEP.

---

# 38. MODULE TECHNICAL RESPONSIBILITY MATRIX

| Module | Primary technical responsibility |
|---|---|
| M01 | Auth, registration, verification, session security |
| M02 | Agent profile, reviews, public/private data |
| M03 | Listing CRUD, search, media, lead telemetry |
| M04 | Learning content, Activity, LP, Session |
| M05 | Calendar/Event/Registration |
| M06 | Developer/Project/Claim |
| M07 | DBR calculations/configuration |
| M08 | Dashboard/notification projections |
| M09 | Admin/configuration/audit |
| M10 | RBAC/Permission/Scope/RLS |
| M11 | SEO/Analytics |
| M12 | Organization/membership/context |
| M13 | AI BYOK/provider adapters |
| M14 | Commercial/Payment/Entitlement/Quota |
| M15 | Title/Qualification/Awarding |

Learning Session remains an extension of M04, not a new top-level M16.

---

# 39. CROSS-DOMAIN TECHNICAL CONTRACTS

## 39.1 Listing ↔ Commercial

```text
Listing operation
→ entitlement/quota evaluation
→ allow/deny
```

Commercial owns quota capacity.

## 39.2 Commercial ↔ Payment

```text
Order
→ Payment
→ Verification
→ Fulfillment
```

## 39.3 Payment ↔ Entitlement

Only confirmed payment may trigger commercial fulfillment.

## 39.4 Learning ↔ LP

Learning Activity completion may create LP if reward policy says so.

## 39.5 Session ↔ Learning

Session completion may produce Learning Activity evidence.

## 39.6 Learning ↔ Awarding

Qualification determines Award eligibility.

## 39.7 Organization ↔ Authorization

Organization provides domain context.

RBAC/Permission/Security determines authorization.

## 39.8 Session ↔ Provider

Provider adapter isolates vendor-specific implementation.

---

# 40. DATA CONSISTENCY / IDEMPOTENCY

## 40.1 Idempotent external ingress

Use provider event identity/reference.

Repeated provider event:

```text
same canonical result
```

not:

```text
duplicate business outcome
```

## 40.2 Commercial

Repeated callback cannot duplicate:

- Payment;
- Entitlement;
- Quota;
- LP grant.

## 40.3 Session

Repeated participation evidence cannot duplicate:

- attendance;
- completion;
- downstream Learning Activity completion.

## 40.4 Assignment

Repeated assignment request must respect active uniqueness.

---

# 41. BACKGROUND PROCESSING

Current approved scheduler:

```text
Vercel Cron
+
Postgres Trigger / Database Webhook
```

Candidate workloads:

- listing expiration;
- notification reminders;
- counter synchronization;
- sitemap regeneration;
- rate-limit cleanup;
- other explicitly scheduled housekeeping.

Do not add a long-running worker service for MVP.

---

# 42. CONFIGURATION MANAGEMENT

Configurable values must be stored centrally where BR/product says they are configurable.

Examples:

- listing expiry duration;
- commercial pricing;
- promotional duration;
- LP earning values;
- learning unlock configuration;
- DBR bank master;
- notification configuration;
- provider operational configuration.

Configuration changes:

```text
new configuration
+
effective time
```

must not rewrite historical outcomes.

---

# 43. API SECURITY / RATE LIMITS

Sensitive endpoints include:

- login;
- registration;
- OTP;
- password reset;
- public form submissions;
- AI provider calls;
- maps APIs;
- payment initiation/callback handling;
- provider webhooks.

Rate limits are scoped by domain and endpoint.

Maps limits remain independent from general rate limiting.

---

# 44. THIRD-PARTY ADAPTER PATTERN

Every vendor-specific integration should expose an internal contract.

Examples:

```text
PaymentProviderAdapter
SessionProviderAdapter
MapsProvider
AIProviderAdapter
```

Internal domain code must not depend directly on vendor-specific SDK semantics.

Benefits:

- provider replacement;
- testing;
- controlled configuration;
- vendor isolation;
- historical continuity.

For Learning Session specifically, provider switching is manual/admin-controlled and not automatic failover.

---

# 45. ACCESS CONTROL / DATA DISCLOSURE

Authorization denial must not leak protected resource existence.

Where applicable:

```text
404 / generic denial
```

may be preferable to:

```text
403 with sensitive resource details
```

depending on the protection boundary.

RLS must enforce the same boundary independently of application claims.

---

# 46. AUDIT / PROVENANCE TECHNICAL CONTRACT

Audit must support reconstruction of:

- actor;
- action;
- target;
- previous state where applicable;
- new state;
- timestamp;
- request/reference ID;
- source/domain;
- relevant rule/configuration reference.

Reuse existing audit/history.

No separate appeal-history subsystem is created.

---

# 47. HISTORICAL RULE / CONFIGURATION SNAPSHOTS

For domains where historical reconstruction matters:

```text
current configuration
      ≠
historical outcome
```

Commercial order stores commercial snapshot.

Award stores Rule Version used.

DBR result stores calculation context/threshold used.

Session evidence retains provenance.

LP transaction retains source/reference.

---

# 48. TEST FIXTURE STRATEGY

Fixtures must be deterministic.

Minimum role personas:

```text
Superadmin
Manager
Admin
Agent
Instructor
Host-capable actor
Buyer
Developer Partner where needed
```

Minimum Organization scenarios:

```text
Personal only
Active member
Inactive member
Cross-Organization actor
```

Minimum Session scenarios:

```text
Instructor only
Host only
Dual capability
No assignment
Revoked assignment
```

No fixture is created merely because an old document mentions a tester role; fixture creation must be traceable to a current test requirement.

---

# 49. RUNTIME NEGATIVE TESTING

Mandatory negative cases include:

- Agent reads another Agent's private resource → DENY;
- inactive Organization member accesses Organization-scoped resource → DENY;
- Instructor without Host assignment manages provider → DENY;
- Host without Instructor assignment performs Instructor-only action → DENY;
- role alone creates Session assignment → DENY;
- provider credential alone proves authorization → DENY;
- client-supplied scope bypass → DENY;
- learner self-sets ACTIVE → DENY;
- learner self-sets COMPLETED → DENY;
- successful payment without trusted confirmation → no fulfillment;
- sufficient LP without qualification → no Award;
- Learning completion without configured reward → no LP;
- analytics event → no authoritative mutation.

---

# 50. PRODUCTION READINESS GATE

Production readiness requires all of:

```text
Canonical documentation
        ↓
Canonical migration package
        ↓
Canonical authorization seed
        ↓
Canonical RLS
        ↓
Clean development verification
        ↓
Controlled staging
        ↓
Runtime test families
        ↓
Evidence reconciliation
        ↓
Application runtime verification
        ↓
Security review
        ↓
Backup/rollback readiness
        ↓
Production authorization
```

No single artifact can substitute for the full gate.

---

# 51. CURRENT CONTROLLED RESIDUAL REGISTER

| Residual | Current classification | Resolution path | Owner decision? |
|---|---|---|---|
| Four Development corrections | CANONICAL RECONCILIATION HOLD | Reconcile + clean-reset rerun | No |
| Application runtime entry point | EVIDENCE BLOCKER | Continue TECH-29A runtime discovery | No |
| Exact provider OAuth/webhook contracts | IMPLEMENTATION RESIDUAL | Provider implementation gate | No |
| Attendance numeric thresholds | CONFIGURATION RESIDUAL | BR/configuration | No |
| Recording retention/privacy/replay | IMPLEMENTATION/POLICY RESIDUAL | Media/privacy implementation | No |
| Final runtime RLS behavior | EXECUTION GATE | Controlled PostgreSQL runtime | No |
| Final permission seed execution | EXECUTION GATE | Controlled seed gate | No |
| Production provider binding | OPERATIONS GATE | Production activation authorization | No |
| Commercial physical schema | DOWNSTREAM IMPLEMENTATION | Controlled migration gate | No |
| Learning Activity physical API/schema | DOWNSTREAM IMPLEMENTATION | Learning Activity technical gate | No |
| TECH-29B naming collision | PROVENANCE/NAMING | Document reconciliation | No |

None of these is an unanswered MADCR/OD.

---

# 52. OPEN-STATE SANITY CHECK

## 52.1 MADCR

```text
Current Owner-level MADCR unresolved: 0
```

## 52.2 OD

```text
Current Owner-level OD unresolved: 0
```

## 52.3 ADR

The current System Architecture records:

```text
28 / 28 ADR
Approved / Approved With Notes
OPEN = 0
```

## 52.4 Technical gates

Technical execution still has controlled residuals.

These are not silently labeled “complete”.

Current critical state:

```text
Design baseline                 PASS
Authorization design            PASS
Session assignment design       PASS
Development evidence            EXISTS
Canonical correction sync       HOLD
Application runtime discovery   BLOCKED
Production authorization        NOT AUTHORIZED
```

This distinction is intentional.

---

# 53. TRACEABILITY MATRIX

| Upstream authority | Technical propagation |
|---|---|
| Project Constitution | governance/architecture constraints |
| System Architecture v1.7 | topology, stack, deployment |
| Technical Decisions v1.6 | technology consequences |
| PRD v2.1 | product technical requirements |
| User Flow v2.1 | state/interaction behavior |
| Entity Mapping v2.0 | entity technical boundaries |
| ERD v2.1 | relationships |
| DB Dictionary v2.1 | physical data contract |
| API v2.1 | HTTP/domain contract |
| RBAC/RLS v2.1 | authorization |
| SEO/Analytics v2.0 | public/index/telemetry |
| Functional v2.1 | functional constraints |
| UI/UX v2.0 | presentation constraints |
| AEP1 | Commercial/Payment |
| AEP2 | Learning Economy |
| AEP3 | Title/Awarding |
| AEP4 | Learning Session |
| MADCR-010 | Entitlement |
| MADCR-011 | Payment placement |
| MADCR-002 | Payment Adapter |
| MADCR-003 | verification/idempotency |
| MADCR-005 | reconciliation |
| MADCR-036 | Award boundary |
| MADCR-049 | Learning Activity |
| MADCR-053 | authorization taxonomy |
| MADCR-054 | Host/Instructor |
| AEP3-OD-02 | authority source |
| AEP3-OD-03 | audit/history |
| AEP3-OD-04 | version/history |
| AEP3-OD-05 | Rule Version snapshot |
| AEP4-OD-08 | Session provider switching |
| TECH-20 | authorization catalogue |
| TECH-21 | Session permissions |
| TECH-22 | resource-level capability |
| TECH-23 | assignment structure |
| TECH-24 | assignment migration/RLS |
| TECH-25 | consolidated Session candidate |
| TECH-26 | authorization seed |
| TECH-27 | Instructor mapping |
| TECH-28 | frozen authorization design |
| TECH-29 | runtime verification boundary |
| TECH-29A | current runtime continuation |

---

# 54. LEGACY + WAVE 3 TECHNICAL COVERAGE CHECKLIST

## Foundation
- [x] Architecture
- [x] Authentication
- [x] Authorization
- [x] Database
- [x] API
- [x] Storage
- [x] Deployment
- [x] State management
- [x] Error handling
- [x] Logging
- [x] Monitoring
- [x] Testing
- [x] Security
- [x] Caching
- [x] File upload
- [x] Notification
- [x] Search
- [x] Maps
- [x] Multi-tenancy
- [x] Type safety

## Product modules
- [x] M01
- [x] M02
- [x] M03
- [x] M04
- [x] M05
- [x] M06
- [x] M07
- [x] M08
- [x] M09
- [x] M10
- [x] M11
- [x] M12
- [x] M13
- [x] M14
- [x] M15

## AEP propagation
- [x] AEP1
- [x] AEP2
- [x] AEP3
- [x] AEP4
- [x] Cross-AEP / MAEP
- [x] Master BR

## Technical execution
- [x] TECH-01…TECH-28 lineage consumed
- [x] TECH-29 historical checkpoint reconciled
- [x] TECH-29A current continuation reconciled
- [x] Four Development corrections registered
- [x] Application runtime blocker registered
- [x] TECH-29B naming collision registered
- [x] No new TECH number invented

---

# 55. HISTORICAL WAVE 3 STEP 3.11 GATE

The predecessor Wave 3 Step 3.11 gate is retained as historical/provenance. Its GREEN status established the predecessor technical baseline; it does not override this W4-02A.6.19 current contract.

# 56. HISTORICAL WAVE 3 CHECKPOINT

The predecessor W3-01 through W3-11 checkpoint remains historical lineage. W4-02A.6.10–6.18 are the current synchronized downstream chain.

# 57. CURRENT W4-02A.6 TECHNICAL CHAIN

```text
Owner Decision / BR / approved MADCR-ADR-OD
        ↓
6.10 Business Rules
        ↓
6.11 PRD
        ↓
6.12 User Flow
        ↓
6.13 ERD
        ↓
6.14 Database Dictionary
        ↓
6.15 Database Schema
        ↓
6.16 API
        ↓
6.17 RBAC / Permission / RLS
        ↓
6.18 Functional Specification
        ↓
6.19 Technical Specification  ← THIS ARTIFACT
        ↓
6.20 UI / UX Specification
        ↓
6.21 SEO / Analytics
        ↓
6.22 Module Dependency Matrix
        ↓
6.23 Module Implementation Strategy
        ↓
6.24 Revised Module Planning
        ↓
6.25–6.29 Execution Specifications / Packs / Audit
        ↓
6.30–6.32 Engineering / AI Context
        ↓
6.33–6.37 Final Closure / Reconciliation
```


# 58. W4-02A.6.19 CURRENT SOURCE / AUTHORITY RECONCILIATION

## 58.1 Direct current inputs

| Source | Current state | Technical use |
|---|---|---|
| W4-02A.6.10 Business Rules v1.2 | COMPLETE / GREEN | Normative business invariants and traceability |
| W4-02A.6.11 PRD v2.1 | COMPLETE / GREEN | Product capability/requirement constraints |
| W4-02A.6.12 User Flow v2.1 | COMPLETE / GREEN | Journey/state/edge behavior |
| W4-02A.6.13 ERD v2.1 | COMPLETE / GREEN | Logical relationship boundary |
| W4-02A.6.14 Dictionary v2.2 | COMPLETE / GREEN | Data meaning and physical mapping |
| W4-02A.6.15 Schema v2.7 | COMPLETE / GREEN | Current physical schema reference |
| W4-02A.6.16 API v2.1 | COMPLETE / GREEN | API/resource/interaction contract |
| W4-02A.6.17 RBAC/RLS v2.1 | COMPLETE / GREEN | Authorization and RLS contract |
| W4-02A.6.18 Functional v2.1 | COMPLETE / GREEN | Current functional implementation contract |
| W4-02A.6.5 Architecture v1.8 | COMPLETE / GREEN | Current system topology and architecture |
| W4-02A.6.6 Technical Decisions v1.6 | COMPLETE / GREEN | Current technology consequences |
| W4-01E v2.6 | FROZEN | Physical design authority |
| W4-02 v1.0 | CURRENT EXECUTABLE | Sole executable physical baseline |

## 58.2 Current technical invariants

The following are carried as technical invariants:

1. One integrated RumahAgen system; M01–M15 are semantic modules, not independent applications.
2. No module creates an independent database, RBAC authority, payment authority or duplicate entity authority.
3. Client state is never the authoritative business state.
4. Cross-domain mutation is performed through the owning-domain contract.
5. Payment Core is provider-independent; Provider Adapter isolates provider-specific mechanics.
6. Verification precedes confirmed commercial fulfillment where required.
7. Retry-sensitive ingress and fulfillment are idempotent.
8. Reconciliation is first-class.
9. Entitlement is distinct from RBAC.
10. Learning Activity is the canonical completion/reward boundary.
11. Course Enrollment, Event Registration and Session Enrollment remain distinct.
12. Host and Instructor remain distinct capabilities.
13. Qualification and Awarding authority remain distinct from operational RBAC.
14. Historical confirmed outcomes must remain reconstructable.
15. RLS is a second enforcement layer and is not runtime-verified by documentation alone.
16. W4-01E/W4-02 physical authority cannot be silently changed by this document.
17. No production/runtime PASS is claimed unless verified by the runtime gate.

# 59. W4-02A.6.19 CARRY-FORWARD AUDIT

## 59.1 Predecessor inventory

Exact predecessor:

`RUMAHAGEN_TECHNICAL_SPECIFICATION_v2.0_WAVE3_STEP3.11_FULL_CONSOLIDATED_SYNCHRONIZED.md`

The predecessor contains **57 numbered top-level sections**, including architecture, frontend/backend, API, database, M01–M15 technical responsibility, Learning Economy, Learning Session, authorization/RLS, Commercial/Payment, Awarding, Organization, Search, Maps, caching/rate limiting, storage, AI BYOK, notification, SEO/Analytics, security, error handling, observability, performance, testing, TECH-29 runtime boundary, deployment, migration, technical handoff, legacy preservation, cross-domain contracts, idempotency, background processing, configuration, access control, audit/provenance, test fixtures, production readiness, residual register, traceability, coverage checklist and gate/checkpoint/final chain.

## 59.2 Classification

| Class | Result |
|---|---|
| CARRY FORWARD | All 57 predecessor sections and valid technical content |
| UPDATE | Current W4-02A.6.5/6/11–18 authority versions; current physical 86-table reference; current API/RBAC/functional contracts; current closure state |
| SUPERSEDE | Wave 3 Step 3.11 wording that treated v2.0 downstream contracts as current; old checkpoint labels that conflict with later W4 current authority |
| HISTORICAL / PROVENANCE | Wave 3 v2.0 chronology; TECH-29 historical checkpoint; old AEP/TECH OPEN snapshots; legacy technical baseline lineage |
| REMOVED | 0 |
| Missing valid predecessor content | 0 identified |
| Untraced new substantive content | 0 |
| Material unresolved conflict | 0 |
| Owner decision required | 0 |
| Audit result | PASS |

## 59.3 Silent-deletion scan

No valid predecessor technical section was removed solely for brevity. Where wording was superseded, the historical boundary is preserved rather than silently erased.

# 60. W4-02A.6.19 CONFLICT SCAN / INTERNAL RECONCILIATION

| Conflict class | Finding | Resolution |
|---|---|---|
| Architecture vs Technical Decisions | No active contradiction | Technical Decisions v1.6 is consumed as technology-consequence authority |
| Technical vs API | No active contradiction | API v2.1 is treated as current interaction contract |
| API vs RBAC/RLS | No active contradiction | RBAC/RLS v2.1 is consumed for capability/scope/RLS boundaries |
| Functional vs Technical | No active contradiction | Functional v2.1 is treated as behavior contract; this artifact handles realization constraints |
| ERD/Dictionary/Schema | No active contradiction | 6.13–6.15 chain and W4-01E/W4-02 hierarchy retained |
| Provider architecture | No active contradiction | Midtrans is MVP provider behind adapter; no provider becomes core authority |
| Learning Activity | No active contradiction | Completion/reward boundary retained |
| Host/Instructor | No active contradiction | Separate capabilities retained |
| Commercial Entitlement/RBAC | No active contradiction | Separate authorities retained |
| Historical OPEN wording | Present in provenance | Reclassified as historical where later closure exists |
| Runtime evidence | Not equivalent to design completion | Runtime remains TECH-29/29A/W4-03 boundary |
| Legacy migration/runtime | Historical only | Not used as execution starting point |
| W4-01E/W4-02 physical contradiction | None identified in inspected current chain | No STOP condition triggered |

## 60.1 Important runtime boundary

The technical contract deliberately retains the current runtime blocker:

**Application Runtime Discovery remains an evidence blocker.**

Development evidence and controlled corrections exist, but this document does not convert them into a verified production/runtime state. Authentication smoke tests, RBAC runtime tests, domain runtime tests and production readiness remain downstream execution gates.

# 61. STEP13-D ACCEPTANCE / SECOND-RECONCILIATION GATE

**STEP13-D STATUS = PASS WITH CONTROLLED RESIDUALS — FULL REBUILD v1.3 / SECOND FULL DEEP SCAN CLEAN**

Gate conditions:

- [x] Full technical specification rebuilt as a new successor artifact.
- [x] Core v1.3 treated as immutable/frozen inheritance reference.
- [x] Accepted M01–M15 authority and technical deltas propagated.
- [x] STEP09 Architecture/Dependencies consumed.
- [x] STEP10 Data/ERD/Schema baseline consumed.
- [x] STEP11 API baseline and controlled API residuals consumed.
- [x] STEP12 RBAC/RLS baseline and controlled residuals consumed.
- [x] STEP13-A PRD v3.7 consumed.
- [x] STEP13-B Functional v2.3 consumed.
- [x] STEP13-C User Flow v1.1 consumed.
- [x] Valid Core v1.3 technical detail preserved.
- [x] M01–M15 authority boundaries preserved.
- [x] M14/M15 Q01–Q64 boundary preserved.
- [x] M03 retains Listing/Refresh action authority; M14 supplies commercial allowance.
- [x] M10 remains authorization authority; domain modules retain semantic authority.
- [x] Exact API gaps are explicitly controlled where not evidenced.
- [x] Physical implementation and runtime verification remain separate from semantic/technical contract.
- [x] No fabricated endpoint IDs, permission IDs, physical tables, SQL/RLS policies, migrations, deployment status, or runtime PASS.
- [x] No silent deletion or wholesale replacement.
- [x] Controlled residuals are explicitly registered.
- [x] Second full deep scan completed after correction.

The remaining residuals are implementation/evidence-gated and do not constitute a blocking semantic conflict.

# 62. DOWNSTREAM HANDOFF

STEP13-D now hands its accepted technical contract to:

```text
STEP13-D Technical Specification v1.2
        ↓
STEP13-E UI/UX Specification Synchronization
```

STEP13-E must consume this artifact together with the accepted STEP13-A/B/C outputs and the applicable current API/Data/Authorization baselines. STEP13-E must not reinterpret controlled technical residuals as semantic deletion and must not invent implementation/runtime facts.

Execution stops at STEP13-D in this artifact.

# 63. CURRENT SOURCE / EXECUTION COVERAGE RECORD

The source boundary for this revalidation is **only the files uploaded in the current request**:

1. `STEP13-D_SUCCESSOR_INTEGRATED_TECHNICAL_SPECIFICATION_FULL_REBUILD_PACKAGE_v1.1.zip`
2. `pre-00 gate(20260907-023531).zip`
3. `step12 sync core(1).zip`
4. `step13 sync core.zip`
5. `Step11 Sync core(10).zip`
6. `STEP SYNC CORE(20260907-030419).zip`
7. `Utama core RUMAHAGEN_WIREFRAME_CORE_FINAL_SOURCE_PACK_v1.3(9)_GOVERNANCE_CORRECTED_STEP0_RESIDUAL_FIXED(20260907-030418).zip`

All seven uploaded archives were recursively inspected, including nested ZIP members.

Current scan statistics for this execution:

- 7 top-level uploaded ZIP files;
- 1,822 archive/member instances traversed;
- 104 nested ZIP layers discovered;
- 1,718 leaf members;
- 1,484 text-readable members inspected at content level;
- approximately 74.28 million characters decoded from text-readable content;
- 0 archive/read errors;
- all seven top-level ZIP integrity tests returned `testzip = None`.

The current STEP12-H handoff was found in `step12 sync core(1).zip`; PRE-00/M01–M15 readiness material was found in `pre-00 gate(20260907-023531).zip`; STEP11 API evidence was found in `Step11 Sync core(10).zip`; the current technical baseline and Core inheritance source were found recursively in the uploaded Core/STEP sync packages.

Historical and duplicate artifacts inside these uploads remain provenance unless a current authority record explicitly promotes them.

# 64. FINAL DECLARATION

This artifact is a **NEW FULL SUCCESSOR INTEGRATED TECHNICAL SPECIFICATION v1.2**.

It is **not a patch, append-only correction, or addendum** to v1.1. The complete technical specification has been regenerated with the findings from the current seven-file source boundary incorporated.

The revalidation confirms:

1. STEP13-D now explicitly consumes the PRE-00/M01–M15 readiness boundary.
2. STEP12 authorization/RLS baseline and its controlled residuals are explicitly carried forward.
3. STEP11 API residuals that are relevant to technical implementation are explicitly represented rather than hidden inside a generic gap.
4. Valid Core v1.3 technical scope was checked for silent loss; no semantic deletion was identified.
5. M01–M15 technical changes required by STEP13-D are integrated within the current authority model.
6. Physical implementation and runtime verification remain evidence-gated and non-blocking for semantic integration.
7. No fabricated technical identifiers or runtime claims were introduced.
8. The artifact is ready for STEP13-E, subject to the controlled residuals recorded above.

**FINAL STATUS = PASS WITH CONTROLLED RESIDUALS — STEP13-D FULL REBUILD v1.3 / SECOND FULL DEEP SCAN CLEAN**

**Core v1.3 remains IMMUTABLE/FROZEN REFERENCE.**

**STEP13-D does not replace Core v1.3 in place.**
