# RUMAHAGEN — FUNCTIONAL_FLOW_TRACEABILITY_MATRIX_v1.1

# 20. FUNCTIONAL ↔ FLOW TRACEABILITY MATRIX
| Functional family | Representative functional contract | STEP13-C flow coverage | Treatment |
|---|---|---|---|
|M01|FR-M01-S01 / FR-M01-S02|Registration, OTP activation, Conditional KTP/deferred completion, login/session boundaries|UPDATE-RECONCILE|
|M02|FR-M02-S01..S04|Profile visibility, CTA, review auto-approve/moderation, non-owning outcome presentation|UPDATE-RECONCILE / ADD-NEW|
|M03|FR-M03-S01..S03 + legacy Listing FRs|Create, owner-only update, publish/no Pending Review, publish-lock fields, Suspended distinction, Sold/Rented search exclusion, media-card behavior, Refresh, expiry/closure/transfer|UPDATE-RECONCILE / AUGMENT|
|M04|FR-M04-S01..S04 + Learning FRs|Learning discovery, Free-to-Learn, LP, purchase/acceleration, assessment, Session lifecycle|PRESERVE / AUGMENT|
|M05|FR-M05-S01..S02|Participant mode, Guest registration, notification|AUGMENT|
|M06|FR-M06-S01..S05|Developer, Project, Media, Marketing Kit, Claim/Approval Claim|ADD-NEW / UPDATE-RECONCILE|
|M07|FR-M07-S01..S02|DBR and Bank Master journey|PRESERVE / CONTROLLED|
|M08|FR-M08-S01..S02|Dashboard aggregation and notifications as projections|PRESERVE|
|M09|FR-M09-S01..S04|Moderation, configuration, audit/export, review/escalate/manual correction|AUGMENT|
|M10|FR-M10-S01..S02|Role/default matrix, Superadmin/Manager-Agent preset authority, target mismatch, effective resolution, RLS boundary|AUGMENT / CONTROLLED|
|M11|FR-M11-S01..S04|Ten public surfaces, public SEO and measurement|ADD-NEW / AUGMENT|
|M12|FR-M12-S01..S04|Context, invitation/Join Request, membership actions, listing/entitlement closure resolution, Lead Exit/closure, public content|UPDATE-RECONCILE / AUGMENT|
|M13|FR-M13-S01..S03|Provider Catalogue, BYOK ownership, connection lifecycle, outage/retirement, AI authority restriction|UPDATE-RECONCILE|
|M14|FR-M14-S01..S11|Catalog, subscription/add-on, promotion, order snapshot/confirmed_at, payment evidence/verification, fulfillment, entitlement, quota, refund/chargeback, Refresh Allowance, reconciliation|AUGMENT / UPDATE-RECONCILE|
|M15|FR-M15-S01..S03|Qualification/evidence, Developer Learning evidence dependency, Awarding|ADD-NEW / AUGMENT|

---
