# RUMAHAGEN — USER FLOW SPECIFICATION
## STEP13-C — Successor Integrated User Flow Synchronization
### Full Rebuild v1.1 — 2026-09-07

**Artifact mode:** FULL VERSION / WHOLE-ARTIFACT REBUILD / NOT PATCH / NOT APPEND
**Source boundary:** current conversation uploads only; no web/external source used
**Core v1.3:** IMMUTABLE / FROZEN REFERENCE
**Upstream functional authority:** STEP13-B Successor Integrated Functional Specification v2.3
**Gate posture:** semantic acceptance is separate from physical/runtime proof

---
# 0. STEP13-C EXECUTION CONTRACT
## 0.1 Objective
STEP13-C rebuilds the User Flow as the end-to-end behavioral bridge between the accepted Functional Specification and the later UI/UX stage. The flow model describes journeys, actor/context decisions, state transitions, branches, outcomes, failure/edge behavior and authority-preserving cross-domain handoffs. It is not a screen-by-screen UI specification.

## 0.2 Authority chain
Current semantic authority = M01–M15 current authoritative recon/decisions → frozen Core v1.3 valid detail → accepted STEP08–STEP12 baselines → STEP13-A PRD v3.7 → STEP13-B Functional v2.3 → this STEP13-C User Flow.
Historical W4-02A.6 User Flow material is preservation/provenance input only and does not outrank the accepted successor chain.

## 0.3 Mandatory synchronization model
- **PRESERVE:** retain every valid inherited Core flow.
- **AUGMENT:** add current rules, states, conditions, branches and dependencies without deleting valid inherited detail.
- **ADD-NEW:** create flow paths for valid new capabilities absent from the predecessor.
- **UPDATE-RECONCILE:** change only the affected flow semantics where a current authoritative decision supersedes or conflicts with predecessor wording.

Core v1.3 is never edited in place. Missing physical/runtime evidence is never used as a reason to delete a valid semantic flow.

## 0.4 Flow notation
- **Actor** = person/system actor initiating or receiving a journey.
- **Context** = Personal, Organization, Public, Partner or other governed context.
- **Decision** = business/authorization/state condition supported by upstream authority.
- **State** = lifecycle state owned by the applicable domain.
- **Outcome** = authoritative result produced by the owning domain.
- **Projection** = dashboard/notification/SEO/analytics representation; projection is not authority.
- **Handoff** = directional transfer between domains without authority inversion.

---
# 1. GLOBAL USER FLOW INVARIANTS
- Identity establishes authenticated context; authentication does not itself assign business permissions.
- Visibility is not authorization.
- Membership is not ownership.
- Membership is not entitlement.
- Entitlement is not RBAC permission.
- Payment confirmation is not a direct permission grant.
- Completion is not automatically LP, credential, Title or Award.
- Course Enrollment, Event Registration and Session Enrollment remain separate lifecycle concepts.
- Host and Instructor remain separate capabilities.
- Organization membership does not automatically assign Host or Instructor authority.
- Client claims do not create authoritative business outcomes.
- Server-authoritative state controls governed lifecycle transitions.
- Current configuration does not rewrite historical outcomes.
- Domain authority remains with the owning module; downstream projections cannot mutate upstream state.
- Physical/API/RLS/runtime gaps remain evidence-gated and controlled where no semantic contradiction is established.

## 1.1 Canonical cross-domain journey
**Identity → Personal Context → discover/operate domain → optional Organization Context → optional Commercial transaction → verified entitlement → authorized access → domain outcome → Learning Activity/Qualification where applicable → Awarding where applicable → notification/analytics projection.**

---
# 2. ACTOR / CONTEXT FLOW MODEL
| Actor/context | Flow responsibility | Boundary |
|---|---|---|
|Guest|Public discovery and supported Guest registration/contact flows|No canonical authenticated identity is inferred from Guest contact data|
|Authenticated Agent/User|Personal context, owned resources, authorized domain actions|Authorization is evaluated separately from authentication|
|Manager / Partner / Buyer|Only capabilities supported by current role/scope semantics|No capability expansion through UI visibility|
|Admin|Governed administrative/moderation/configuration actions|M09 authority applies; M10 remains authorization owner|
|Superadmin|Superadmin-scoped administrative/provider operations|Provider Catalogue mutation and applicable administrative operations remain explicitly bounded|
|Organization context|Membership/context and organization-owned resources where supported|Membership does not imply ownership or entitlement|
|Domain service / projection|State projection, notification, analytics, SEO or provider result handling|Projection/integration does not become business authority|

---
# 3. M01 — IDENTITY / AUTHENTICATION / ACTIVATION
## 3.1 Registration / OTP
**Preconditions:** registration data is accepted by the current identity contract.
**Main flow:** Start registration → validate registration input → initiate OTP → user submits OTP → verify OTP → successful verification establishes authenticated account context → account becomes ACTIVE where the accepted M01 lifecycle permits.
**Alternate:** OTP expired/invalid → verification fails → remain outside authoritative ACTIVE state → retry according to identity rules.
**KTP branch:** if KTP is deferred/conditional, account flow may continue subject to the governed eligibility condition; KTP remains an eligibility/requirement condition, not an RBAC permission.
**Boundary:** authentication success does not itself grant domain capabilities; authorization is evaluated separately.

## 3.2 Login / session
Login → authenticate → establish authenticated context → evaluate current authorization separately → enter permitted product context.
Password recovery/reset returns the user to the authentication lifecycle; it does not grant business permissions.

## 3.3 Verification Document flow
Authorized actor → create/submit Verification Document according to the M01 role scope → document remains private/non-public → authorized reviewer may view/review according to governed role scope → verification result is consumed only by applicable eligibility/verification logic. Verification-document visibility does not become public profile visibility and verification does not become an RBAC permission.

## 3.4 Conditional KTP exact path
User selects `ISI NANTI` → KTP is recorded as `DEFERRED/NOT_PROVIDED` → account may proceed to `ACCOUNT=ACTIVE` where the accepted M01 eligibility condition permits → user reaches `HOME`. Successful OTP remains the identity activation event; no default Pending Review/approval gate is introduced solely because KTP is deferred.

## 3.3 Failure / denied branches
- Invalid credentials/verification → authentication failure.
- Expired verification → no authoritative activation.
- Authorization denied after authentication → authenticated user remains authenticated but cannot execute the denied capability.

---
# 4. M02 — PROFILE / PUBLIC VISIBILITY / REVIEW / OUTCOME PRESENTATION
## 4.1 Profile flow
Authenticated actor → open profile → view/edit fields permitted by ownership and authorization → save governed changes → updated profile becomes the source for downstream permitted projections.
Sensitive/private fields remain protected; public projection exposes only approved public information.

## 4.2 Public profile / CTA
User configures public visibility/CTA opt-in where supported → system evaluates authorization and visibility settings → public profile is projected only when eligible → public visitor sees approved public information.
Public/WhatsApp CTA requires explicit Agent opt-in. Superadmin is the only actor that may administratively override another Agent's profile visibility or Public CTA, subject to the governed authorization boundary. PUBLIC/PRIVATE is a visibility state, not an RBAC scope. Private Identity and Legal/Verification Documents remain non-public.

## 4.3 Review flow — current reconciliation
Buyer/Agent submits review → validation → **AUTO-APPROVE** → review becomes Published/Viewable → Admin moderation may occur **post-publication** → moderation action is recorded without converting Admin moderation into a pre-publication approval gate.
This reconciles stale predecessor wording while preserving valid moderation capability.

## 4.4 Outcome Presentation
Upstream Learning/Award/Organization outcome is produced by its owning domain → M02 Outcome Presentation consumes/represents the approved result → presentation exposes permitted outcome information → M02 does not mutate or become owner of the upstream outcome.

---
# 5. M03 — LISTING / PUBLICATION / REFRESH
## 5.1 Create Listing
Authenticated authorized actor → select Personal/Organization context → create Draft → enter Listing content → validate → retain Draft until governed publish action.
Listing ownership and lifecycle remain M03-owned. Commercial entitlement/quota can determine commercial capacity, but it does not replace RBAC authorization.

## 5.2 Listing ownership, edit locks and search-state behavior
After creation, ordinary Listing Update remains owner-only; Organization membership does not create ordinary edit authority. After the first successful Publish, Address, Property Type, Land Size and Building Size become locked against ordinary edits. `Suspended` remains a violation/code-of-ethics enforcement state and is not a publication-approval state. Sold/Rented listings are excluded from public Search while historical Agent-profile counts remain preserved. Ordinary Search cards use optimized thumbnail/card derivatives, preserve aspect ratio, and do not deliver original-resolution media as the normal card path; stretching is prohibited. Refresh does not create regional quotas.

## 5.2 Normal publication — current reconciliation
Draft → validate publish conditions → Publish → Listing becomes the applicable published/public state → public discovery/analytics projections may follow.
**Normal Listing publication does not use Pending Review as a mandatory approval gate.** Unrelated account/application Pending Review semantics remain where separately governed.

## 5.3 Refresh flow
Agent selects eligible Listing → system checks authorization → system checks current Refresh allowance → system checks whether that Listing has already received a successful Refresh during the current Asia/Jakarta operational day → if eligible, execute Refresh → use server transaction time as authoritative timestamp → reposition within governed district-local behavior → consume one successful allowance → record audit provenance → expose updated discovery timing.
Current contract: default configured allowance is 5 successful Refreshes/Agent/operational day; no carry-forward; maximum one successful Refresh per Listing/day; Agent may distribute allowance across Listings; failed Refresh does not consume allowance; equal timestamps use first-recorded-action tie-break.
Commercial ownership: M14 owns configurable commercial allowance/entitlement; M03 owns Listing/Refresh action enforcement; M10 owns authorization.

## 5.4 Refresh failure branches
- Unauthorized → denied; no allowance consumed.
- Allowance exhausted → unavailable/denied according to governed state; no action mutation.
- Listing already successfully refreshed that operational day → unavailable/denied; no second successful refresh.
- Validation/system failure before successful action → failed; allowance not consumed.

## 5.5 Listing lifecycle / expiry
Create Draft → edit → publish → public discovery → views/leads/measurement → expiry/inactivation/closure according to M03 lifecycle → preserve historical provenance where governed.

---
# 6. M04 — LEARNING / LEARNING ECONOMY / LEARNING SESSION
## 6.1 Learning discovery
User opens Learning → discover available learning content/session → inspect permitted content → choose learning path/activity.

## 6.2 Free-to-Learn / Learning Activity
Eligible user → start learning activity → consume required learning content → complete activity conditions → completion is recorded by the Learning authority.
Completion does not automatically become an Award/Title; downstream evidence/qualification remains separately governed.

## 6.3 Learning Points / pay-to-accelerate
User earns LP from eligible learning activity → LP balance is updated by M04 → user may redeem LP for supported learning/skill path outcomes.
Where purchase is supported: user selects LP package → commercial order/checkout → payment verification → fulfillment → LP entitlement/balance update. Payment is not itself an LP grant until verified/fulfilled.
Pay-to-accelerate remains an optional commercial path; it does not remove learning/assessment requirements for governed credentials.

## 6.4 Assessment / credential
Learning completion → required assessment → pass/fail decision → if qualification criteria are satisfied, M04 produces its learning-owned evidence/credential state → downstream M15 may consume evidence for qualification/award.

## 6.5 Learning Session
Session creator/authorized actor → create Session → configure lifecycle/visibility/provider/host/instructor as separately authorized → publish/activate → user enrolls → Session Enrollment PENDING → ACTIVE → participates → attendance/evidence → COMPLETED where conditions are satisfied.
Event may surface/associate a Session but does not own Session lifecycle. Event Registration/RSVP remains distinct from Session Enrollment. Provider session ID/meeting link is infrastructure binding, not semantic Session identity. events.quota is not canonical Session capacity.

## 6.6 Session taxonomy and provider-switching branches
A Learning Session may be BROADCAST, INTERACTIVE or ON_DEMAND according to the governed taxonomy. Provider binding is infrastructure, not Session identity. There is no automatic provider failover; a provider switch is an explicit authorized operation that preserves Session semantic identity and records the applicable evidence/provenance.

## 6.6 Session visibility branches
- PUBLIC → discoverable according to public visibility rules.
- ORGANIZATION → available within governed organization context.
- PARTNER → available to governed partner context.
- PRIVATE → restricted to authorized audience.

## 6.7 Provider / attendance / completion
Provider binding → provider evidence → normalized/idempotent evidence handling → attendance → completion. AI may assist but cannot become attendance/completion authority.
Host and Instructor remain separate capabilities; assigning one does not automatically grant the other.

---
# 7. M05 — EVENT / REGISTRATION
## 7.1 Event creation
Authorized actor → create Event → configure event details/participant mode → optionally associate a Session → publish according to event lifecycle.

## 7.2 Registration
Visitor/user → open Event → choose supported participant mode → register → registration state is recorded by M05 → confirmation/notification is delivered through the applicable communication path.

## 7.3 Guest
Guest → provide required contact data → submit registration → Guest registration is stored according to the supported flow → email is used as notification/contact destination where required → no canonical authenticated identity is inferred solely from Guest email.
If an Event/Session link is available, confirmation may contain the applicable link; the flow must not fabricate a link.

## 7.4 Event-start notification
Registered/Waitinglist participant → event reaches notification condition → notification is sent to the governed destination → notification communicates status and does not become business authority.

---
# 8. M06 — DEVELOPER / PROJECT / MEDIA / MARKETING KIT / CLAIM
## 8.1 Developer
Authorized Developer actor → open Developer profile → manage approved semantic fields including company_logo and free-text “Tentang Developer” → save → permitted public/internal projections update.

## 8.2 Project
Developer → create/edit Project within authorized scope → provide governed Project semantic fields → save → Project becomes available to supported Listing/discovery relationships.
Developer Project is a source compatible with Listing M03 semantics; compatibility does not transfer M03 Listing action authority. Developer non-exclusivity remains the governing rule unless a separately approved decision changes it.

## 8.3 Project Media
Authorized Developer → add photo/video Project Media → validate semantic media boundary → save → media becomes available to supported Project presentation.
The M06 semantic boundary is photo/video; physical evidence that contains additional values does not broaden M06 semantic authority.

## 8.4 Marketing Kit
Authorized actor → open Marketing Kit → authorization/scope check → permitted action executes → audit/provenance as applicable.
Locked direction: Developer = own CRUD; Admin/Superadmin = All; Manager/Agent = View + Download; Buyer/Partner = none. No new permission IDs are created by this flow.

## 8.5 Claim / Approval Claim
Agent submits Project Claim → Claim enters governed lifecycle → applicable authority reviews → Approval Claim is produced on approval → Approved Claim may initialize the Agent-owned Listing relationship where supported → M03 retains Listing ownership/lifecycle authority.
Claim approval does not grant ordinary M03 Create/Update/Publish/Refresh capability by itself.

---
# 9. M07 — DBR / BANK MASTER
## 9.1 DBR
User provides supported financing inputs → DBR calculation executes under M07 authority → result is presented → result history is retained according to governed provenance.

## 9.2 Bank selection / Bank Master
User selects/receives applicable bank information → Bank Master semantics are consumed where supported → no physical Bank Master table is invented in this User Flow.
Physical Bank Master realization remains a controlled downstream evidence item.

---
DBR result history remains available as historical provenance where governed; bank selection consumes Bank Master/DBR configuration and does not grant lending authority.

# 10. M08 — DASHBOARD / NOTIFICATION
## 10.1 Dashboard
Domain state/event changes → projection pipeline → dashboard aggregates authorized data → user views dashboard.
Dashboard is a projection; it does not mutate the owning domain merely because a value is displayed.

## 10.2 Notification
Governed domain event/state change → notification eligibility/destination check → notification generated/sent → recipient receives status/message → underlying domain remains source of truth.
Notification failure is recorded/handled without changing the authoritative domain outcome unless the owning domain explicitly defines otherwise.

---
# 11. M09 — ADMINISTRATION / CONFIGURATION / AUDIT
## 11.1 System Configuration
Authorized administrator → open System Configuration → authorization/scope check → modify supported configuration → save → current configuration applies to future eligible behavior.
Configuration changes do not rewrite historical outcomes.

## 11.2 Administrative Audit
Governed administrative action → audit/provenance record → authorized reviewer can inspect history. Audit is historical/provenance authority, not a replacement for domain ownership.

## 11.3 Administrative Export
Superadmin → request administrative export → authorization check → generate supported export → deliver/download → record provenance.
Administrative Export remains M09-owned; M10 supplies authorization semantics.

## 11.4 Review / Escalate / Manual Correction
Administrative issue enters applicable workflow → Review → if required Escalate → authorized Manual Correction → record resulting change and provenance. These are distinct actions; one is not silently substituted for another.
Provider-domain execution remains with the provider/domain owner; M09 is not a super-domain.

---
# 12. M10 — AUTHORIZATION / RBAC / RLS
## 12.1 Authorization resolution
Authenticated account → resolve Role/actor grouping → resolve baseline Role Permission → if configured, resolve optional Permission Preset targeted to the existing Role → evaluate scope/ownership/organization/domain conditions → authorize or deny action.
Permission Preset cannot create capabilities outside the target Role baseline, cannot become a new Role, and cannot bypass ownership/organization/domain constraints. Superadmin has Full Governance. Manager may manage Permission Presets only for Agent targets. Admin, Buyer, Developer, Instructor and Agent do not manage Permission Presets. No-preset resolves to Role Default Matrix; active preset resolves to the Current Active Preset Matrix; empty preset resolves to Role Default Matrix; target-role mismatch fails closed. Preset lifecycle is separate from account lifecycle.

## 12.2 Negative authorization
Actor requests action → authorization evaluation fails → Permission Denied/Unavailable outcome → no business mutation.
UI visibility must not be interpreted as authorization.

## 12.3 RLS/runtime boundary
The flow recognizes the required authorization/RLS boundary but does not claim runtime verification. Exact permission IDs, endpoint IDs, physical tables and RLS SQL are downstream implementation artifacts and are not invented here.

---
# 13. M11 — PUBLIC DISCOVERY / SEO / MEASUREMENT
## 13.1 Mandatory public discovery surfaces
The public discovery flow must preserve all ten mandatory surfaces:
1. Homepage
2. Listing
3. Agent
4. Organization
5. Developer/Project
6. Event
7. Learning
8. Learning Session
9. Static Public Content
10. Announcement/Promotion

## 13.2 Public discovery flow
Public visitor → discover/search/navigation → open public resource → public projection checks visibility → render approved public content → measurement event may be recorded.
Static Public Content and Announcement/Promotion remain first-class public discovery surfaces even though lifecycle/configuration is owned by M09 or the applicable authoritative domain.

## 13.3 Listing/public lifecycle
Listing published/eligible → public discovery projection → views/leads/analytics → listing changes state → SEO/public availability follows the new governed state.
Private/protected resources are not exposed merely because they are indexable in another context.

## 13.4 Measurement
Authorized/public interaction → analytics event → measurement store/projection → reporting. Analytics cannot mutate authoritative business state.

---
## 13.5 Canonical discovery controls
For indexable public representations, the discovery flow uses one canonical URL per public identity, derives structured data from canonical resource state, and follows owning-domain lifecycle for indexability/sitemap participation. Discovery/analytics failure does not mutate business lifecycle. Protected/private resources remain server-authorized and are not exposed merely because a route exists.

# 14. M12 — ORGANIZATION / MEMBERSHIP / CONTEXT
## 14.1 Create / join / membership
Authorized user → create Organization or request/invite membership → membership state changes according to organization authority → user may enter Organization Context where membership permits.
Membership does not equal ownership and does not equal entitlement.

## 14.2 Membership, invitation and Join Request branches
Invitation: Create → Pending → Accept / Reject / Revoke; system cancellation may invalidate a pending invitation when organization lifecycle/enforcement requires it. Invitation acceptance creates membership but does not create ownership or commercial entitlement. Join Request supports Create / View / Cancel / Accept / Reject; closure/enforcement invalidation cancels pending requests. Membership actions are explicit and must not be replaced by a generic status mutation.

## 14.2 Organization-owned operations
User switches/selects Organization Context → system resolves organization-scoped resources → authorization and ownership conditions are evaluated → authorized operation executes against organization-owned resource.
Personal and Organization Context remain distinguishable.

## 14.3 Lead Exit / closure
Member/Lead Exit condition → organization enters CLOSING where required → closure processing completes → organization reaches CLOSED → CLOSED is irreversible.
No Lead Transfer/successor privilege inheritance is inferred. Exit does not automatically transfer privileges to another actor. Where the governed organization/listing closure path requires transfer or resolution of Organization Listings, transfer/forfeiture/ownership resolution follows the applicable M03/M14 contract; Personal Listings are not processed as Organization assets. Permanent add-on ownership remains with its governed recipient.

## 14.4 Organization Public Content
Authorized organization actor → manage organization-owned public content → M11 may discover/project approved public content → M11 does not become lifecycle owner.
Physical ORG-ADMIN terminology does not create a new platform role.

---
# 15. M13 — PROVIDER / BYOK / AI
## 15.1 Provider Catalogue
Superadmin → manage Provider Catalogue → authorization check → add/update/remove supported provider catalogue entry → record configuration/provenance.
Provider Catalogue mutation is Superadmin-only under current M13 authority.

## 15.2 Connection lifecycle
Agent/User creates own provider connection → UNVERIFIED → test success → VALID/ACTIVE. From VALID/ACTIVE, governed states include DISABLED, INVALID/ERROR, REVOKED/FORCE DISCONNECTED and DISCONNECTED/DELETED. Provider retirement may system-disconnect affected connections; temporary provider outage does not transfer ownership or automatically revoke the connection. One active connection per provider per Agent is the governed ownership boundary where applicable.

## 15.2 BYOK
Agent/User → configure own provider credential/BYOK → secure storage/configuration path → request AI assistance → provider result returned → user/authorized domain decides what business action, if any, follows.
BYOK ownership is Agent/User / OWN. Provider credential is not platform business authority.

## 15.3 AI authority restriction
AI may assist with domain information/output → AI cannot create authoritative attendance, completion, payment verification, entitlement, qualification, award, permission or other domain outcomes by itself.

---
# 16. M14 — COMMERCIAL / PAYMENT / ENTITLEMENT / QUOTA / PROMOTION
## 16.1 Commercial lifecycle
User selects commercial item → Order/Checkout → payment provider interaction → provider result/webhook → verification → fulfillment → entitlement → quota/usage application → reconciliation/audit.
Payment, Entitlement and RBAC remain separate authorities.

## 16.2 Commercial catalog and state presentation
The approved M14 commercial surface set remains preserved as the current commercial catalog scope. The user flow may traverse Product/Offer → Order/Checkout → Pending Payment → Processing → Confirmed/Failed/Expired/Cancelled → Fulfillment → Entitlement → Quota/Benefit. Order purchase data uses an immutable purchase snapshot; `confirmed_at` is authoritative only after trusted verification. Provider callbacks/results are evidence inputs, not direct confirmation. Refund/chargeback states remain distinguishable and reconcile through the commercial authority.

## 16.2 Subscription / Add-on
User selects Subscription/Add-on → create order → payment → verify → fulfill → create/update entitlement → commercial capacity becomes available according to the applicable entitlement rules.
Historical purchase integrity is preserved; current configuration does not rewrite historical outcomes.

## 16.3 Promotion
Eligible commercial context → applicable promotion evaluated → order/checkout reflects supported promotion → payment verification → fulfillment/entitlement follows governing rules.

## 16.4 Payment failure / verification
Checkout initiated → payment fails or remains unverified → entitlement is not treated as successfully fulfilled → user receives applicable failure/pending outcome → reconciliation can later identify inconsistency.

## 16.5 Idempotent fulfillment
Verified provider result → check whether fulfillment has already been applied → if already fulfilled, do not duplicate → otherwise fulfill exactly once under commercial authority → record provenance.

## 16.6 Quota / Refresh allowance
Commercial entitlement/configuration establishes commercial capacity → M03 checks action eligibility and enforces Listing/Refresh operation → M10 evaluates authorization.
This preserves the locked chain: **M14 commercial allowance/entitlement → M03 Listing/Refresh action enforcement → M10 authorization.**

## 16.7 Reconciliation
Provider/payment state → compare with internal commercial state → identify mismatch → record/reconcile according to authority → do not silently mutate unrelated domain state.

## 16.8 Q boundary
Q01–Q64 remain M14. Q40, Q54, Q61 and Q62 remain M14. No M15 flow absorbs these questions.

---
# 17. M15 — QUALIFICATION / EVIDENCE / AWARD / TITLE
## 17.1 Qualification
Evidence becomes available from an owning source → M15 evaluates qualification criteria/Rule Version → qualification result is produced → if eligible, proceed toward Award.
Qualification/eligibility is not authorization/permission.

## 17.2 Developer Learning evidence
Developer completes Learning under M04 → M04 owns learning activity/evidence → qualifying evidence is handed to M15 → M15 evaluates qualification → M15 may issue Award/Title according to its authority.
This is a directional dependency; M15 does not take over M04 Learning authority.

## 17.3 Award / Title
Qualification satisfied → Awarding authority resolves applicable Rule Version → Award Instance is created/snapshotted → Title presentation may expose the approved outcome → stable Title identity/history is preserved.
Title Definition and Award Instance remain distinct.

## 17.4 Presentation
Approved Award/Title outcome → authorized/public presentation layer → user/viewer sees permitted outcome → presentation does not mutate Award/Qualification.

---
# 18. CROSS-DOMAIN USER FLOW CHAINS
## 18.1 — Onboarding
Identity → Authentication → Personal Context → authorization evaluation → permitted product entry.

## 18.2 — Claim → Listing
M06 Claim → Approval Claim → approved Agent-owned Listing initialization dependency → M03 owns Listing lifecycle/action.

## 18.3 — Listing → Discovery
M03 Listing lifecycle → M11 public discovery/SEO/measurement → M08 projection/notification where applicable.

## 18.4 — Commercial → Learning
Learning purchase intent → M14 Order/Payment/Verification/Fulfillment → entitlement/LP outcome → M04 Learning authority.

## 18.5 — Learning → Qualification
M04 Learning Activity/Session completion/evidence → M15 Qualification Evidence → Award/Title where criteria are met.

## 18.6 — Commercial → Listing Refresh
M14 allowance/entitlement → M03 Refresh action eligibility/enforcement → M10 authorization → successful Refresh/audit.

## 18.7 — Organization → Listing
M12 Organization Context → M10 authorization/ownership/scope → M03 Listing operation.

## 18.8 — Organization → Session
M12 Organization Context → M04 Session visibility/enrollment/ownership as authorized.

## 18.9 — Event → Session
M05 Event surfaces/associates M04 Session → Session remains M04-owned.

## 18.10 — Payment → Entitlement
M14 Payment verification → Fulfillment → Entitlement → commercial capacity; payment is not a direct permission grant.

## 18.11 — Dashboard/Notification
Owning domain state/event → M08 projection/notification → recipient sees communication; source domain remains authoritative.

## 18.12 — AI assistance
User → M13 BYOK/provider → AI assistive output → user/authorized domain decides business action; AI is not authority.

---
## 18.13 — Legacy flow preservation controls
The successor preserves still-valid inherited behavior including: Personal vs Organization context separation; Organization Listing transfer/closure resolution; historical Listing origin/provenance; Learning Activity as completion/reward boundary; Course Enrollment ≠ Event Registration ≠ Session Enrollment; Session taxonomy BROADCAST/INTERACTIVE/ON_DEMAND; explicit Host/Instructor separation; provider switching without automatic failover; immutable purchase snapshot and trusted payment verification; DBR result history; and AI secret/authority boundaries. Superseded historical behavior is not revived.

# 19. STATE / EXCEPTION / NEGATIVE FLOW CATALOG
| Condition | Flow consequence | Authority consequence |
|---|---|---|
|Validation failure|Return validation error; do not advance governed state|Owning domain state remains unchanged|
|Authorization denied|Permission Denied / unavailable branch|No business mutation|
|Pending|Remain in owning domain pending state until governed transition|No premature outcome|
|Empty|Show empty-state branch without fabricating records|No authority created|
|Unavailable|Explain unavailable condition; no unauthorized fallback|No mutation|
|Payment failure/unverified|Do not treat as fulfilled entitlement|M14 remains source of commercial state|
|Provider failure|Handle failure/retry/manual path supported by contract|Provider result does not become entitlement without verification|
|Duplicate fulfillment|Detect prior fulfillment and avoid duplication|Idempotency preserved|
|Expired Listing|Follow M03 lifecycle transition|Public discovery follows resulting state|
|Organization CLOSING|Closure workflow proceeds under M12|No new successor privileges inferred|
|Organization CLOSED|Terminal organization state|No ordinary active organization operation inferred|
|Guest|Use supported Guest path|Guest contact is not canonical identity|
|Runtime/RLS unverified|Carry as controlled evidence-gated residual|Never claim runtime PASS|

---
# 20. FUNCTIONAL ↔ FLOW TRACEABILITY MATRIX
| Functional family | Representative functional contract | STEP13-C flow coverage | Treatment |
|---|---|---|---|
|M01|FR-M01-S01 / FR-M01-S02|Registration, OTP activation, Conditional KTP/deferred completion, login/session boundaries|UPDATE-RECONCILE|
|M02|FR-M02-S01..S04|Profile visibility, CTA, review auto-approve/moderation, non-owning outcome presentation|UPDATE-RECONCILE / ADD-NEW|
|M03|FR-M03-S01..S03 + legacy Listing FRs|Create, owner-only update, publish/no Pending Review, publish-lock fields, Suspended distinction, Sold/Rented search exclusion, media-card behavior, Refresh, expiry/closure/transfer|UPDATE-RECONCILE / AUGMENT|
|M04|FR-M04-S01..S04 + Learning FRs|Learning discovery, Free-to-Learn, LP, purchase/acceleration, assessment, Session lifecycle|PRESERVE / AUGMENT|
|M05|FR-M05-S01..S02|Participant mode, Guest registration, notification|AUGMENT|
|M06|FR-M06-S01..S05|Developer, Project, Media, Marketing Kit, Claim/Approval Claim|ADD-NEW / UPDATE-RECONCILE|
|M07|FR-M07-S01..S02|DBR and Bank Master journey|PRESERVE / CONTROLLED|
|M08|FR-M08-S01..S02|Dashboard aggregation and notifications as projections|PRESERVE|
|M09|FR-M09-S01..S04|Moderation, configuration, audit/export, review/escalate/manual correction|AUGMENT|
|M10|FR-M10-S01..S02|Role/default matrix, Superadmin/Manager-Agent preset authority, target mismatch, effective resolution, RLS boundary|AUGMENT / CONTROLLED|
|M11|FR-M11-S01..S04|Ten public surfaces, public SEO and measurement|ADD-NEW / AUGMENT|
|M12|FR-M12-S01..S04|Context, invitation/Join Request, membership actions, listing/entitlement closure resolution, Lead Exit/closure, public content|UPDATE-RECONCILE / AUGMENT|
|M13|FR-M13-S01..S03|Provider Catalogue, BYOK ownership, connection lifecycle, outage/retirement, AI authority restriction|UPDATE-RECONCILE|
|M14|FR-M14-S01..S11|Catalog, subscription/add-on, promotion, order snapshot/confirmed_at, payment evidence/verification, fulfillment, entitlement, quota, refund/chargeback, Refresh Allowance, reconciliation|AUGMENT / UPDATE-RECONCILE|
|M15|FR-M15-S01..S03|Qualification/evidence, Developer Learning evidence dependency, Awarding|ADD-NEW / AUGMENT|

---
# 21. ROLE / AUTHORIZATION-AWARE FLOW MATRIX
| Actor | Representative flow | Scope/condition | Denied behavior |
|---|---|---|---|
|Guest|Public discovery; supported Event Guest registration|Public/Guest-supported resource|Protected/unauthorized actions denied|
|Agent/User|Profile, Listing, Learning, BYOK, commercial, qualification journeys|Personal ownership plus permitted organization scope|No capability outside resolved authorization|
|Developer|Developer/Project/Media/Marketing Kit/Claim flows|Own scope for Developer/Marketing Kit; governed project/claim scope|No cross-scope mutation|
|Manager|Organization/context and permitted view/operate flows|Resolved organization/scope|No action outside baseline/scope|
|Partner|Partner Learning/session/content flows where supported|Partner scope|No unsupported ownership or mutation|
|Buyer|Public discovery, supported review/event/commercial journeys|Own permitted interactions|No administrative/domain mutation|
|Admin|Moderation, configuration, audit, supported administrative operations|Admin scope|No Superadmin-only operation|
|Superadmin|Superadmin-scoped administration and Provider Catalogue mutation|Superadmin scope|Still subject to domain boundary; no super-domain ownership|

**Authorization note:** the matrix expresses flow behavior, not newly invented permission IDs. Effective authorization remains the accepted STEP12 model.

---
# 22. M01–M15 CURRENT DELTA ACCEPTANCE MATRIX
| Module | Current delta | STEP13-C acceptance consequence | Treatment |
|---|---|---|---|
|M01|Conditional KTP / deferred completion|Identity/authentication flow must distinguish eligibility/requirement from authorization; successful OTP activates account; deferred KTP remains a requirement condition.|UPDATE-RECONCILE|
|M02|Review auto-approve + Outcome Presentation|Review submission reaches AUTO-APPROVED → Published/Viewable; moderation is post-publication; outcome presentation is non-owning.|UPDATE-RECONCILE / ADD-NEW|
|M03|Normal publication + Refresh|Normal Listing publication is not gated by Pending Review; Refresh has governed allowance/action/state behavior and preserves M03 action authority.|UPDATE-RECONCILE / AUGMENT|
|M04|Learning / Learning Economy / Session|Learning remains M04-owned; Learning Economy and Session journeys remain separate from M15 qualification authority.|PRESERVE / AUGMENT|
|M05|Event / Registration / Guest|Event and Registration journeys preserve participant_mode and Guest semantics; Guest contact destination is not canonical identity.|AUGMENT|
|M06|Developer / Project / Media / Marketing Kit / Claim|Developer fields, Project semantics, media boundary, Marketing Kit permissions, Claim lifecycle and Approved Claim → Agent-owned Listing initialization are represented.|ADD-NEW / UPDATE-RECONCILE|
|M07|DBR / Bank Master|DBR remains M07 authority; Bank Master remains a controlled physical/traceability residual without invented persistence.|PRESERVE / CONTROLLED|
|M08|Dashboard / Notification|Projection and communication only; no domain mutation authority is introduced.|PRESERVE|
|M09|Administration / Configuration / Audit|System Configuration, Administrative Audit, Administrative Export, Review/Escalate/Manual Correction remain M09-owned; provider execution stays elsewhere.|AUGMENT|
|M10|RBAC / Permission Preset / RLS boundary|Role, baseline Role Permission and optional Permission Preset remain distinct; preset cannot create capability outside target Role baseline; runtime/RLS remains unverified.|AUGMENT / CONTROLLED|
|M11|10 public discovery surfaces|All ten mandatory public surfaces remain discoverable; Static Public Content and Announcement/Promotion are explicitly included; lifecycle remains with M09/applicable domain.|ADD-NEW / AUGMENT|
|M12|Organization / Membership / Context|Organization lifecycle, membership/ownership/entitlement separation, Lead Exit → CLOSING → CLOSED, no successor privilege inheritance.|UPDATE-RECONCILE / AUGMENT|
|M13|Provider Catalogue / BYOK|Provider Catalogue mutation is Superadmin-only; BYOK is Agent/User-owned; M10 remains authorization authority.|UPDATE-RECONCILE|
|M14|Commercial / Payment / Entitlement / Quota / Refresh|Payment, verification, fulfillment, entitlement, quota, promotion and reconciliation are distinct; Refresh Allowance is additive commercial contract input to M03.|AUGMENT / UPDATE-RECONCILE|
|M15|Qualification / Evidence / Award / Title|Qualification/evidence/award/title flows remain M15-owned; Developer Learning evidence originates in M04 and is consumed by M15; Q01–Q64 remain M14.|ADD-NEW / AUGMENT|

---
# 23. CORE PRESERVATION / LEGACY FLOW RECONCILIATION
The predecessor User Flow material establishes durable cross-domain invariants that remain preserved in this successor flow. These include:
- Identity → Personal Context → optional Organization Context → optional Commercial → Entitlement → authorized access → domain outcome.
- Payment ≠ Entitlement; Entitlement ≠ RBAC; Payment success ≠ Permission grant.
- Learning Activity is the completion/reward boundary; Event does not own Session.
- Host ≠ Instructor; Instructor ≠ automatic Host.
- Organization membership ≠ ownership/entitlement/Host/Instructor assignment.
- Listing lifecycle remains M03-owned while commercial capacity and authorization are separate dependencies.
- Dashboard/Notification/Analytics are projections and do not become authoritative state mutation layers.
- AI is assistive and cannot become domain authority.
- Historical artifacts are preserved as provenance and are not rewritten merely to erase prior states.

### 23.1 Explicit reconciliations
| Predecessor area | Successor treatment |
|---|---|
| Listing publication with stale Pending Review interpretation | Reconciled: normal Listing publication is not Pending Review-gated; unrelated account/application Pending Review may remain |
| Review with pre-publication Admin approval interpretation | Reconciled: Review → AUTO-APPROVE → Published/Viewable; moderation is post-publication |
| M13 Provider Catalogue Admin-curated wording | Reconciled to Superadmin-only mutation |
| M13 broad BYOK ownership | Reconciled to Agent/User / OWN |
| M11 incomplete public-surface inventory | Augmented to ten mandatory surfaces including Static Public Content and Announcement/Promotion |
| M03 Refresh | Augmented with current allowance, operational-day, frequency, failure, timestamp and audit behavior |
| M15 Learning ownership ambiguity | Reconciled: M04 owns Learning; M15 consumes qualifying evidence |

---
# 24. ORPHAN / COVERAGE CONTROL
## 24.1 Orphan semantic capability check
Every current M01–M15 delta identified for STEP13-C has a corresponding flow family or is explicitly classified as physical/traceability-only. Physical-only items such as Bank Master realization and runtime RLS proof are not falsely converted into semantic user-flow claims.

## 24.2 Orphan functional feature check
The accepted STEP13-B functional families are represented in module or cross-domain flows. Where a function is projection/communication-only, the flow explicitly preserves that boundary rather than inventing business mutation.

---
# 25. PHYSICAL / RUNTIME NON-BLOCKING BOUNDARY
- No endpoint ID is invented.
- No database table is invented.
- No permission ID is invented.
- No RLS SQL is invented.
- No migration execution is claimed.
- No deployment is claimed.
- Runtime authorization/RLS remains NOT VERIFIED.
- Physical/runtime gaps remain controlled/evidence-gated unless they expose a genuine semantic contradiction.

---
# 26. FLOW FINDING REGISTER / PROVENANCE
| ID | Finding | Classification | Resolution |
|---|---|---|---|
|C-F01|Legacy User Flow authority wording must not outrank accepted STEP13-B v2.3|CONTROLLED PROVENANCE|Treat predecessor W4-02A.6 material as preservation/reference; current successor chain governs.|
|C-F02|M01 Conditional KTP distinction requires explicit flow branch|CONTROLLED SEMANTIC PROPAGATION|Flow KTP as eligibility/requirement, not permission.|
|C-F03|M03 stale Pending Review publication interpretation|CONTROLLED RECONCILIATION|Use normal publish path without Pending Review gate.|
|C-F04|M03 Refresh contract requires full flow behavior|CONTROLLED AUGMENT|Include allowance/reset/frequency/failure/timestamp/audit and M14→M03→M10 boundary.|
|C-F05|M02 Review stale approval-gate interpretation|CONTROLLED RECONCILIATION|Use AUTO-APPROVE then Published/Viewable, with post-publication moderation.|
|C-F06|M06 Project/Marketing Kit/Claim flow propagation|CONTROLLED ADD-NEW/AUGMENT|Represent current semantic lifecycle and authorization boundaries without physical invention.|
|C-F07|M10 Permission Preset flow boundary|CONTROLLED MULTI-LAYER|Represent baseline/preset resolution without new IDs.|
|C-F08|M11 mandatory public surfaces|CONTROLLED MANDATORY DELTA|Explicitly include all ten surfaces.|
|C-F09|M13 Provider Catalogue/BYOK authority|CONTROLLED RECONCILIATION|Superadmin-only catalogue mutation; Agent/User-owned BYOK.|
|C-F10|M14 commercial/Refresh boundary|CONTROLLED CONTRACT UPDATE|Payment/entitlement/quota remain M14; M03 remains action authority.|
|C-F11|M15 Developer Learning evidence dependency|CONTROLLED TRACEABILITY|M04 evidence → M15 qualification/award path.|
|C-F12|Runtime/RLS verification absent|CONTROLLED NON-BLOCKING|Do not claim runtime proof.|
|C-F13|STEP13-A v3.7 package has internal top-title/version presentation drift|CONTROLLED PROVENANCE|Use accepted package/status lineage as upstream authority; do not alter upstream artifact here.|
|C-F14|M03 legacy listing behaviors were not explicit enough in v1.0 (owner-only update, publish-lock fields, Suspended, Sold/Rented search exclusion, media derivative/aspect-ratio rules, no regional Refresh quota)|CONTROLLED SEMANTIC FLOW COMPLETENESS|Rebuilt M03 flow with these current requirements.|
|C-F15|M01 Verification Document scope/non-public behavior and exact deferred-KTP activation path were underrepresented|CONTROLLED SEMANTIC FLOW COMPLETENESS|Added verification-document flow and `ISI NANTI` → `DEFERRED/NOT_PROVIDED` → `ACTIVE` → `HOME` branch.|
|C-F16|M10 Permission Preset actor governance/effective-resolution branches were under-specified|CONTROLLED AUTHORIZATION FLOW COMPLETENESS|Added Superadmin/Manager-Agent target boundaries, mismatch fail-closed and preset resolution.|
|C-F17|M12 invitation/Join Request state machines and Organization Listing closure resolution were under-specified|CONTROLLED FLOW COMPLETENESS|Added explicit invitation/request branches and closure resolution controls.|
|C-F18|M13 provider connection lifecycle/outage/retirement behavior was under-specified|CONTROLLED FLOW COMPLETENESS|Added lifecycle/state and outage/retirement branches.|
|C-F19|M14 trusted payment/order snapshot/refund-reversal commercial states were under-specified|CONTROLLED COMMERCIAL FLOW COMPLETENESS|Added explicit commercial state and verification/snapshot/reversal behavior.|
|C-F20|Legacy Core User Flow included valid taxonomy/context/transfer/DBR/AI constraints not explicitly surfaced in v1.0|CONTROLLED PRESERVATION COMPLETENESS|Added explicit legacy preservation controls without reviving superseded behavior.|

---
# 27. SECOND FULL DEEP SCAN PROTOCOL
After the whole User Flow artifact is generated, the complete artifact and package must be scanned again for:
- all required M01–M15 flow families;
- all ten M11 mandatory public surfaces;
- M03 no-Pending-Review normal publication wording;
- M03 Refresh invariants;
- M02 AUTO-APPROVE/post-publication moderation wording;
- M10 Permission Preset boundary;
- M14 Q01–Q64 boundary, including Q40/Q54/Q61/Q62;
- M04 vs M15 authority separation;
- M14 → M03 → M10 Refresh authority chain;
- Core immutability / no in-place mutation language;
- absence of invented endpoint/table/permission/RLS/runtime success claims;
- presence of required matrices, findings, provenance and gate result.

---
# 28. STEP13-C FINAL GATE
**Result: PASS WITH CONTROLLED RESIDUALS — FULL REBUILD v1.1 / SECOND FULL DEEP SCAN CLEAN**

Acceptance:
- User Flow is current and is not merely the frozen Core v1.3 flow.
- All valid inherited flow paths are preserved.
- All valid M01–M15 flow additions/changes are integrated or explicitly classified.
- No blocking semantic flow contradiction remains.
- Authority boundaries remain aligned with M01–M15.
- Physical/runtime proof is not used as a semantic blocker.
- No unsupported endpoint, table, permission ID, RLS SQL, migration or runtime proof is invented.
- STEP13-D is the next substantive stage.

### Handoff
**STEP13-D — Technical Specification Synchronization = READY**
STEP13-D must consume this accepted User Flow together with accepted STEP13-B Functional v2.3, STEP13-A PRD v3.7, STEP08–STEP12 baselines, current M01–M15 authorities, and frozen Core v1.3. STEP13-D must continue PRESERVE / AUGMENT / ADD-NEW / UPDATE-RECONCILE and keep physical/runtime proof evidence-gated.

---
# 29. SOURCE / VERSION CONTROL
Execution date: 2026-09-07
Current source uploads: 10 (9 ZIP + 1 Markdown)
Recursive archive member instances: 3215
Nested ZIP instances: 118
Leaf artifacts after recursive expansion: 3097
Text-bearing leaf artifacts: 2704
Text characters scanned: 33,462,363
ZIP integrity errors: 0

### Current source SHA256
| Source | SHA256 |
|---|---|
|STEP13-C_SUCCESSOR_INTEGRATED_USER_FLOW_FULL_REBUILD_PACKAGE_v1.0.zip|73890b944d92ad69542c3ba846dad28f9d12add336ea45d02a7e18fb4e8f3093|
|STEP13-B_SUCCESSOR_INTEGRATED_FUNCTIONAL_SPECIFICATION_FULL_REBUILD_PACKAGE_v2.3.zip|baaad2c438842737a762b54881fff29353a2a47a6138a82389ba81b1a33ff50b|
|STEP13-A_SUCCESSOR_INTEGRATED_PRD_FULL_REBUILD_PACKAGE_v3.7.zip|cc6b8e88c26d3e8faf399232a886721a3fd394e7649773524e2b7f04283e282a|
|STEP13-00_INPUT_DEEP_SCAN_CURRENTNESS_AUTHORITY_GATE_FULL_v1.1_CORRECTED_REBUILT_20260906.md|39702521d7e6ad0838a75a4cd8fe36201152ff57199e59668f4e486945e04b2e|
|M01-M15 new recon(20260906-155950).zip|91354375da7c57257a7c4ef7da0aae3e26fc832f424d55d78dde8956dc7a54d7|
|STEP SYNC CORE(20260906-155940).zip|0474fe3e7f2461e2d68217838075741f27f01b411ab084c33db0a9d196425872|
|Utama core RUMAHAGEN_WIREFRAME_CORE_FINAL_SOURCE_PACK_v1.3(9)_GOVERNANCE_CORRECTED_STEP0_RESIDUAL_FIXED(20260906-155940).zip|7c491ce312a42f7d4debd77a4533a895dd35a71ad7464053c0bfe61639ba72e6|
|Step11 Sync core(9).zip|db6d96c9e0f9b9d22b17e44ffbdf00791b6eef8ccdc191c348f5fdb021f92826|
|pre-00 gate(20260906-155935).zip|f241d2cc281168a25767d938b954c3fd84ab9e51dbfeb072116449f2507b8751|
|step12 sync core.zip|91dbdadea5f00bc9d3aab3f7eb2f9fa9be5177620599b1ec01d393ddc2d069eb|

### Accepted upstream artifacts
- STEP13-B Functional v2.3: accepted upstream input; source package hash recorded above.
- STEP13-A PRD v3.7: accepted upstream input; source package hash recorded above.
- STEP13-00 v1.1: PASS WITH CONTROLLED RESIDUALS / STEP13-A previously accepted.
- STEP13-C v1.0: predecessor User Flow artifact; used only as the immediate rebuild baseline and preservation input.

# 30. END-OF-STEP RESPONSE
STEP13-C has been executed as a whole-artifact User Flow rebuild. The flow is the behavioral bridge from accepted Functional to downstream Technical/UI/UX stages. Core v1.3 remains immutable. Controlled residuals remain evidence-gated and non-blocking unless a future source proves a semantic contradiction.
