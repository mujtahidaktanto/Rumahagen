# RUMAHAGEN — ROLE_AUTHORIZATION_AWARE_FLOW_MATRIX_v1.1

# 21. ROLE / AUTHORIZATION-AWARE FLOW MATRIX
| Actor | Representative flow | Scope/condition | Denied behavior |
|---|---|---|---|
|Guest|Public discovery; supported Event Guest registration|Public/Guest-supported resource|Protected/unauthorized actions denied|
|Agent/User|Profile, Listing, Learning, BYOK, commercial, qualification journeys|Personal ownership plus permitted organization scope|No capability outside resolved authorization|
|Developer|Developer/Project/Media/Marketing Kit/Claim flows|Own scope for Developer/Marketing Kit; governed project/claim scope|No cross-scope mutation|
|Manager|Organization/context and permitted view/operate flows|Resolved organization/scope|No action outside baseline/scope|
|Partner|Partner Learning/session/content flows where supported|Partner scope|No unsupported ownership or mutation|
|Buyer|Public discovery, supported review/event/commercial journeys|Own permitted interactions|No administrative/domain mutation|
|Admin|Moderation, configuration, audit, supported administrative operations|Admin scope|No Superadmin-only operation|
|Superadmin|Superadmin-scoped administration and Provider Catalogue mutation|Superadmin scope|Still subject to domain boundary; no super-domain ownership|

**Authorization note:** the matrix expresses flow behavior, not newly invented permission IDs. Effective authorization remains the accepted STEP12 model.

---
