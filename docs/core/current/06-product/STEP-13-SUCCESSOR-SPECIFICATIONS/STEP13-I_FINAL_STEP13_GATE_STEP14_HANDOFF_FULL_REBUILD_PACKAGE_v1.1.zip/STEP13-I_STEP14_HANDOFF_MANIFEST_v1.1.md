# STEP13-I — STEP14 HANDOFF MANIFEST v1.1

STEP14 receives: frozen Core v1.3 reference/provenance, accepted M01–M15 semantic evidence, STEP13-00/A/B/C/D/E/F/G outputs, H v1.1 preservation/traceability, and the fully materialized STEP13-I successor candidate v1.1.

STEP14 must continue the four-case model and must not revert valid current M01–M15 decisions or delete valid Core detail merely because a current M01–M15 delta does not repeat it. Physical/runtime residuals remain evidence-gated.
