# STEP13-G — GLOBAL CONFLICT & RECONCILIATION REGISTER v1.1

| ID | Finding | v1.1 correction | State |
|---|---|---|---|
| G-01 | STEP13-D stale predecessor authority wording | Canonicalized A v3.7/C v1.1 at G layer | RECONCILED |
| G-02 | STEP13-A internal v3.6 vs supplied v3.7 identity | v3.7 canonicalized at G layer; v3.6 retained only as source provenance | RECONCILED |
| G-03 | STEP13-E internal v3.0 vs supplied v3.1 identity | v3.1 canonicalized at G layer; v3.0 retained only as source provenance | RECONCILED |
| G-04 | Static Public Content missing from frozen Core M11 enumeration | Explicit G12-C11 successor target | CONTROLLED |
| G-05 | Announcement/Promotion lifecycle incomplete in frozen Core | Explicit G12-C12 successor target | CONTROLLED |
| G-06 | Physical/runtime proof not blanket-established | Evidence-gated rule retained | CONTROLLED |
| G-07 | v1.0 M01–M15 treatment too broad for several locked deltas | Complete module delta matrix added in v1.1 | RECONCILED |
| G-08 | v1.0 Core audit listed only two M11 gaps | Full G12-C01…C17 Core propagation audit added | RECONCILED |
| G-09 | v1.0 final gate claimed clean while material module/Core propagation details were omitted | Gate now explicitly requires complete M01–M15 and G12-C01…C17 coverage | RECONCILED |
