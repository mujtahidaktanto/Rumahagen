# STEP13-G — CROSS-DOMAIN DEPENDENCY & HANDOFF MATRIX v1.1

| Dependency | Direction | Authority rule | Status |
|---|---|---|---|
| M01 → M02 | Identity/activation → visibility | M01 identity; M02 public representation | PRESERVE |
| M02 → M11 | Visibility → discovery/measurement | M11 only eligible public representation | PRESERVE |
| M14 → M03 → M10 | Commercial allowance → action enforcement → authorization | No authority inversion | PRESERVE |
| M04 → M15 | Learning evidence → qualification | M04 learning; M15 qualification | PRESERVE |
| M05 → M11 | Event/participant semantics → measurement segmentation | Measurement cannot create registration/identity | PRESERVE |
| M06 → M03/M11 | Project/Claim dependency → listing/public representation | M06 does not grant M03 ordinary action authority | PRESERVE |
| M09 → M11 | Content lifecycle → public discovery | M09/applicable owner lifecycle; M11 discovery | PRESERVE |
| M12 → M11 | Organization lifecycle → public representation | Membership ≠ ownership/entitlement | PRESERVE |
| M13 → M11 | Provider outcomes → measurement | No secrets/credentials propagation | PRESERVE |
| M14 → M11 | Commercial promotion truth → public observation | M14 commercial truth; M11 observes eligible public surface | PRESERVE |
| M08 ← domains | Domain outcome → projection | M08 cannot mutate domain authority | PRESERVE |
