# STEP13-G — M01–M15 CROSS-DOMAIN AUTHORITY MATRIX v1.1

| Module | Authority | STEP13-G complete delta treatment |
|---|---|---|
| M01 | Identity/authentication/activation | OTP success → ACTIVE; Conditional KTP/deferred KTP supported; KTP is eligibility/private data, not RBAC/public discovery — **AUGMENT** |
| M02 | Profile/public visibility/reviews/outcome presentation | Public visibility gates public representation; Review AUTO-APPROVE; moderation is post-publication; no default approval gate for normal listing inferred — **AUGMENT** |
| M03 | Listing lifecycle/Refresh action | Normal Listing publication has no default Pending Review; Refresh action semantics remain M03; receives commercial allowance from M14 and authorization from M10 — **PRESERVE + AUGMENT** |
| M04 | Learning/Learning Economy | Learning completion/reward remains M04; capability concepts include Skill Verify/Issue/Manage, Learning Economy Redemption, LearningPath Configure/Progression Manage, Credential Issue/Manage, Learning Reconciliation; no invention of exact routes — **AUGMENT** |
| M05 | Event/Registration/participant_mode/Guest | participant_mode affects journey/measurement segmentation; Guest registration allowed; Guest email is notification/contact destination, not canonical identity; Event-start notifications; Event ≠ Session; Host ≠ Instructor — **AUGMENT** |
| M06 | Developer/Project/media/Marketing Kit/Claim | Developer includes company_logo and Tentang Developer; Project Media photo/video only; Marketing Kit permissions locked; Claim/Approval Claim; Approved Claim → Agent-owned Listing initialization, without granting ordinary M03 authority — **AUGMENT** |
| M07 | DBR | DBR remains M07 authority; Bank Master physical realization remains evidence-gated; analytics cannot become DBR truth — **PRESERVE + RECONCILE** |
| M08 | Dashboard/Notification projection | Projection/communication only; no business mutation authority; notification state/dismiss/delivery completeness remains domain-owned — **PRESERVE + AUGMENT** |
| M09 | Administration/configuration/content lifecycle | Static Public Content and Announcement/Promotion lifecycle/configuration; System Configuration; Administrative Audit/Export; Review/Escalate/Manual Correction boundaries — **AUGMENT** |
| M10 | Authorization/RBAC/RLS | Role = actor grouping; Role Permission = baseline; Permission Preset = optional configurable authorization for an existing Role only; cannot create roles/capabilities outside baseline — **AUGMENT** |
| M11 | Public discovery/SEO/tracking/measurement | Ten mandatory public surfaces; M11 owns discovery/SEO/measurement, not lifecycle; analytics observational; visibility-aware measurement — **PRESERVE + COMPLETE** |
| M12 | Organization/membership/context | Lead Exit → CLOSING → CLOSED; no successor privilege inheritance; membership ≠ ownership/entitlement/Host/Instructor; Organization public representation follows M12 lifecycle — **AUGMENT** |
| M13 | Provider/BYOK | Provider Catalogue mutation Superadmin-only; BYOK Agent/User OWN; lifecycle includes controlled disconnect/revoke/disable states; analytics never exposes secrets — **AUGMENT** |
| M14 | Commercial/payment/entitlement/quota/promotion | Canonical commercial lifecycle; configurable Daily Refresh Allowance; payment ≠ entitlement ≠ RBAC; Q01–Q64 remain M14; M14 commercial truth → M03 enforcement → M10 authorization — **AUGMENT** |
| M15 | Qualification/evidence/award/title | Consumes governed evidence; Developer Learning evidence originates through M04; M15 owns qualification/award/title; does not absorb M04 or M14 Q01–Q64 — **AUGMENT** |

**Q01–Q64 remain M14. M15 does not absorb them. Core v1.3 remains immutable.**
