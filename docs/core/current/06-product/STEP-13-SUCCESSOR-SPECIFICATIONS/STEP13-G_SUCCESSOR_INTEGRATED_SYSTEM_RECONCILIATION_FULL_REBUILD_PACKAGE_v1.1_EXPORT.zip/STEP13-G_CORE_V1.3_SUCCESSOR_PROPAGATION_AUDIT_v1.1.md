# STEP13-G — CORE v1.3 SUCCESSOR PROPAGATION AUDIT v1.1

| ID | Domain | Gap | Class | Required successor treatment |
|---|---|---|---|---|
| G12-C01 | M01 | OTP→ACTIVE vs frozen Core stale Pending Review/agent approval wording | RECONCILIATION-REQUIRED | Successor baseline must use M01 current activation authority; frozen Core unchanged |
| G12-C02 | M02 | Current public profile presentation/visibility delta not explicitly enumerated | EVIDENCE-RESIDUAL | Carry current M02 public visibility semantics into successor candidate; frozen Core unchanged |
| G12-C03 | M03 | Refresh action API-237 not evidenced in frozen Core | API-RESIDUAL | Carry Refresh semantics only; exact API identifier remains evidence-gated |
| G12-C04 | M04 | Learning Path configuration/progression, Skill/Credential lifecycle, LP Redemption/reconciliation not exact in Core | API-RESIDUAL | Carry semantic capability coverage; no route invention |
| G12-C05 | M05 | Guest registration/participant_mode exact physical representation incomplete | PHYSICAL-RESIDUAL | Carry semantic Guest/participant_mode; physical realization downstream |
| G12-C06 | M06 | Developer company logo/Tentang Developer + Project/Media/Marketing Kit/Claim delta not explicit in Core | EVIDENCE-RESIDUAL | Carry current M06 semantic delta into successor candidate |
| G12-C07 | M07 | DBR/admin authorization alignment needs explicit reconciliation | RECONCILIATION-REQUIRED | Preserve M07 authority; no transfer to M11 |
| G12-C08 | M08 | Notification state/dismiss/delivery mutation family incomplete | API-RESIDUAL | Carry M08 projection/communication semantics; exact API remains gated |
| G12-C09 | M09 | Notification Template/Content Configuration ADD-NEW absent from Core | API-RESIDUAL | Carry M09 administrative configuration concept only where evidenced |
| G12-C10 | M10 | Permission Preset exact model absent from Core | RLS-RESIDUAL | Carry semantic model; no new Role/capability; physical/RLS downstream |
| G12-C11 | M11 | Static Public Content absent from Core M11 discovery enumeration | API-RESIDUAL | Mandatory public surface; successor propagation target; no Core edit |
| G12-C12 | M11 | Announcement/Promotion lifecycle representation incomplete | API-RESIDUAL | Mandatory public surface; M14 commercial truth and M09 lifecycle; successor target |
| G12-C13 | M12 | Organization Settings/revoke/cancel/enforcement operation family incomplete | API-RESIDUAL | Carry M12 lifecycle semantics; exact mutation routes downstream |
| G12-C14 | M13 | Provider Catalogue mutation + force revoke/disconnect/disable exact routes not evidenced | API-RESIDUAL | Carry lifecycle/authority semantics; no route invention |
| G12-C15 | M14 | daily_refresh_allowance and current commercial contract absent/incomplete in Core | PHYSICAL-RESIDUAL | Carry configurable allowance/commercial semantics; Q01–Q64 remain M14 |
| G12-C16 | M15 | Detailed authority-scope/path-rule/version/condition/prerequisite operations incomplete | API-RESIDUAL | Carry M15 semantic authority; exact mutation contract gated |
| G12-C17 | GLOBAL | No distinct Integrated Core candidate artifact evidenced in uploaded corpus | EVIDENCE-RESIDUAL | STEP13-G must not fabricate candidate; downstream successor-core integration required |

**No frozen Core v1.3 edit is permitted. G12-C01…C17 are successor propagation targets / evidence residuals.**
