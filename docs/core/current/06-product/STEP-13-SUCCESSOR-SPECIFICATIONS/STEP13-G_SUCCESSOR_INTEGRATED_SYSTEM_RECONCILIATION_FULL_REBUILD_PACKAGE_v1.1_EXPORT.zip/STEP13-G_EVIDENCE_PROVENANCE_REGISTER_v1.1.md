# STEP13-G — EVIDENCE & PROVENANCE REGISTER v1.1

| ID | Source basis | Decision | Class | Treatment |
|---|---|---|---|---|
| E-01 | Uploaded A–F chain | Successor chain current through F v1.1 | Documentary | PRESERVE |
| E-02 | Core sync evidence | Core v1.3 frozen | Governance | PRESERVE |
| E-03 | Current M01–M15 corpus | Complete module authority deltas | Semantic | AUGMENT |
| E-04 | Core sync G12-C01…C17 | 17 successor propagation targets | Core propagation | CONTROLLED |
| E-05 | STEP13-F v1.1 | Ten M11 surfaces | Semantic | PRESERVE |
| E-06 | STEP13-F v1.1 | Static Public Content + Announcement/Promotion | Semantic/Core propagation | CONTROLLED |
| E-07 | Current M03/M14/M10 | Refresh chain and allowance | Semantic/authorization | PRESERVE |
| E-08 | Current M04/M15 | Learning evidence → qualification | Semantic | PRESERVE |
| E-09 | Current M10 | Permission Preset | Authorization | PRESERVE |
| E-10 | Current M12/M13/M14 | Lifecycle/Provider/Commercial deltas | Semantic | AUGMENT |
| E-11 | Upstream documentary discrepancies | A v3.6/v3.7, E v3.0/v3.1, D stale wording | Documentary | RECONCILE at G layer |
| E-12 | Full uploaded corpus | Runtime/production proof not blanket-established | Physical/runtime | EVIDENCE-GATED |
