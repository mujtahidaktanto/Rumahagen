# STEP13-A — SUCCESSOR INTEGRATED PRD
## Full Version v3.6 — PRD Synchronization / Whole-Artifact Rebuild

**Execution date:** 2026-09-06  
**Mode:** FULL VERSION / WHOLE-ARTIFACT REBUILD / NOT PATCH / NOT APPEND  
**Source boundary:** current uploaded source corpus only; no web/external source used.  
**Frozen baseline:** Core v1.3 — immutable/reference only.  
**Integration model:** PRESERVE / AUGMENT / ADD-NEW / UPDATE-RECONCILE / explicit SUPERSEDED only with evidence.

**STEP13-A-00:** PASS — STEP13-00 v1.1 accepted; STEP13-A ready.

RUMAHAGEN — PRODUCT REQUIREMENTS DOCUMENT (PRD)
Version 3.6 — STEP13-A Successor Integrated PRD Full Rebuild
06 September 2026 | STEP13-A SUCCESSOR / CONTROLLED GREEN
Predecessor: Core PRD v2.1 — W4-02A.6.11 Full Current Consolidation. Core v1.3 remains frozen. This artifact is a new full current version, not a patch or delta.
0. EXECUTIVE PRODUCT BASELINE
RumahAgen is a property-agent platform whose product model combines the original M01–M13 baseline with governed Commercial/Payment, Learning Economy, Learning Session, Title/Awarding and Organization semantics. Product requirements remain downstream of approved governance and normative business rules.
1. PRODUCT VISION, OBJECTIVES & ACTORS
1.1 Objectives
Enable independent-first agent onboarding and professional property operations.
Provide Personal + Organization collaboration without removing Personal Context.
Provide listing, developer collaboration and DBR pre-screening capabilities.
Provide Internal Learning Economy with free progression, earned LP, optional paid acceleration and assessment-based certification.
Provide governed Commercial/Payment capabilities without conflating payment, entitlement and authorization.
Provide governed Title/Awarding and Learning Session capabilities with explicit historical/provenance boundaries.
Provide SEO/Analytics for public discovery and measurement without creating a parallel business-authority layer.
Provide AI BYOK assistance without allowing AI to become business, authorization, payment, completion, awarding or credential authority.
1.2 Actors / Contexts
2. CANONICAL PRODUCT STRUCTURE
3. PRODUCT-WIDE REQUIREMENT INVARIANTS
Business behavior must trace to BR-001–BR-151 and approved Commercial BR where applicable.
Subscription, Entitlement and RBAC are separate product concepts.
Entitlement ≠ Role; Entitlement ≠ Permission; Payment Success ≠ Permission Grant.
Payment success must not directly mutate RBAC/application permissions.
Commercial Entitlement is authoritative for commercial capability/quota capacity.
Payment fulfillment requires verified confirmation and idempotent processing; duplicate provider events cannot create duplicate commercial outcomes.
Reconciliation detects/assesses/audits inconsistencies; it does not silently authorize automatic remediation.
Historical purchase snapshots are commercial-complete and immutable after confirmed transaction.
Configurable commercial parameter changes do not rewrite historical purchases.
Learning Activity completion is distinct from LP transaction, progression, competency, credential and Award.
Pay-to-Accelerate must never become Pay-to-Pass.
Learning Session does not create official LP transactions directly.
Course Enrollment, Event Registration and Session Enrollment remain distinct.
Provider evidence is normalized/idempotent evidence with provenance; raw provider events are not canonical attendance/completion outcomes.
Title Definition and Award Instance are distinct; qualification determines applicable rule version and Award snapshots the applicable rule.
Role + Permission + Scope authorizes action; qualification determines eligibility.
Host and Instructor remain separate capabilities.
AI assistance cannot become authority for payment, entitlement, authorization, attendance, completion, LP, competency, credential or Title/Award.
Dashboard, notification and analytics are aggregation/side-effect surfaces, not domain authorities.
Public SEO must not expose private/sensitive authorization or commercial data.
4. MVP COMMERCIAL PRODUCT SCOPE
The approved MVP monetization scope is limited to the following surfaces; this PRD does not infer additional monetization mechanisms.
Listing quota add-on packages.
Learning Point packages.
Free membership.
Pro monthly subscription.
Pro annual subscription.
Paid listing boost / premium promotion.
Paid internal RumahAgen Learning classes.
Paid partner Learning classes.
4.1 Commercial product requirements
Commercial catalog must represent approved plans, add-ons and promotions.
Subscription lifecycle must support approved personal Agent and Organization commercial relationships.
Commercial Entitlement remains the authority for commercial capacity/access outcomes.
Order/Checkout precedes payment confirmation.
Payment uses provider-independent Payment Core and Provider Adapter boundaries.
Verified payment confirmation and idempotency are prerequisites to commercial fulfillment.
Promotion validity, purchase terms and historical purchase snapshots must be preserved according to approved Commercial BR.
Permanent and promotional add-ons remain semantically distinct.
Agency quota capacity, operational pool, member allocation and actual usage remain distinct concepts.
Refund/chargeback events are represented separately from ordinary payment success; exact customer policy remains downstream where not governed.
Commercial reconciliation is first-class and auditable.
Commercial audit/history preserves provenance.
4.2 Beta activation boundary
Commercial infrastructure may be architecture-ready while commercial functionality remains inactive during free beta.
Activation is controlled and does not require redesign of the Commercial core.
No payment provider activation is claimed by this PRD.
5. MODULAR PRODUCT REQUIREMENTS
M01 — Registration & Authentication

### Successor synchronization — M01 Identity / Authentication / Verification
- M01 remains the semantic identity/authentication foundation: registration, OTP, login/logout, password recovery, session mechanisms, verification-document intake and Agent activation.
- **Agent account activation is immediate after **Successful OTP verification**:** Register → OTP verification → Account ACTIVE → general feature access. Normal account activation does not wait for Admin approval/Pending Review.
- KTP is an eligibility/requirement condition, **not an RBAC permission** and not an authorization capability.
- Conditional KTP / deferred completion is supported: after OTP verification and activation, an Agent may choose `ISI NANTI`; KTP becomes `DEFERRED / NOT_PROVIDED`, the account remains ACTIVE, and missing/deferred KTP does not create `PENDING_REVIEW` or an account-activation approval gate.
- KTP remains an outstanding capability-specific requirement where a later capability explicitly requires KTP; deferred does not mean completed or permanently waived.
- Verification Document Create is same-user `OWN`; View is protected NON-PUBLIC identity information; Review is an Admin responsibility.
- Public profile visibility remains M02 authority.
- Physical permission IDs, API identifiers, RLS enforcement and runtime PASS remain downstream/evidence-gated.
- M01 is the semantic identity/authentication foundation: registration, OTP, login/logout, password recovery, session mechanisms, verification-document intake and Agent activation.
- Verification Document Create is same-user OWN; View is protected NON-PUBLIC identity information; Review is an Admin responsibility.
- KTP is an eligibility/requirement condition, not an RBAC permission and not an authorization capability.
- Conditional KTP / deferred completion is supported where the current M01 decision permits it. Deferred does not mean completed and does not itself trigger Pending Review.
- Successful OTP/activation and KTP eligibility remain distinct. Public profile visibility remains M02 authority.
- Physical permission IDs, API identifiers, RLS enforcement and runtime PASS remain downstream/evidence-gated.
Self-service agent registration using approved email/phone verification flow.
Login/logout/session management and password recovery.
Optional Google SSO remains subject to the approved current product/authentication baseline; no unsupported SSO provider is invented.
Agent verification/document submission remains part of onboarding where required.
Account activation for the Agent flow is immediate after successful OTP; `PENDING_REVIEW` is not the default Agent activation state. Workflow-specific Pending Review uses may remain only where separately governed and must not be interpreted as an Agent activation prerequisite.
M02 — Agent Profile

### Successor synchronization — M02 Profile / Public Visibility / Reviews / Outcome Presentation
- M02 owns professional profile, public visibility, public CTA and review presentation; M01 remains identity authority.
- Default Agent profile visibility is PUBLIC unless changed by the Agent to PRIVATE.
- **Public CTA requires explicit Agent opt-in**; a contact number not selected for public CTA is not automatically public.
- **Only Superadmin may administratively override another Agent's profile visibility or Public/WhatsApp CTA**; Manager/Admin do not receive that override merely from role.
- Review submission is **AUTO-APPROVED**; Admin moderation is post-publication and is **not an approval gate**.
- Valid moderation capability is preserved; only the pre-publication approval interpretation is superseded.
- Outcome Presentation is explicitly non-owning and may present authoritative Learning/Award/Organization outcomes without mutating or redefining them.
- Legal/verification information remains NON-PUBLIC under M01.
- M02 owns professional profile, public visibility, public CTA/override semantics and review presentation; M01 remains identity authority.
- Profile visibility is distinct from authentication and authorization.
- Review submission is AUTO-APPROVED; Admin moderation is post-publication and is not an approval gate.
- Valid moderation capability is preserved; only the pre-publication approval interpretation is superseded.
- Outcome Presentation is explicitly non-owning: it presents authoritative outcomes without mutating/redefining Learning, Award, Organization or other source-domain outcomes.
Agent maintains professional profile and public profile where permitted.
Profile supports reviews/recognition presentation according to current Awarding and authorization boundaries.
Personal Context remains separate from Organization Context.
M03 — Listing

### Successor synchronization — M03 Listing / Publication / Refresh / Media Delivery
- M03 owns ordinary Listing lifecycle, ownership and action authority.
- Normal Listing publication is `DRAFT → PUBLISHED`; there is no Pending Review approval gate for normal Listing publication.
- After first successful publication, `address`, `property_type`, `land_area` and `building_area` remain permanently locked, including after Expired → Draft.
- Sold/Rented Listings remain historical and excluded from public search/discovery while contributing to Agent-profile historical counters.
- The commercial parameter **`daily_refresh_allowance`** is configurable; default = **5 successful Refreshes per Agent per operational day**.
- Operational day = **Asia/Jakarta**; reset is at the next operational-day boundary, not rolling 24-hour; unused allowance has **no carry-forward**.
- The Agent may distribute the daily allowance across eligible Listings, subject to the per-Listing limit.
- Each eligible Listing may be successfully Refreshed at most once per operational day.
- Successful Refresh is a District-local ranking/repositioning signal only; it does not mutate province/city/regency/district/area/latitude/longitude.
- District-local ordering uses latest successful Refresh order; timestamp ties use first-recorded Refresh action; `listing_id ASC` is only the final deterministic fallback when authoritative event order is indistinguishable.
- Server transaction time/order is authoritative; client-supplied time cannot control ordering.
- Failed Refresh consumes zero allowance, does not change ranking position and does not update `last_refreshed_at`.
- Successful Refresh updates timestamp/order, consumes one allowance unit and records audit provenance using the existing audit mechanism.
- Refresh does not create regional Refresh quota and does not guarantee global #1 ranking outside the defined District-local ordering.
- Where applicable effective freshness is `MAX(published_at, last_refreshed_at)`.
- **M14 commercial allowance/entitlement → M03 Listing/Refresh action enforcement → M10 authorization.** M14 does not own the Listing Refresh action.
- Search/card media uses optimized thumbnail/card derivatives rather than original Listing images where a derivative is required.
- Media derivatives preserve aspect ratio; **image stretching is prohibited**, including cover-image presentation; crop/cover or contain/letterbox behavior applies as appropriate.
- Exact endpoint IDs and physical schema realization remain downstream/evidence-gated.
- M03 owns ordinary Listing lifecycle, ownership and action authority.
- Normal Listing publication is DRAFT → PUBLISHED; there is no Pending Review approval gate for normal Listing publication.
- After first successful publication, address, property_type, land_area and building_area remain permanently locked, including after Expired → Draft.
- Sold/Rented Listings remain historical and excluded from public search/discovery while contributing to Agent-profile historical counters.
- Default Refresh allowance = 5 successful Refreshes per Agent per operational day, configurable rather than hardcoded.
- Operational day = Asia/Jakarta; reset is day-boundary based, not rolling 24-hour; unused allowance has no carry-forward.
- Each eligible Listing may be successfully Refreshed at most once per operational day.
- Successful Refresh repositions the Listing only within its existing District and does not mutate province/city/district/area/latitude/longitude.
- Server transaction timestamp/order is authoritative; equal timestamps use first-recorded action first, with listing_id ASC only if event ordering remains indistinguishable.
- Failed Refresh consumes zero allowance, does not change position and does not update last_refreshed_at.
- Successful Refresh updates timestamp/order, consumes allowance and records audit provenance.
- M14 commercial allowance/entitlement → M03 Listing/Refresh action enforcement → M10 authorization. M14 does not own the Listing Refresh action itself.
Agent can create/manage listings subject to listing business rules and authorization.
Listing supports CRUD, moderation, search/filter/map, lifecycle, price history, leads/views and approved public discovery.
Personal Listing remains outside Agency lifecycle.
Agency Listing respects current Organization context, ownership, origin and transfer rules.
Listing lifecycle follows BR-001–BR-151; commercial quota/promotion behavior follows approved Commercial BR.
M04 — Learning Center / Learning Economy / Session

### Successor synchronization — M04 Learning / Learning Economy / Learning Session
- M04 remains semantic authority for Learning, Learning Economy and Learning Session.
- Current M04 v1.2 records **51/51 canonical decisions RESOLVED / LOCKED**; retained older OPEN/conflict records are historical/provenance, not active blockers.
- Learning Activity remains the canonical completion/reward boundary.
- Learning Economy remains free-to-learn with earned LP, optional paid acceleration and assessment-based certification; purchased LP cannot directly purchase competency and Pay-to-Accelerate never becomes Pay-to-Pass.
- Learning Points retain transaction/provenance semantics; earned and purchased LP remain distinguishable.
- Learning Session is an extension of Learning; Session Enrollment is distinct from Course Enrollment and Event Registration.
- Session taxonomy remains BROADCAST / INTERACTIVE / ON_DEMAND; Session Enrollment lifecycle remains PENDING → ACTIVE → COMPLETED.
- Authorized ACTIVE enrollment is required for eligible provider session access; provider events are normalized/idempotent evidence and do not directly establish canonical attendance/completion.
- Session completion is distinct from Learning Activity completion and does not itself directly grant rewards/credentials/Awards.
- Host and Instructor remain separate capabilities; no automatic inheritance.
- M15 may consume Learning-owned evidence for qualification, but M15 does not redefine Learning authority.
- M04 remains semantic authority for Learning, Learning Economy and Learning Session.
- Current M04 v1.2 records 51/51 canonical decisions RESOLVED / LOCKED; retained older OPEN/conflict records are historical/provenance, not active blockers.
- Learning Activity remains the canonical completion/reward boundary.
- Learning Economy remains free-to-learn with earned LP, optional paid acceleration and assessment-based certification; purchased LP cannot directly purchase competency and Pay-to-Accelerate never becomes Pay-to-Pass.
- Learning Points retain transaction/provenance semantics; earned and purchased LP remain distinguishable.
- Learning Session is an extension of Learning. Session Enrollment is distinct from Course Enrollment and Event Registration.
- Session taxonomy remains BROADCAST / INTERACTIVE / ON_DEMAND; Session Enrollment lifecycle remains PENDING → ACTIVE → COMPLETED.
- Authorized ACTIVE enrollment is required for eligible provider session access. Provider events are normalized/idempotent evidence and do not directly establish canonical attendance/completion.
- Session completion is distinct from Learning Activity completion and does not itself directly grant rewards/credentials/Awards.
- Host and Instructor remain separate capabilities; no automatic inheritance.
- M15 may consume Learning-owned evidence for qualification, but M15 does not redefine Learning authority.
Learning provides course/lesson/quiz/enrollment/completion experiences.
Internal Learning Economy supports free progression, earned LP, optional paid acceleration and assessment-based certification.
Learning Activity is the canonical completion/reward boundary.
Learning Points have transaction/provenance semantics; purchased LP is distinguishable from earned LP.
Paid LP cannot bypass assessment or purchase competency.
Learning Session is an extension of Learning and exposes eligible sessions within Learning context.
Session taxonomy = BROADCAST, INTERACTIVE, ON_DEMAND.
Session Enrollment is distinct from Course Enrollment and Event Registration.
Session Enrollment lifecycle distinguishes PENDING, ACTIVE and COMPLETED.
Only authorized ACTIVE enrollment may resolve provider session access.
Provider abstraction is provider-neutral; provider identity remains infrastructure.
Participation evidence is normalized/idempotent with provenance.
Attendance and completion are evaluated under governed policy; provider events do not directly establish canonical outcomes.
Qualifying session completion may feed Learning Activity, but Session does not own LP/credential/Award authority.
Where assessment is required, session completion cannot bypass assessment.
Paid session access consumes trusted Commercial/Payment outcomes and does not duplicate payment/entitlement logic.
Learning Session provider switching preserves semantic session identity, enrollment, evidence and outcome history; no automatic failover is assumed.
AI may assist session/learning experience but cannot become attendance/completion/LP/credential/Award authority.
M05 — Event / Calendar

### Successor synchronization — M05 Event / Calendar / Registration
- M05 remains Event/Calendar and Registration authority.
- Event Registration remains distinct from Learning Session Enrollment.
- `participant_mode` remains an M05 participant semantic and must not be reinterpreted by another module.
- Guest registration is supported where current M05 semantics permit it; Guest email is a notification/contact destination.
- Successful Guest registration confirmation may include the available Event/meeting link; if no link is available, confirmation remains confirmation-only and no link is fabricated.
- Event-start notification applies to Registered and Waitinglist participants with an available notification destination; Guest email is not canonical RumahAgen identity.
- Anonymous Guest persistence remains a downstream physical/documentary residual and does not authorize invention of a physical field/model at STEP13-A.
- At Event start, Registered and Waitinglist participants are notified using configured notification destinations.
- Event/session relationships may surface Learning Sessions through calendar discovery without turning the session into an Event-owned semantic object.
- Event lifecycle, registration, configuration/provider and dependencies remain M05-owned.
- M05 remains Event/Calendar and Registration authority.
- Event Registration remains distinct from Learning Session Enrollment.
- participant_mode remains an M05 participant semantic and must not be reinterpreted by another module.
- Guest registration is supported where current M05 semantics permit it; Guest email is a notification/contact destination.
- At Event start, Registered and Waitinglist participants are notified using configured notification destinations.
- Event/session relationships may surface Learning Sessions through calendar discovery without turning the session into an Event-owned object.
- Event lifecycle, registration, configuration/provider and dependencies remain M05-owned.
Event calendar remains a discovery/integration surface.
Event Registration remains distinct from Session Enrollment.
Learning Session may be surfaced through calendar discovery without becoming an Event-owned semantic object.
Legacy Event requirements remain unless explicitly superseded by current Session semantics.
M06–M09 — Developer / DBR / Dashboard / Admin

### Successor synchronization — M06 Developer / Project / Media / Marketing Kit / Claim
- M06 owns Developer, Project, Project Media, Marketing Kit, Project Claim and Approval Claim semantics.
- Developer fields explicitly include `company_logo` and free-text **“Tentang Developer”**.
- Project semantic field expansion is integrated while preserving valid predecessor detail, including project identity/slug, M03-compatible meta title/meta description, geography, property type, bedrooms/bathrooms, price range, land/building area, floors/carport/electrical/water/furnishing/year built, certificate/IMB declarations, availability, commission fields, status, category, transaction type, price unit, negotiability, area keyword, coordinates and property declarations.
- Project Media = **photo/video only**, including multiple uploads. Marketing Kit is separate and limited to PDF brochure/pricelist.
- Marketing Kit permissions: Developer Partner own Create/Upload/Update/Delete/View/Download; Admin/Superadmin All; Manager/Agent View/Download; Buyer/Partner none.
- Claim lifecycle and Approval Claim are explicit M06 capabilities. Approved Claim → Agent-owned Listing initialization is a dependency, not a transfer of M03 authority.
- Developer Project/Claim approval does **not** grant ordinary M03 Listing Create/Update/Publish/Refresh authority.
- Project fields remain compatible with M03 Listing integration without redefining Listing ownership/lifecycle authority.
- M06 owns Developer, Project, Project Media, Marketing Kit, Project Claim and Approval Claim semantics.
- Developer fields explicitly include company_logo and free-text “Tentang Developer”.
- Current Project semantic field expansion is integrated while preserving valid predecessor Project detail.
- Project Media = photo/video only, including multiple uploads. Marketing Kit is separate and limited to PDF brochure/pricelist.
- Marketing Kit permissions: Developer Partner own Create/Upload/Update/Delete/View/Download; Admin/Superadmin All; Manager/Agent View/Download; Buyer/Partner none.
- Claim lifecycle and Approval Claim are explicit M06 capabilities. Approved Claim → Agent-owned Listing initialization is a dependency, not a transfer of M03 authority.
- Developer Project/Claim approval does not grant ordinary M03 Listing Create/Update/Publish/Refresh authority.
- Project fields remain compatible with M03 Listing integration without redefining Listing ownership/lifecycle authority.

### Successor synchronization — M07 DBR / Bank Master
- M07 remains DBR semantic authority.
- DBR master/configuration/display semantics remain preserved.
- Bank Master remains a valid M07 semantic requirement.
- Current Bank Master physical representation is a controlled downstream/traceability residual; no table, migration or physical identifier is invented here.
- M07 remains DBR semantic authority.
- DBR master/configuration/display semantics remain preserved.
- Bank Master remains a valid M07 semantic requirement.
- Current Bank Master physical representation is a controlled downstream/traceability residual; no table, migration or physical identifier is invented here.

### Successor synchronization — M08 Dashboard / Notification Projection
- M08 remains projection/communication only; it is not a business-mutation authority.
- Dashboard Projection aggregates authoritative states from source modules and inherits their scope.
- Notification State is the actor's own state; read/unread, dismiss and delivery-state actions cannot mutate the underlying source business state.
- Protected source details referenced by notifications remain hidden without source permission.
- Historical M08 Q18/Q19 Dashboard mutation proposals remain cancelled/superseded.
- M08 remains projection/communication only; it is not a business-mutation authority.
- Dashboard Projection aggregates authoritative states from source modules and inherits their scope.
- Notification State is the actor's own state; read/unread, dismiss and delivery-state actions cannot mutate the underlying source business state.
- Protected source details referenced by notifications remain hidden without source permission.
- Historical M08 Q18/Q19 Dashboard mutation proposals remain cancelled/superseded.

### Successor synchronization — M09 Administration / Configuration / Audit
- M09 owns Administration and System Configuration within governed administrative scope but is not a super-domain business authority.
- Administrative Audit remains an audit/context capability; Administrative Export is **Superadmin-only**.
- Review, Escalate and Manual Correction remain distinct administrative concepts where separately governed; provider/domain execution remains in the applicable domain.
- M09 owns lifecycle/configuration for lightweight public content and communication configuration where applicable; M11 owns public discovery/SEO/measurement.
- M09 does not bypass M10 and does not inherit M14 payment, M03 Listing, M04 Learning or M13 provider-domain authority.
- M09 owns Administration and System Configuration within governed administrative scope but is not a super-domain business authority.
- Administrative Audit remains an audit/context capability; Administrative Export is Superadmin-only under the locked M09 boundary.
- Review, Escalate and Manual Correction remain distinct administrative concepts where separately governed; provider/domain execution remains in the applicable domain.
- M09 owns lifecycle/configuration for lightweight public content and communication configuration where applicable; M11 owns public discovery/SEO/measurement.
- M09 does not bypass M10 and does not inherit M14 payment, M03 Listing, M04 Learning or M13 provider-domain authority.
Developer directory, project collaboration and project claims remain supported within approved Organization/Developer boundaries.
MVP has no territory/project exclusivity unless explicitly governed.
DBR bank/configuration follows approved master + display rules; no new DBR authority is invented.
Dashboard aggregates current authoritative states; it does not mutate them.
Admin configuration remains governed by explicit permission and configuration rules.
Audit log/history remains the existing audit mechanism where approved decisions require reuse rather than a new subsystem.
M10 — Authorization

### Successor synchronization — M10 Authorization / RBAC / RLS
- M10 remains authorization/RBAC/RLS semantic authority.
- **Role = actor grouping.**
- **Role Permission = default/baseline permission matrix.**
- **Permission Preset = optional configurable authorization configuration targeted to an existing Role.**
- Permission Preset is not a Role and cannot create capabilities/permissions outside the target Role baseline.
- Preset resolution cannot bypass ownership, organization, domain, scope, state or separation-of-duty constraints.
- Capability + Permission + Scope + Condition + Ownership + Organization context remain authorization inputs.
- Permission minimization/reuse remains the governing principle; physical permission IDs are not invented at PRD level.
- API mappings, ERD/DB realization, RLS and runtime authorization remain downstream; runtime authorization/RLS is **NOT VERIFIED**.
- M10 remains authorization/RBAC/RLS semantic authority.
- Role = actor grouping.
- Role Permission = default/baseline permission matrix.
- Permission Preset = optional configurable authorization configuration targeted to an existing Role.
- Permission Preset is not a Role and cannot create capabilities/permissions outside the target Role baseline.
- Preset resolution cannot bypass ownership, organization, domain, scope, state or separation-of-duty constraints.
- Capability + Permission + Scope + Condition + Ownership + Organization context remain authorization inputs.
- Permission minimization/reuse remains the governing principle; physical permission IDs are not invented at PRD level.
- API mappings, ERD/DB realization, RLS and runtime authorization remain downstream; runtime authorization/RLS is NOT VERIFIED.
Authorization is based on Capability + Permission + Scope.
Role is not equivalent to capability and entitlement is not equivalent to permission.
Organization Lead and Member/Agent remain the approved Organization roles.
Instructor and Host are separate capabilities; no automatic inheritance.
Exact permission IDs remain downstream authorization artifacts and are not invented here.
M11 — SEO / Analytics

### Successor synchronization — M11 Public Discovery / SEO / Measurement
- M11 owns public discovery, SEO projection and measurement; it does not own lifecycle/configuration of source resources.
- The locked **ten-surface** public discovery inventory is: **1) Homepage, 2) Listing, 3) Agent, 4) Organization, 5) Developer/Project, 6) Event, 7) Learning, 8) Learning Session, 9) Static Public Content, 10) Announcement/Promotion**.
- **Static Public Content** and **Announcement/Promotion** are mandatory public surfaces, not optional traceability.
- Lightweight Public Content is not a full CMS/per-user website builder. V1 publishing is restricted to the current governed administrative actors; ordinary actors receive public view without arbitrary static-page authoring.
- Static Public Content lifecycle is M09/domain-owned: Draft → Published → Unpublished → Archived; only eligible Published public representations are discovery/sitemap candidates.
- Public Announcement/Promotion is public, scheduled, dismissible and non-segmented in V1; administrative configuration remains outside M11.
- M09 or the applicable domain owns lifecycle/configuration mutation; M08 may provide reusable projection infrastructure; M10 remains authorization authority.
- Every indexable public representation has one canonical URL; sitemap participation is limited to eligible canonical public URLs and robots policy is discovery policy, not authorization.
- Public SEO/analytics must not expose private/sensitive identity, authorization or commercial data and cannot create/mutate authoritative business outcomes.
- M11 owns public discovery, SEO projection and measurement; it does not own lifecycle/configuration of source resources.
- Mandatory public discovery surfaces are Homepage, Listing, Agent, Organization, Developer/Project, Event, Learning, Learning Session, Static Public Content, Announcement/Promotion.
- Static Public Content and Announcement/Promotion are mandatory public surfaces, not optional traceability.
- Lightweight Public Content is not a full CMS/per-user website builder. Current M11 semantics restrict V1 publishing to Superadmin/Admin; Manager has governed/view access; Agent, Instructor, Developer Partner and Buyer receive public view without arbitrary static-page authoring.
- Public Announcement/Promotion is public, scheduled, dismissible and non-segmented in V1.
- M09 or the applicable domain owns lifecycle/configuration mutation; M08 can provide reusable projection infrastructure; M10 remains authorization authority.
- Public SEO/analytics must not expose private/sensitive identity, authorization or commercial data.
Public Listing, Agent, Organization and Developer surfaces may expose governed SEO metadata.
Public SEO may use SSR/SSG, metadata, Open Graph/Twitter Card, structured data and sitemap according to current SEO specification.
Sold/Rented listing SEO retention and expired-listing lifecycle/noindex behavior follow current SEO baseline.
Dashboard/Admin/private Learning/Payment/Authorization surfaces are excluded from public indexing where private.
GA4/GTM/Search Console ownership is configurable; personal Google identity is not canonical product identity.
Analytics measures domain events and cannot create/mutate authoritative business outcomes.
Private/sensitive data must not leak into public SEO/analytics payloads.
M12 — Organization / Agency

### Successor synchronization — M12 Organization / Membership / Context
- M12 remains Organization/Membership/Organization Context authority.
- Agency is the Organization semantic context; Personal Context remains distinct.
- Organization Lead is organization-scoped authority; Member/Agent is normal membership role. Physical `ORG-ADMIN` labels do not create a new platform role.
- Membership, ownership and entitlement remain distinct.
- Lead Exit follows the governed **CLOSING → CLOSED** lifecycle where applicable; no Lead Transfer or successor privilege inheritance is implied.
- **Organization Public Content ownership remains with the Organization/applicable M12 context owner; M11 only discovers/measures its public representation.**
- M12 supplies Organization context to M03/M10/M11/M14 without absorbing their domain authority.
- M12 remains Organization/Membership/Organization Context authority.
- Agency is the Organization semantic context; Personal Context remains distinct.
- Organization Lead is organization-scoped authority; Member/Agent is normal membership role. Physical ORG-ADMIN labels do not create a new platform role.
- Membership, ownership and entitlement remain distinct.
- Lead Exit follows the governed CLOSING → CLOSED lifecycle where applicable; no Lead Transfer or successor privilege inheritance is implied.
- M12 supplies Organization context to M03/M10/M11/M14 without absorbing their domain authority.
Agency is the Organization semantic context.
Agent may have Personal and Organization contexts without losing Personal Context.
Organization Lead is the organization-scoped authority; Member/Agent is the normal membership role.
Membership, ownership and entitlement remain separate concepts.
Agency lifecycle follows ACTIVE → CLOSING → CLOSED.
Closure is irreversible after successful OTP gate and server-side state transition.
Agency Listing transfer, promotion exception, add-on ownership and historical analytics/audit follow BR-001–BR-151.
Personal Listing and Personal Entitlement are not automatically absorbed into Agency state.
M13 — AI BYOK

### Successor synchronization — M13 Provider / BYOK
- M13 remains Provider Catalogue and BYOK authority.
- Provider Catalogue mutation is **Superadmin-only**.
- BYOK/provider connection ownership is **Agent/User / OWN**.
- Provider configuration must respect M10 authorization and security boundaries; provider/AI mechanics cannot bypass authorization.
- Provider credentials, OAuth/webhook implementation and runtime connectivity remain downstream/evidence-gated.
- M13 remains Provider Catalogue and BYOK authority.
- Provider Catalogue mutation is Superadmin-only.
- BYOK/provider connection ownership is Agent/User / OWN.
- Provider configuration must respect M10 authorization and security boundaries; provider/AI mechanics cannot bypass authorization.
- Provider credentials, OAuth/webhook implementation and runtime connectivity remain downstream/evidence-gated.
AI Provider/Connection behavior remains subject to the existing BYOK product baseline.
AI is assistive; it does not become a business-rule, payment, entitlement, authorization, attendance, completion, LP, competency, credential or awarding authority.
AI provider identity/connection configuration must respect current authorization and security boundaries.
M14 — Commercial / Payment

### Successor synchronization — M14 Commercial / Payment / Entitlement / Quota
- M14 remains Commercial/Payment authority and is a subdomain of the integrated system.
- Current M14 Q01–Q66 inventory is preserved; **Q01–Q64 remain M14** and must not migrate to M15. Q40/Q54/Q61/Q62 remain M14.
- Locked MVP commercial surfaces: Listing quota add-ons; Learning Point packages; Free membership; Pro monthly; Pro annual; paid listing boost/premium promotion; paid internal RumahAgen Learning classes; paid partner Learning classes.
- Subscription, Add-on, Promotion, Catalog/Offer, Order, Checkout, Payment Transaction, Payment Core, Provider Adapter, Provider Result/Webhook, Verification, **Payment Verification**, Fulfillment, Entitlement, Quota Capacity, Operational Pool, Allocation, Usage, Refund/Chargeback and Reconciliation remain distinct where authority/state boundaries require it.
- Subscription lifecycle: PENDING → ACTIVE → PAUSED → ACTIVE → EXPIRED; ACTIVE → CANCELLED; ACTIVE → TERMINATED.
- Add-on lifecycle: ACTIVE → INACTIVE → ARCHIVED, with permanent/fixed-period/usage-based validity semantics.
- Promotion lifecycle: DRAFT → SCHEDULED → ACTIVE → EXPIRED, with governed DISABLED path.
- Order lifecycle: DRAFT → PENDING_PAYMENT → PAID → FULFILLED, with cancellation/expiry/refund branches. Checkout is part of Order; client totals are never authoritative.
- Payment Verification precedes confirmed payment/fulfillment; provider callback/result alone is insufficient. Verified confirmation and idempotency are prerequisites to fulfillment.
- Entitlement is commercial right/state, not RBAC permission. Payment Success ≠ Permission Grant.
- Historical purchase snapshots remain immutable after confirmed transaction; configuration changes do not rewrite historical purchases.
- Commercial reconciliation is first-class and auditable; it does not silently authorize arbitrary remediation.
- The commercial parameter **`daily_refresh_allowance`** is a configurable M14 entitlement/allowance consumed by M03; M14 does not own the Listing Refresh action.
- Refresh relationship remains **M14 allowance/entitlement → M03 Listing/Refresh action enforcement → M10 authorization**.
- M14 remains Commercial/Payment authority and is a subdomain of the integrated system.
- Current M14 Q01–Q66 inventory is preserved; Q01–Q64 remain M14 and must not migrate to M15. Q40/Q54/Q61/Q62 remain M14.
- Locked MVP commercial surfaces: Listing quota add-ons; Learning Point packages; Free membership; Pro monthly; Pro annual; paid listing boost/premium promotion; paid internal RumahAgen Learning classes; paid partner Learning classes.
- Subscription, Add-on, Promotion, Catalog/Offer, Order, Checkout, Payment Transaction, Payment Core, Provider Adapter, Verification, Fulfillment, Entitlement, Quota, Operational Pool, Allocation, Usage, Refund/Chargeback and Reconciliation remain distinct where authority/state boundaries require it.
- Subscription lifecycle: PENDING → ACTIVE → PAUSED → ACTIVE → EXPIRED; ACTIVE → CANCELLED; ACTIVE → TERMINATED.
- Add-on lifecycle: ACTIVE → INACTIVE → ARCHIVED, with permanent/fixed-period/usage-based validity semantics.
- Promotion lifecycle: DRAFT → SCHEDULED → ACTIVE → EXPIRED, with governed DISABLED path.
- Order lifecycle: DRAFT → PENDING_PAYMENT → PAID → FULFILLED, with cancellation/expiry/refund branches. Checkout is part of Order; client totals are never authoritative.
- Verified payment confirmation and idempotency are prerequisites to fulfillment. Provider callback alone is insufficient.
- Entitlement is commercial right/state, not RBAC permission. Payment Success ≠ Permission Grant.
- Historical purchase snapshots remain immutable after confirmed transaction; configuration changes do not rewrite historical purchases.
- Refresh Allowance is a configurable M14 entitlement consumed by M03; M14 does not own the Listing Refresh action.
Commercial/Payment is a subdomain of the integrated RumahAgen system, not an independent subsystem.
Payment belongs to M14 Commercial.
Payment Core is provider-independent behind Provider Adapter.
Midtrans is the selected MVP provider behind the adapter.
Payment callback/provider result is not sufficient by itself for commercial fulfillment.
Verification precedes confirmed payment; idempotency prevents duplicate fulfillment.
Commercial Entitlement is authoritative for commercial capacity/access.
Reconciliation is a first-class capability.
Payment must not directly grant RBAC permissions.
M15 — Title / Awarding

### Successor synchronization — M15 Qualification / Award / Title
- M15 remains Title/Qualification/Awarding authority.
- Title Definition and Award Instance remain distinct; stable Title Identity is preserved without Title Identity Version.
- Awarding Path, Path Version, Rule Version, Condition Groups, Conditions and Prerequisites form the qualification model.
- Qualification Evidence and Qualification Evaluation remain distinct from authorization and Learning completion.
- **Learning-owned evidence** remains M04 authority; M15 consumes that evidence for qualification/evaluation and does not redefine Learning.
- Explicit dependency: **Developer Learning → Learning-owned evidence → M15 Qualification Evidence**; applicable Partner Learning evidence is traced similarly.
- Award snapshots applicable qualification/rule semantics and preserves provenance/history; Award Presentation is non-owning.
- M10 remains authorization; M12 remains Organization context where applicable; M14 remains commercial/payment authority.
- M14 Q01–Q64 are not part of M15.
- M15 remains Title/Qualification/Awarding authority.
- Title Definition and Award Instance remain distinct; stable Title Identity is preserved without Title Identity Version.
- Awarding Path, Path Version, Rule Version, Condition Groups, Conditions and Prerequisites form the qualification model.
- Qualification Evidence and Qualification Evaluation remain distinct from authorization and Learning completion.
- Learning-owned evidence remains M04 authority; M15 consumes that evidence for qualification/evaluation and does not redefine Learning.
- Explicit dependency: Developer Learning → Learning-owned evidence → M15 Qualification Evidence; applicable Partner Learning evidence is traced similarly.
- Award snapshots applicable qualification/rule semantics and preserves provenance/history; Award Presentation is non-owning.
- M10 remains authorization; M12 remains Organization context where applicable; M14 remains commercial/payment authority.
- M14 Q01–Q64 are not part of M15.
Title Definition and Award Instance remain distinct concepts.
Title identity is stable; no separate Title Identity Version is implied.
Awarding Path and Rule Version carry material qualification semantics where governed.
One authority source applies at a time.
Existing audit/history mechanism is reused; no separate appeal subsystem is invented.
Qualification/completion determines applicable Rule Version; Award snapshots the applicable Rule.
Certificate remains a Learning/M04 concept where already defined; Award Instance remains M15.
Qualification/eligibility is distinct from authorization/permission.
Award presentation may surface recognition on profile without becoming authorization.
6. LEARNING ECONOMY PRODUCT CONTRACT
Canonical product principle: Learn for free. Grind to earn. Pay to accelerate. Prove to certify.
7. LEARNING SESSION PRODUCT CONTRACT
8. TITLE / AWARDING PRODUCT CONTRACT
Title Definition identifies the recognition concept; Award Instance represents an actual awarded outcome.
Stable Title Identity is preserved without creating Title Identity Version.
Qualification and completion are not interchangeable with authorization.
Rule Version is selected by qualification/completion under approved semantics and is snapshotted by Award.
One authority source at a time prevents competing qualification/awarding sources.
Existing audit/history is reused for appeal/history requirements; no new appeal subsystem.
Certificate and Award remain distinct to prevent M04/M15 semantic collision.
9. ORGANIZATION / LISTING / COMMERCIAL PRODUCT CONTRACT
Agency = Organization.
Membership does not establish Personal Listing ownership.
Membership does not establish Personal Entitlement ownership.
Listing has owner agent plus current context; origin remains historical.
Member exit may transfer Agency Listing to Personal Draft according to BR exception rules.
Published + active promotion may remain Agency Published until promotion expiry during ordinary member exit; closure is different and transfers immediately.
Agency closure transfers Agency Listings to Personal Draft and resolves commercial ownership according to approved BR.
Permanent Add-on ownership follows allocation, not consumption.
Unallocated Permanent Add-on resolves to Owner on closure; allocated add-on remains with recipient.
Personal Entitlements remain personal and are not automatically converted into new Agency entitlements.
10. REQUIREMENTS TRACEABILITY
11. CURRENT DECISION / OPEN-STATE AUDIT
12. CONTROLLED PRODUCT RESIDUALS
Exact physical table/cardinality/FK implementation remains downstream.
Exact API endpoint/payload identifiers remain downstream.
Exact RBAC permission IDs remain downstream.
Provider-specific operational credentials/OAuth/webhook implementation remain downstream.
Attendance numeric/configuration values remain downstream where intentionally configurable.
Recording retention/privacy implementation remains downstream.
Migration/deployment/runtime verification remains downstream.
Production commercial activation remains downstream.
These residuals are not converted into new Owner decisions or product requirements by inference.
13. HISTORICAL / PROVENANCE BOUNDARY
PRD v1.3 is the predecessor lineage of PRD v2.0 and remains historical baseline evidence.
PRD v2.0 is the immediate predecessor and all still-valid product content is carried forward.
Older AEP impact artifacts that were authored before later closure remain provenance; their OPEN/DEFERRED labels do not override current closure.
Older AEP4 artifacts showing provider failover as OPEN/DEFERRED are historical where later closure exists.
Older MBR-COM-001–013 evidence-gap wording is historical; current status is CLOSED — OWNER APPROVED.
Older Title/Awarding and Learning Session candidate models are historical where superseded by later controlled decisions.
No historical artifact is rewritten merely to erase its former status.
14. W4-02A.6 PHYSICAL / IMPLEMENTATION BOUNDARY
W4-01E remains frozen physical design authority.
W4-02 remains the sole current executable physical baseline.
Legacy database/migrations/RLS/seed/runtime are historical/provenance only.
This PRD does not authorize SQL migration, schema modification, RLS changes, payment activation, runtime deployment or production release.
Fresh database runtime verification belongs to W4-03 after the required final freeze gates.
15. CARRY-FORWARD AUDIT — W4-02A.6.11
16. INTERNAL RECONCILIATION / GREEN GATE
17. DOWNSTREAM HANDOFF CONTRACT
STEP13-B Functional Specification consumes this PRD as immediate product authority.
STEP13 downstream physical/technical artifacts consume this PRD with their governed upstream baselines.
Product requirements must not be reinterpreted by downstream physical artifacts.
Exact physical implementation remains downstream and must reconcile to W4-01E/W4-02.
Commercial, Learning, Session, Awarding, Organization and RBAC semantic boundaries established here must remain intact downstream.
## 10A. SUCCESSOR INTEGRATED AUTHORITY GRAPH

M14 Commercial Entitlement / Allowance → M03 Listing / Refresh Action Enforcement → M10 Authorization / RBAC / RLS.
M04 Learning / Learning Economy → Learning-owned Evidence → M15 Qualification / Award / Title.
M13 Provider / BYOK → M10 Authorization.
M12 Organization Context → M03 / M10 / M11 / M14.
M09 Administration / Configuration → M11 Public Discovery Configuration.
M06 Developer / Project / Claim → M11 Discovery / SEO / Measurement where applicable.

Arrows express dependency/consumption/authorization relationships, not authority transfer.

## 10B. PRODUCT-WIDE SUCCESSOR INVARIANTS

- Core v1.3 remains immutable.
- Valid Core PRD detail is preserved; no silent deletion.
- M01–M15 deltas use PRESERVE / AUGMENT / ADD-NEW / UPDATE-RECONCILE.
- Entitlement ≠ Permission; Payment Success ≠ Permission Grant.
- Membership ≠ ownership; public visibility ≠ authorization.
- M04 Learning authority is not absorbed by M15.
- M14 Q01–Q64 remain M14.
- M14 Refresh allowance does not become M03 action authority.
- M10 authorizes domain-owned actions without taking over their business semantics.
- M11 owns discovery/SEO/measurement; M09/domain owns lifecycle/configuration.
- M08 remains projection/communication, not mutation authority.
- Physical/API/RLS/runtime status is separate; no runtime PASS is inferred.
- No unsupported endpoint, permission, table, RLS SQL, provider credential or production authorization is invented.

## 10C. CORE PRD PRESERVATION DECLARATION

The complete Core PRD v2.1 content is carried forward as the structural/product baseline while affected module sections are natively augmented/reconciled. This is not a PRD-plus-appendix and does not mutate Core v1.3.

**Core Detail Loss = 0**, except for explicit semantic reconciliation/supersession recorded below.

## 10D. EXPLICIT SUPERSESSION / RECONCILIATION REGISTER

| Item | Successor state | Classification |
|---|---|---|
| Normal Listing publication | DRAFT → PUBLISHED; no normal Listing Pending Review gate | UPDATE-RECONCILE |
| Review approval interpretation | AUTO-APPROVED; Admin moderation post-publication | UPDATE-RECONCILE |
| KTP | Eligibility/requirement; not RBAC permission; deferred flow explicit | AUGMENT / UPDATE-RECONCILE |
| Provider Catalogue mutation | Superadmin-only | UPDATE-RECONCILE |
| BYOK ownership | Agent/User / OWN | UPDATE-RECONCILE |
| Project Media | Semantic photo/video; Marketing Kit separate | UPDATE-RECONCILE |
| Historical M04 OPEN/conflict snapshots | Current v1.2 51/51 RESOLVED/LOCKED; old records provenance | SUPERSEDED / PROVENANCE |

## 10D.1 STEP13-A v3.7 CORRECTIVE RECONCILIATION RECORD

The v3.7 full rebuild incorporates the findings produced by the source-only deep scan of the uploaded v3.6 candidate and the uploaded M01–M15/Core source corpus.

### Corrected finding A-025 — M01 Pending Review wording contradiction
The predecessor Core PRD contains a generic `Pending Review → Active/Suspended/Rejected` account-lifecycle statement, while current M01 locks immediate Agent activation after successful OTP and explicitly rejects `PENDING_REVIEW` as the default Agent activation state. The successor therefore preserves workflow-specific Pending Review semantics only where separately governed and removes its interpretation as an Agent activation prerequisite.

**Classification:** UPDATE-RECONCILE.

### Corrected finding A-026 — M11 public-surface inventory contradiction
The successor previously contained one shortened eight-surface sentence after separately declaring the locked ten-surface inventory. This was an internal completeness inconsistency. The successor now uses the complete ten-surface inventory consistently: Homepage, Listing, Agent, Organization, Developer/Project, Event, Learning, Learning Session, Static Public Content, Announcement/Promotion.

**Classification:** UPDATE-RECONCILE / COMPLETENESS CORRECTION.

### Corrected finding A-027 — M05 Guest registration detail propagation
The current M05 source supports Guest registration, Guest email as a notification/contact destination, conditional inclusion of an available Event/meeting link in confirmation, Event-start notifications for Registered/Waitinglist participants with an available destination, and Guest email not being canonical identity. These semantics are now explicit at STEP13-A PRD level; anonymous Guest persistence remains physical/documentary residual.

**Classification:** AUGMENT / TRACEABILITY.

v3.7 remains a whole-artifact rebuild. It does not mutate Core v1.3 in place and does not claim physical/runtime authorization or RLS completion.

## 10E. CONTROLLED PHYSICAL / RUNTIME BOUNDARY

Exact physical schema/cardinality/FK, API identifiers, physical permission IDs, Permission Preset realization, Bank Master representation, Marketing Kit/Claim persistence, provider credentials/OAuth/webhooks, RLS enforcement, migration/deployment proof and production commercial activation remain evidence-gated.

**Runtime authorization/RLS = NOT VERIFIED.**

## 10F. PRD SUCCESSOR HANDOFF

This successor PRD is the immediate product authority for STEP13-B Functional Specification Synchronization. Downstream stages must preserve all M01–M15 authority boundaries, cross-module dependencies and mandatory public surfaces established here.

18. SOURCE BASIS
W4-02A.6 Baseline Execution Prompt v1.1 with Mandatory Carry-Forward Audit.
W4-02A.6.0 Core Artifact Inventory & Ordering Lock v1.1.
PRD v2.0 Wave 3 Step 3.1 — immediate predecessor.
W4-02A.6.1–6.10 current consolidated artifacts.
Master BR-001–BR-151.
Commercial Business Rules Closure MBR-COM-001–013 — CLOSED / OWNER APPROVED.
AEP1 Commercial/Payment PRD impact.
AEP2 Learning Economy PRD impact.
AEP3 Title/Awarding product requirement/architecture package.
AEP4 Learning Session PRD impact and cross-document reconciliation.
Current Wave 3 User Flow / Entity Mapping / ERD / Dictionary / API / Functional / SEO downstream evidence.
Current Project Manifest / Constitution / Decision Log / Governance closure states.
19. NEXT STEP
NEXT STEP = STEP13-B — FUNCTIONAL SPECIFICATION SYNCHRONIZATION
Execution stops here. No work from Step 6.12 or later is performed in this artifact.
END — RUMAHAGEN STEP13-A SUCCESSOR INTEGRATED PRD FULL REBUILD v3.7

[TABLE 1]
Current authority fact | Current state
BR-001–BR-151 | NORMATIVE / LOCKED
MBR-COM-001–013 | CLOSED — OWNER APPROVED; normative Commercial BR downstream input
Agency | Organization semantic boundary
Commercial Entitlement | Authority for commercial access/quota capacity; not RBAC
Payment | M14 Commercial / Payment subdomain
Payment Core | Provider-independent behind Provider Adapter
MVP payment provider | Midtrans behind Provider Adapter
Learning Activity | Canonical completion/reward boundary
Title / Award | Title Definition and Award Instance remain distinct
Learning Session | Extension of Learning; not a new top-level M16
Host / Instructor | Separate capabilities; no automatic inheritance
Session taxonomy | BROADCAST / INTERACTIVE / ON_DEMAND
Session enrollment | PENDING → ACTIVE → COMPLETED
Automatic provider failover | Not required; switching is manual/admin controlled
Implementation authorization | NOT GRANTED by this PRD
Production authorization | NOT GRANTED by this PRD

[TABLE 2]
Actor / Context | Canonical product meaning
Superadmin | Global permission-matrix authority according to explicit permissions.
Manager | Internal supervisory role; no Agent/Admin promotion or demotion.
Admin | Internal RumahAgen operational role; not an Organization role.
Agent | Independent-first platform actor with Personal Context; may gain Organization Context.
Organization Lead | Organization-scoped authority over Organization context.
Organization Member/Agent | Organization-scoped member actor; may receive authorized Instructor capability.
Instructor capability | Teaching capability scoped to authorized Organization/session/resource; does not imply Host.
Host capability | Separate session/provider-operation capability; does not imply Instructor.
Developer Partner | External partner context for developer/project collaboration.
Buyer / Guest / Lead | Public/lightweight consumer actors for discovery, inquiry and review surfaces where allowed.

[TABLE 3]
Area | Product role | Current status
M01–M03 | Agent, profile, listing foundation | Existing baseline — evolve
M04 | Learning Center + Learning Economy + Learning Session | Evolved
M05 | Calendar Event / discovery context | Existing baseline — boundary clarified
M06–M09 | Developer, DBR, dashboard, admin | Existing baseline — evolve
M10 | RBAC / Capability / Permission / Scope | Evolved
M11 | SEO / Analytics | Evolved
M12 | Organization / Agency context | Evolved
M13 | AI BYOK | Existing baseline — preserved
M14 | Commercial / Payment | Governing product boundary
M15 | Title / Awarding | Governing product boundary
Learning Session | Learning extension, not top-level M16 | Governing semantic boundary

[TABLE 4]
Boundary | Requirement
Learning | Provides content/product structure and governed learning progression.
Learning Activity | Canonical completion/reward boundary.
LP | Economic/progression transaction; does not constitute competency.
Earned LP | Issued only after validated completion/outcome according to authority.
Purchased LP | Commercially fulfilled and provenance-distinguished from earned LP.
Pay-to-Accelerate | May accelerate eligible progression.
Never-Pay-to-Pass | Payment cannot bypass assessment/competency.
Credential/Award | Requires applicable qualification/assessment/awarding authority; LP cannot purchase it.

[TABLE 5]
Requirement | Current product rule
Taxonomy | BROADCAST / INTERACTIVE / ON_DEMAND
Enrollment | Separate Session Enrollment
Lifecycle | PENDING → ACTIVE → COMPLETED
Access | Only authorized ACTIVE enrollment resolves provider session access
Provider | Provider-neutral Session/Adapter boundary
Evidence | Normalized, idempotent, provenance-preserving
Attendance | Evaluated under policy; raw provider events are not canonical
Completion | Governed outcome; provider cannot directly establish it
LP | Session does not directly create official LP transactions
Assessment | Session completion cannot bypass required assessment
Switching | Manual/admin controlled; semantic identity/history preserved
Failover | No automatic failover
AI | Assistive only; never session authority

[TABLE 6]
Requirement cluster | Primary source authority | Downstream consumers
BR-001–BR-151 | Master Business Rules | User Flow, ERD, Dictionary, API, RBAC/RLS, Functional, Technical, Test
MBR-COM-001–013 | Commercial Business Rules Closure — CLOSED / OWNER APPROVED | Commercial, Payment, Entitlement, Listing, PRD, User Flow, ERD, API, RBAC
MADCR-010/011 | Approved Commercial/Payment decisions | Commercial/Payment product boundaries
MADCR-002/003/005 | Approved Payment architecture decisions | Payment flow, fulfillment, reconciliation
MADCR-049 | Approved Learning decision — Option A | Learning Activity/completion/reward boundary
MADCR-053/054 | Approved authorization decisions | Capability/Permission/Scope; Host/Instructor
AEP3-OD-02/03/04/05 | Closed Awarding decisions | Awarding product semantics
AEP4-OD-01/08/16/17 | Approved/closed Session decisions | Session taxonomy, provider, enrollment lifecycle
MADCR-058 | Closed — Midtrans MVP | M14 provider product boundary
SEO/Analytics baseline | Wave 3 SEO/Analytics v2.0 | Public discovery/measurement

[TABLE 7]
Item | Current state | PRD treatment
BR-001–BR-151 | LOCKED / NORMATIVE | Current business-rule authority
MBR-COM-001–013 | CLOSED — OWNER APPROVED | Current Commercial BR authority; stale gap wording = historical
MADCR-049 | APPROVED / GOVERNING — Option A | Learning Activity boundary
MADCR-053 | APPROVED / GOVERNING | Capability + Permission + Scope
MADCR-054 | APPROVED / GOVERNING | Host/Instructor separation
AEP3-OD-02 | CLOSED | One authority source at a time
AEP3-OD-03 | CLOSED | Reuse existing audit/history
AEP3-OD-04 | CLOSED | No mandatory parent Rule Version lineage
AEP3-OD-05 | CLOSED | Qualification selects Rule Version; Award snapshots
AEP4-OD-08 | CLOSED / GOVERNING | No automatic provider failover
AEP4-OD-16/17 | APPROVED | Session Enrollment lifecycle
MADCR-058 | CLOSED / GOVERNING | Midtrans MVP behind Provider Adapter
OPEN-C01 / MADCR-012 | CLOSED | Commercial AEP relationship governed
Owner-level unresolved for PRD | 0 | No STOP condition

[TABLE 8]
Audit field | Result
Predecessor | RUMAHAGEN_PRD_v2.0_WAVE3_STEP3.1_FULL_CONSOLIDATED_SYNCHRONIZED.md — CURRENT CANONICAL PRD v2.0
New artifact | W4-02A.6.11 PRD Current Product Requirements v2.1
Content units reviewed | 15 major predecessor/content units: executive baseline, objectives/actors, canonical product structure, commercial scope, module requirements, Learning Economy, Session, Awarding, traceability, decision audit, residuals, historical boundary, physical boundary, handoff, gate
CARRY FORWARD | Existing M01–M13 product baseline; actors; commercial scope; product invariants; Wave 3 PRD structure; downstream handoff; historical boundary
UPDATE | Current 6.1–6.10 authority, approved Commercial BR closure, current AEP2/AEP3/AEP4 decisions, Midtrans closure, Session lifecycle/taxonomy, Awarding closure, Authorization boundaries
SUPERSEDE | Stale current-state wording where later closure governs; especially older OPEN/DEFERRED Commercial/AEP states
HISTORICAL / PROVENANCE | PRD v1.3 lineage; older AEP impact states; earlier evidence-gap classifications
REMOVED | 0 valid predecessor content authorized for removal
Missing valid content | 0 identified in source-driven section inventory
Untraced new substantive content | 0
Material conflict | 0 unresolved
Owner decision required | 0
Audit result | PASS

[TABLE 9]
Gate | Result
Full current PRD source produced | PASS
Current BR authority | PASS
MBR-COM-001–013 current closure | PASS
AEP1 Commercial/Payment | PASS
AEP2 Learning Economy | PASS
AEP3 Title/Awarding | PASS
AEP4 Learning Session | PASS
Organization / Authorization | PASS
SEO / Analytics | PASS
AI boundary | PASS
Physical/runtime boundary | PASS
Historical/provenance boundary | PASS
Carry-Forward Audit | PASS
Unresolved Owner decision | 0
Material authority conflict | 0
STEP STATUS | COMPLETE / GREEN
