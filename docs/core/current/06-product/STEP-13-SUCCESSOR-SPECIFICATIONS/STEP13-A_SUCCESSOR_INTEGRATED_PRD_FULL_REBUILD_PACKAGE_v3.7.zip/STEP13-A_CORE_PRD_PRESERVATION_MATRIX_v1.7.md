# STEP13-A — CORE PRD PRESERVATION MATRIX v1.7
Complete Core PRD v2.1 baseline | PRESERVE | PASS
M01 | UPDATE-RECONCILE / AUGMENT | Immediate OTP activation + Conditional KTP
M02 | UPDATE-RECONCILE / ADD-NEW | CTA + override + Review + Outcome Presentation
M03 | UPDATE-RECONCILE / AUGMENT / ADD-NEW | Publication + Refresh + media delivery
M04 | PRESERVE / AUGMENT | Learning/Economy/Session
M05 | AUGMENT | Event/Registration/participant_mode/Guest
M06 | UPDATE-RECONCILE / ADD-NEW | Developer/Project/Media/Marketing Kit/Claim
M07 | PRESERVE / CONTROLLED | DBR/Bank Master
M08 | PRESERVE / AUGMENT | Projection/Notification
M09 | AUGMENT | Administration/Configuration/Audit/Export
M10 | UPDATE-RECONCILE | Role/Role Permission/Permission Preset
M11 | UPDATE-RECONCILE / ADD-NEW | Locked 10-surface discovery inventory
M12 | AUGMENT | Organization/Context/Public Content
M13 | UPDATE-RECONCILE | Provider Catalogue/BYOK
M14 | AUGMENT / UPDATE-RECONCILE | Commercial/payment + daily_refresh_allowance
M15 | AUGMENT | Qualification/Award/Title + Learning evidence dependency
Physical/runtime | CONTROLLED | Evidence-gated, not semantic blocker
Core Detail Loss | — | 0 except explicit reconciliation/supersession
