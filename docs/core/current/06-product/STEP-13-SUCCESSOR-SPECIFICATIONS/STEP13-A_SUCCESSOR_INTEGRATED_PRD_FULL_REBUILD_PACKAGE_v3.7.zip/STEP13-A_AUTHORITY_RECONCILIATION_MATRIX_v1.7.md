# STEP13-A — AUTHORITY RECONCILIATION MATRIX v1.7
M01 | Identity/Auth/Activation | — | M02/M10 identity ownership
M02 | Profile/Visibility/Review presentation | M01 identity | Identity/Learning/Award authority
M03 | Listing/Refresh action | M14 allowance; M10 auth; M12 context | M14 action authority
M04 | Learning/Learning Economy/Session | M10 auth; M14 commercial outcomes | M15 Learning authority
M05 | Event/Registration | M04 session discovery | M04 Event ownership
M06 | Developer/Project/Media/Marketing Kit/Claim | M03 compatibility; M10 auth | M03 ordinary Listing actions
M07 | DBR/Bank Master semantic | M10 where protected | Physical authority
M08 | Projection/Notification | source domains | Business mutation
M09 | Administration/Configuration/Audit | M10 auth; domain semantics | Super-domain authority
M10 | Authorization/RBAC/RLS | identity/domain/context | Business semantics
M11 | Discovery/SEO/Measurement | M09/domain lifecycle | Lifecycle ownership
M12 | Organization/Membership/Context | M03/M10/M11/M14 | Domain authority
M13 | Provider Catalogue/BYOK | M10 auth | Business outcome authority
M14 | Commercial/Payment/Entitlement/Quota | M12 context; M10 auth; M03 consumption | M03 action/RBAC authority
M15 | Qualification/Award/Title | M04 evidence; M10 auth; M12 context | M04/M14 authority
