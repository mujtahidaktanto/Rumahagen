# RUMAHAGEN --- UI / UX SPECIFICATION

## STEP13-E --- Successor Integrated UI/UX Specification

**Version:** 3.0 --- STEP13-E Successor Integrated UI/UX\
**Date:** 19 August 2026\
**Status:** **SUCCESSOR INTEGRATED UI/UX CONTRACT --- FULL REBUILD /
SECOND DEEP SCAN CLEAN**\
**Predecessor:**
`RUMAHAGEN_UI_UX_SPECIFICATION_v2.0_WAVE3_STEP3.10_FULL_CONSOLIDATED_SYNCHRONIZED.md`\
**Document type:** **FULL CURRENT CONSOLIDATED MASTER --- NOT PATCH /
NOT ADDENDUM / NOT MAEP-ONLY**\
**Implementation authorization:** NOT GRANTED\
**Runtime claim:** NONE

> This document is the complete functional UI/UX contract for the
> current RumahAgen product baseline. It preserves valid legacy UX while
> synchronizing Learning Economy, Learning Session, Commercial/Payment,
> Organization, Authorization, Title/Awarding and SEO/Analytics. It
> defines information architecture, screen families, interaction
> patterns, state presentation, responsive behavior, accessibility,
> role/context behavior, cross-domain UX boundaries and acceptance
> criteria. It does not authorize production implementation, migration,
> provider activation or runtime deployment.

------------------------------------------------------------------------

# 0. EXECUTION / AUTHORITY RULES

1.  Current Owner-approved MADCR/ADR/Decision Log closure has highest
    authority.
2.  Master BR-001--BR-151 remains normative.
3.  W4-02A.6.11 PRD v2.1 is the product requirement authority.
4.  Current W4-02A.6.12 User Flow v2.1 is the journey/state-transition
    authority.
5.  Entity Mapping v2.0 is the conceptual entity authority.
6.  W4-02A.6.13 ERD v2.1 is the relationship authority.
7.  W4-02A.6.14 Database Dictionary v2.2 is the physical data contract
    authority.
8.  W4-02A.6.16 API v2.1 is the API interaction contract authority.
9.  W4-02A.6.17 RBAC/Permission/RLS v2.1 is the authorization contract
    authority.
10. SEO/Analytics v2.0 is the public discovery/tracking authority.
11. Historical artifacts are provenance only where superseded by later
    closure.
12. No UI may imply a business authority that does not exist in the
    owning domain.
13. UI state is a projection of authoritative server state; client state
    cannot create official outcomes.
14. No screen, menu or component is itself an authorization boundary.
15. Commercial Entitlement is not RBAC.
16. Organization membership is not Entitlement.
17. Visibility is not Authorization.
18. Course Enrollment is not Session Enrollment.
19. Event Registration is not Session Enrollment.
20. Completion is not Award.
21. Certificate is not Award Instance.
22. Host is not Instructor and Instructor is not Host.
23. Payment success display is not Payment confirmation unless trusted
    confirmation has occurred.
24. Analytics events are observational and never become business
    authority.
25. Historical outcomes must remain explainable after configuration
    changes.
26. Exact visual implementation details may be refined by
    design/engineering without changing semantic behavior in this
    document.

------------------------------------------------------------------------

# 1. DECISION / CURRENT-STATE GATE

## 1.1 Current decision state

STEP13-E treats frozen Core v1.3 as the preservation reference and
integrates the approved M01--M15 successor changes from the uploaded
STEP13-A/B/C/D chain and reconciliation evidence.

Current closure evidence establishes:

  ------------------------------------------------------------------------------------
  Decision                Current state           UX consequence
  ----------------------- ----------------------- ------------------------------------
  Agency = Organization   CLOSED / GOVERNING      One Organization context; "Agency"
                                                  may remain product wording where
                                                  useful.

  MADCR-010               CLOSED / GOVERNING      Entitlement/quota capacity shown
                                                  separately from role/permission.

  MADCR-011               CLOSED / GOVERNING      Payment belongs to Commercial.

  MADCR-002               CLOSED / GOVERNING      Provider-specific payment UI must
                                                  sit behind provider-independent
                                                  Commercial flow.

  MADCR-003               CLOSED / GOVERNING      Payment UI distinguishes
                                                  initiated/pending/confirmed/failed
                                                  and does not grant on client success
                                                  alone.

  MADCR-005               CLOSED / GOVERNING      Reconciliation is visible only to
                                                  authorized operations and does not
                                                  silently remediate.

  MADCR-036               CLOSED / GOVERNING      Title Definition and Award Instance
                                                  remain distinct in UI.

  MADCR-049               CLOSED / GOVERNING ---  Learning Activity is
                          Option A                completion/reward boundary.

  MADCR-053               CLOSED / GOVERNING      UI authorization follows
                                                  Capability + Permission + Scope.

  MADCR-054               CLOSED / GOVERNING      Host and Instructor are distinct
                                                  capabilities.

  OPEN-C01 / MADCR-012    CLOSED / GOVERNING      Commercial surfaces remain
                                                  complementary, not duplicated.

  AEP3-OD-02              CLOSED                  One authority source at a time.

  AEP3-OD-03              CLOSED / GOVERNING      Existing audit/history is reused.

  AEP3-OD-04              CLOSED                  No mandatory parent Rule Version
                                                  lineage.

  AEP3-OD-05              CLOSED                  Qualification selects applicable
                                                  Rule Version; Award snapshots it.

  AEP4-OD-08              CLOSED / GOVERNING      No automatic provider failover;
                                                  provider switching is manual/admin
                                                  controlled.

  MADCR-058               CLOSED / GOVERNING      Midtrans is MVP provider behind
                                                  Provider Adapter.

  MBR-COM-001--013        OWNER APPROVED / CLOSED Commercial behavior is normative.

  DBR bank configuration  CLOSED                  Admin bank master, maximum four
                                                  displayed, fixed 10pp bands.

  Developer exclusivity   CLOSED                  No MVP territory/project
                                                  exclusivity.

  Google ownership        CLOSED                  Configurable ownership; not
                                                  hard-coded to a personal account.

  Organization roles      CLOSED                  Lead + Member/Agent only.

  Instructor/Host         CLOSED                  Separate capabilities; no automatic
                                                  inheritance.
  ------------------------------------------------------------------------------------

The post-Wave-1 Decision Log explicitly records AEP3-OD-03, AEP4-OD-08
and MADCR-058 as APPROVED/APPLIED closures.

The current W4-02A.6 PRD likewise records these decisions as closed and
states that older OPEN/DEFERRED labels are historical rather than
current authority.

## 1.2 Stale historical wording

Older Governance Register material still contains OPEN/DEFERRED/RESEARCH
labels for AEP4-OD-08, MADCR-058 and MBR-COM-001--013. That artifact is
explicitly a re-audit of stale states, not the current closure
authority.

Therefore W4-02A.6.20 does **not** reopen those decisions.

## 1.3 Current Owner-level unresolved count

**0**

Controlled downstream residuals remain:

-   exact component visual styling;
-   exact copy/localization;
-   exact provider checkout rendering;
-   exact attendance numeric configuration;
-   exact recording/privacy display;
-   runtime RLS execution;
-   provider credentials;
-   migration;
-   production activation.

These are not Owner-level open decisions.

------------------------------------------------------------------------

# 2. SOURCE RECONCILIATION

## 2.1 Current W4 authority chain

``` text
Owner Decision / MADCR / ADR
        ↓
Master BR
        ↓
W4-02A.6.11 PRD v2.1
        ↓
W4-02A.6.12 User Flow v2.1
        ↓
Entity Mapping v2.0
        ↓
W4-02A.6.13 ERD v2.1
        ↓
W4-02A.6.14 Database Dictionary v2.2
        ↓
W4-02A.6.15 Database Schema v2.7
        ↓
W4-02A.6.16 API v2.1
        ↓
W4-02A.6.17 RBAC / Permission / RLS v2.1
        ↓
W4-02A.6.18 Functional Specification v2.1
        ↓
W4-02A.6.19 Technical Specification v2.1
        ↓
THIS W4-02A.6.20 UI / UX SPECIFICATION v2.1
```

## 2.2 Existing UX preservation

The legacy product UX remains present for:

-   registration/authentication;
-   agent profile;
-   public profile;
-   review;
-   listing;
-   developer/project;
-   DBR;
-   Learning Center;
-   Event Calendar;
-   Organization;
-   dashboard;
-   notifications;
-   Admin Panel;
-   RBAC;
-   AI BYOK;
-   SEO/public discovery;
-   analytics.

MAEP/AEP synchronization must not remove unaffected legacy journeys.

The AEP1 impact source explicitly requires existing authentication,
profile, listing, learning, event, organization, admin and existing
module flows to remain intact rather than being replaced by Commercial
UX.

------------------------------------------------------------------------

# 3. UX PRINCIPLES

## 3.1 Independent-first

The primary Agent experience is personal/independent.

Organization features are an additional context, not a forced
agency-first model.

## 3.2 One task, one authority

Each screen must make clear which system state controls the action.

Examples:

``` text
Payment → Commercial
Role/Permission → RBAC
Quota → Entitlement/Commercial
Learning Completion → Learning Activity
Session Attendance → Session Evaluation
Award → Awarding
```

## 3.3 Progressive disclosure

Complex domains such as Commercial, Learning Economy, Session operations
and Awarding should expose the next necessary decision first and deeper
provenance on demand.

## 3.4 Explain blocked actions

Whenever an action is disabled, the UI must explain:

``` text
What is blocked
Why it is blocked
What the user can do next
```

Do not expose protected resource existence merely to explain
authorization failures.

## 3.5 State before action

The user must see current authoritative state before destructive or
consequential actions.

## 3.6 Historical integrity

History pages show the state/snapshot that applied at the time.

Current pricing/configuration must not silently rewrite historical
purchases.

------------------------------------------------------------------------

# 4. INFORMATION ARCHITECTURE

## 4.1 Public navigation

Public discovery must expose the M11 ten-surface inventory: Homepage;
Listing; Agent; Organization; Developer/Project; Event; Learning;
Learning Session; Static Public Content; Announcement/Promotion.

## 4.2 Authenticated Agent navigation

Core authenticated navigation preserves: - Personal Context; -
Listings; - Learning / Learning Economy; - Events; - Organization
context; - Commercial / Entitlements; - Dashboard / Notifications; - AI
Assistant; - profile and qualification/award presentation.

The UI must not force Organization context onto independent Agents.

## 4.3 Admin navigation

Admin navigation is capability-driven and includes only authorized
surfaces: - administration/configuration; - moderation; - audit; -
Administrative Export (Superadmin-only); - M10 authorization
governance; - Permission Preset governance for authorized actors; - M07
DBR/Bank Master configuration where applicable; - M13 Provider Catalogue
mutation (Superadmin-only); - M14 commercial
configuration/reconciliation.

## 4.4 Cross-domain navigation rules

-   M14 commercial capacity is distinct from M10 authorization.
-   M03 Refresh action remains in Listing UX.
-   M04 Learning Economy remains in Learning UX.
-   M15 qualification/award presentation consumes authoritative
    evidence.
-   M11 discovery is public-facing and does not grant authorization.
    \# 5. GLOBAL APP SHELL

## 5.1 Desktop

``` text
┌──────────────────────────────────────────────────────────────┐
│ Logo │ Search │ Context Switcher │ Notifications │ Profile  │
├───────────────┬──────────────────────────────────────────────┤
│ Sidebar       │ Breadcrumb                                   │
│               │ Page title + primary action                  │
│ Navigation    │                                              │
│               │ Main content                                 │
│               │                                              │
│               │                                              │
└───────────────┴──────────────────────────────────────────────┘
```

## 5.2 Mobile

``` text
┌─────────────────────────────┐
│ Logo   Search   Bell   Menu │
├─────────────────────────────┤
│ Breadcrumb / context        │
│                             │
│ Content                     │
│                             │
│                             │
├─────────────────────────────┤
│ Primary mobile navigation   │
└─────────────────────────────┘
```

## 5.3 Context switcher

If an Agent belongs to one or more Organizations:

``` text
Current Context
├── Personal
├── Organization A
└── Organization B
```

Switching context must:

-   refresh resource lists;
-   refresh permitted actions;
-   refresh quota/entitlement display where applicable;
-   never mutate ownership merely by switching;
-   never change platform role.

------------------------------------------------------------------------

# 6. DESIGN SYSTEM FOUNDATION

## 6.1 Typography

Use a highly legible sans-serif system with:

-   clear heading hierarchy;
-   readable body text;
-   strong numeric presentation for price/quota/LP;
-   minimum comfortable line-height;
-   consistent form labels.

Recommended semantic levels:

``` text
Display
H1
H2
H3
Body
Body Small
Caption
Label
Numeric Emphasis
```

## 6.2 Color semantics

Color must communicate state, not decoration alone.

Semantic categories:

``` text
Success
Warning
Danger
Info
Neutral
Brand
```

Never encode status using color alone.

Example:

``` text
✓ Published
! Pending Review
× Rejected
○ Draft
```

## 6.3 Spacing

Use a consistent spacing scale.

Primary layout should favor:

-   generous section spacing;
-   compact form groups;
-   clear card separation;
-   predictable modal padding;
-   consistent table density.

## 6.4 Radius / elevation

Use restrained elevation.

Cards should communicate grouping, not become visually heavy.

## 6.5 Iconography

Icons must be:

-   familiar;
-   accompanied by labels where ambiguity exists;
-   accessible;
-   consistent.

------------------------------------------------------------------------

# 7. COMPONENT LIBRARY

## 7.1 Core components

-   Button
-   Icon Button
-   Link
-   Input
-   Textarea
-   Select
-   Cascading Select
-   Search
-   Date/Time Picker
-   Number Input
-   Currency Input
-   File Upload
-   Media Grid
-   Checkbox
-   Radio
-   Toggle
-   Tabs
-   Breadcrumb
-   Pagination
-   Table
-   Card
-   Badge
-   Status Chip
-   Alert
-   Toast
-   Modal
-   Drawer
-   Confirmation Dialog
-   Empty State
-   Skeleton
-   Tooltip
-   Popover
-   Progress Bar
-   Stepper
-   Timeline
-   Activity Feed
-   Timeline/History
-   Chart
-   Map
-   QR/Share block where required.

## 7.2 Component state requirements

Every interactive component must define:

``` text
Default
Hover
Focus
Active
Disabled
Loading
Error
Success
Empty
```

Forms additionally require:

``` text
Untouched
Dirty
Valid
Invalid
Submitting
Submitted
Server Error
```

------------------------------------------------------------------------

# 8. GLOBAL STATE PRESENTATION

## 8.1 State vocabulary

Use authoritative domain states. Generic visual states may include:

``` text
Success / Warning / Danger / Info / Neutral
Loading / Empty / Unauthorized / Error / Pending / Confirmed / Failed
```

`Pending` must always be qualified by its owning domain. The UI must not
invent a generic moderation state.

## 8.2 Loading

Loading states must not imply successful mutation.

## 8.3 Empty state

Empty states distinguish: - no resource; - no authorized resource; - no
configured benefit; - no transaction; - no eligible action.

## 8.4 Error state

Errors identify the next valid action without exposing protected data.

## 8.5 Destructive confirmation

Destructive operations require explicit confirmation and authoritative
result feedback.

## 8.6 Domain-specific state rules

-   M01 OTP success → ACTIVE; deferred KTP is a requirement state.
-   M02 review → AUTO-APPROVE / Published / Viewable for the governed
    flow; moderation is post-publication where authorized.
-   M03 normal publication has no Pending Review gate.
-   M05 participant_mode is descriptive participation state, not
    permission.
-   M06 Claim states are separate from Listing lifecycle.
-   M09 Administrative Export is Superadmin-only.
-   M10 Permission Preset state is separate from Role lifecycle.
-   M13 provider outage is not revocation.
-   M14 payment confirmation requires trusted verification.
-   M15 completion, qualification, credential, award and title remain
    distinct. \# 9. M01 --- REGISTRATION / AUTHENTICATION UX

## 9.1 Registration

Registration collects the minimum identity inputs and presents the OTP
step. Successful OTP verification is the authentication/activation
transition owned by M01.

## 9.2 OTP and activation

``` text
Registration → OTP → successful verification → ACTIVE
```

A successful OTP does not require a default Pending Review gate. The UI
must show ACTIVE immediately after the authoritative activation result.

## 9.3 Conditional KTP / deferred completion

KTP is an eligibility/requirement state, not an RBAC permission. Where
the current M01 flow allows deferred KTP completion:

``` text
ACTIVE account
  ↓
KTP incomplete / deferred requirement
  ↓
restricted feature eligibility where applicable
  ↓
KTP completion
  ↓
eligible for governed capability
```

The UI must distinguish account state from KTP requirement state and
must not invent a generic moderation queue.

## 9.4 Login / recovery

Login, logout, recovery and session-expiry UI remain preserved.
Client-side authentication state never creates official account status.

## 9.5 M01 UI acceptance

-   OTP success visibly resolves to ACTIVE.
-   Deferred KTP is presented as an eligibility/requirement state.
-   No default Pending Review gate is inserted between successful OTP
    and ACTIVE.
-   KTP is never presented as a Role or Permission.
-   Unauthorized downstream actions use the canonical authorization
    denial pattern.

# 10. M02 --- AGENT PROFILE UX

## 10.1 Private profile

Profile editing preserves semantic field visibility and private-data
protection. Sensitive identity/KTP data is never exposed through public
profile components.

## 10.2 Public profile

Public profile rendering follows the profile visibility configuration
owned by M02. Public CTA state is explicit opt-in; administrative
override is Superadmin-only.

## 10.3 Review UX

Review submission and outcome presentation follow the current M02
contract:

``` text
Eligible review → submit → AUTO-APPROVE → Published / Viewable
```

The UI must not represent ordinary Buyer review submission as a
mandatory Pending Review moderation gate. Post-publication moderation
remains an administrative action where separately authorized.

## 10.4 Outcome presentation

Outcome Presentation is a non-owning presentation layer. It displays
authoritative outcomes but does not create approval, qualification,
award or authorization.

## 10.5 M02 UI acceptance

-   AUTO-APPROVE is represented for the governed review flow.
-   Post-publication moderation is represented as a separate
    administrative operation.
-   Public CTA requires explicit opt-in unless the authorized Superadmin
    override applies.
-   Profile visibility and authorization remain distinct.

# 11. M03 --- LISTING UX

## 11.1 Listing creation wizard

The existing wizard remains preserved:

``` text
Context → Category & Transaction → Location → Property Details → Price
→ Legal → Media → Contact → Preview → Submit
```

Normal Listing publication has no Pending Review approval gate. The
authoritative result is rendered from the M03 Listing lifecycle.

## 11.2 Listing detail

Listing detail exposes lifecycle, ownership, visibility and authorized
actions. Fields that become locked after a Listing has ever been
Published remain visibly locked according to M03.

## 11.3 Listing lifecycle UI

``` text
DRAFT → PUBLISHED → [authorized lifecycle transitions]
```

The UI must not invent a moderation approval step for normal
publication.

## 11.4 Refresh UI

Refresh is an M03 action whose commercial allowance is supplied by M14
and whose authorization is resolved by M10:

``` text
M14 commercial allowance / entitlement
          ↓
M03 Refresh eligibility + action + consumption
          ↓
M10 authorization
```

The UI may show: - available daily Refresh allowance; - successful
Refresh count; - remaining allowance; - Listing-level Refresh
eligibility; - next operational-day reset information; - disabled reason
when the Listing has already had one successful Refresh that operational
day.

Canonical presentation rules: - default configured allowance = 5
successful Refreshes / Agent / operational day; - operational day =
Asia/Jakarta; - no carry-forward; - Agent may distribute allowance
across eligible Listings; - maximum one successful Refresh per Listing
per operational day; - failed Refresh consumes no allowance; -
successful Refresh updates authoritative freshness and records audit
provenance; - Refresh does not change district binding; - successful
Refresh repositions only within the Listing's existing District-local
context; - latest successful Refresh ranks first within the governed
District-local freshness ordering; - tied supported timestamps use first
recorded Refresh action; `listing_id ASC` is only a final deterministic
fallback; - client-supplied timestamps are not ranking authority.

The UI must not present Refresh as Update, Publish, Republish, a
regional quota, or an M14 permission.

## 11.5 M03 UI acceptance

-   Normal publication has no Pending Review gate.
-   Refresh allowance is visible where relevant.
-   Refresh action is separate from commercial allowance ownership.
-   Disabled Refresh explains the authoritative reason without leaking
    protected resource existence.
-   District-local freshness semantics are preserved.
-   Listing ownership/lifecycle remains M03 authority.

# 12. M04 --- LEARNING CENTER / LEARNING ECONOMY UX

## 12.1 Learning catalog

Learning catalog and Learning Path remain M04-owned. Internal Learning
Economy remains free-to-learn with Learning Points (LP) earned through
governed activity and optionally purchased to accelerate progression.

## 12.2 Learning Path

The UI presents path progression, prerequisites, current state and
eligible next actions without transferring Learning authority to M15.

## 12.3 Learning Activity

Completion of a governed Learning Activity is the completion/reward
boundary. The UI may show LP earned after authoritative completion, but
client completion alone is not official evidence.

## 12.4 Skill / redemption

Where configured, users can:

``` text
Eligible LP → Redemption → governed Skill / Learning outcome
```

Skill Verify / Issue / Manage and Learning Economy Redemption remain M04
capabilities. Exact endpoint identifiers remain evidence-gated where the
uploaded API corpus does not establish them.

## 12.5 Credential / assessment

Assessment and credential states remain distinct from M15 Award
Instance. Qualification and Awarding consume evidence; they do not
redefine Learning completion.

## 12.6 Learning reconciliation

Learning Economy transactions, redemption and reconciliation states must
be presented as authoritative M04 states. No UI may infer an award
merely from LP balance or course completion.

## 12.7 M04 UI acceptance

-   Learning Economy remains M04-owned.
-   LP balance and transactions are visible as
    commercial/learning-economy state, not RBAC.
-   Redemption is distinct from Award.
-   Skill/credential states are source-bound.
-   Exact route gaps remain controlled residuals rather than invented UI
    API identifiers.

# 16. M05 --- EVENT CALENDAR UX

## 16.1 Calendar and Event detail

Event discovery, detail, registration and participant state remain
M05-owned.

## 16.2 participant_mode

`participant_mode` is explicitly represented in Event/Registration UX.
It describes the participant's governed participation mode and is not: -
a canonical identity; - an RBAC Role; - Session Enrollment; -
ownership; - an authorization capability.

The UI must not convert participant_mode into permission logic.

## 16.3 Guest registration

Guest registration remains supported where configured. Guest email is a
notification/contact destination, not a canonical platform identity.

## 16.4 Session linkage

An Event may link to an available Event/Session resource, but Event does
not own Session. Host and Instructor remain distinct capabilities.

## 16.5 Notifications

Event-start and registration notifications follow authoritative
registration state and the configured destination. The UI must not
fabricate meeting/provider links.

## 16.6 M05 UI acceptance

-   participant_mode is visible where it materially affects the
    participant journey.
-   Guest state is distinguishable from authenticated identity.
-   Event Registration is not represented as Session Enrollment.
-   Event does not grant Host/Instructor authority.

# 17. M06 --- DEVELOPER / PROJECT / MEDIA / MARKETING KIT / CLAIM UX

## 17.1 Developer profile

Developer profile includes the locked semantic fields: -
`company_logo`; - free-text developer description, presented as "Tentang
Developer".

These are profile/content fields and do not create authorization.

## 17.2 Project detail

Project UX preserves Developer Project as a source field compatible with
M03 Listing, including compatible property semantics such as
`building_area`. Project ownership and Listing lifecycle remain
distinct.

## 17.3 Project Media

Project Media semantic boundary is photo/video. UI must not imply that
brochure or pricelist are Project Media when they belong to Marketing
Kit semantics.

## 17.4 Marketing Kit

Marketing Kit is a distinct governed resource for brochure/pricelist
semantics.

Permission presentation: \| Actor \| Scope / action \| \|---\|---\| \|
Developer \| own Upload/Edit/Delete/View \| \| Admin \| All \| \|
Superadmin \| All \| \| Manager \| View + Download \| \| Agent \| View +
Download \| \| Buyer \| None \| \| Partner \| None \|

UI visibility is not authorization enforcement; server-side M10 controls
remain authoritative.

## 17.5 Claim

Claim lifecycle is represented distinctly:

``` text
Pending → Approved / Rejected / Withdrawn / Revoked / Managed
```

Agent may create/withdraw own pending Claim where authorized. Developer
Partner reviews own-project Claims; Admin/Manager/Superadmin provide
governed moderation/override as authorized.

## 17.6 Approval Claim → Listing initialization

An Approved Claim may initialize an Agent-owned Listing context, but
Claim approval does not grant ordinary M03 Listing
Create/Update/Publish/Refresh authority.

## 17.7 M06 UI acceptance

-   company_logo and Tentang Developer are represented.
-   Marketing Kit is separate from Project Media.
-   Marketing Kit action visibility follows the locked matrix while
    enforcement remains M10.
-   Claim status and approval provenance are visible to authorized
    actors.
-   Approved Claim → Listing initialization is distinguishable from
    ordinary Listing creation.

# 18. M07 --- DBR / KPR UX

## 18.1 Calculator and result

DBR remains a pre-screening/assistance result and not lender approval.

## 18.2 Bank Master configuration

Where Bank Master configuration is exposed, the UI treats it as M07
domain configuration. The uploaded impact evidence does not establish a
final physical table implementation; therefore UI must not imply
physical/runtime completion.

Current semantic display constraints remain: - maximum four displayed
banks where configured; - fixed 10 percentage-point bands; -
configurable bank master data is distinct from the calculator result.

## 18.3 M07 UI acceptance

-   DBR result is clearly labeled as pre-screening assistance.
-   Bank Master configuration does not imply lender approval.
-   Physical/runtime representation remains evidence-gated.

# 19. M08 --- DASHBOARD / NOTIFICATION UX

## 19.1 Agent dashboard

Dashboard remains a projection of authoritative domain states.

## 19.2 Dashboard cards

Cards may summarize Listing, Learning, Event, Commercial, Organization,
Awarding and other domain states. A card must not become the source of
business authority.

## 19.3 Notification Center

Notification references are filtered/redacted according to source-domain
visibility. A notification must not become a side-channel around M10 or
source-domain authorization.

Required states: - loading; - populated; - empty; - unauthorized; -
error; - retry-sensitive.

## 19.4 M08 UI acceptance

-   Dashboard/Notification never mutates source-domain business state.
-   Protected details are suppressed when source visibility is absent.
-   Notification actions deep-link only to authorized destinations.

# 20. M09 --- ADMIN UX

## 20.1 Admin dashboard

Administration surfaces are domain-specific and do not create
super-domain authority.

## 20.2 Moderation

Review, Escalate and Manual Correction are distinct operations.
Post-publication moderation must not be converted into an approval gate
for normal M03 publication.

## 20.3 System Configuration

System Configuration is an M09 administrative surface. The exact current
API contract is `GET/PUT /admin/config/system` where evidenced by the
uploaded technical chain. The UI exposes governed configuration values
and effective state without inventing undocumented fields.

## 20.4 Administrative Export

Administrative Export is Superadmin-only under M09-R11. UI must
hide/disable the export action for non-authorized actors, while
M10/server enforcement remains authoritative.

## 20.5 Provider-domain separation

Provider-specific execution remains owned by its domain. M09 may
configure/observe administrative settings but does not acquire provider
execution authority.

## 20.6 M09 UI acceptance

-   System Configuration is clearly administrative.
-   Administrative Export is Superadmin-only.
-   Review/Escalate/Manual Correction remain distinct.
-   No M09 surface becomes an authorization bypass.

# 21. M10 --- RBAC / PERMISSION UX

## 21.1 Role and Role Permission

Role = actor grouping. Role Permission = default/baseline permission
matrix.

## 21.2 Permission Preset

Permission Preset is an optional configurable authorization
configuration targeted to an existing Role. It is never a new Role.

Governed flow:

``` text
Select existing Role
  ↓
Load Role Permission baseline
  ↓
Configure permitted subset / governed scope
  ↓
Validate against baseline and constraints
  ↓
Preview effective permissions
  ↓
Assign / activate
  ↓
Audit
```

A Preset cannot: - create capabilities outside the target Role
baseline; - become a new Role; - bypass ownership; - bypass organization
context; - bypass domain conditions; - create an independent
authorization model.

## 21.3 Preset lifecycle

``` text
NOT CREATED → CREATED → ACTIVE → ASSIGNED → MODIFIED
                                  ↘ REASSIGNED / REPLACED
```

Role changes that make a preset target incompatible must result in the
governed invalid/deny behavior.

## 21.4 Permission denial

Authorization denial remains distinct from visibility. Protected
resource existence must not be leaked merely to explain denial.

## 21.5 M10 UI acceptance

-   Preset List/Create/Edit/Assign is represented for authorized
    governance actors.
-   Baseline matrix is loaded from the target Role.
-   Effective-permission preview is available.
-   Invalid out-of-baseline capability injection is rejected.
-   UI never claims RLS/runtime enforcement merely because a control is
    hidden.

# 22. M11 --- SEO / PUBLIC DISCOVERY / ANALYTICS UX

## 22.1 Mandatory public discovery surfaces

The M11 public-discovery inventory is exactly ten surfaces: 1. Homepage
2. Listing 3. Agent 4. Organization 5. Developer / Project 6. Event 7.
Learning 8. Learning Session 9. Static Public Content 10. Announcement /
Promotion

Static Public Content and Announcement / Promotion are mandatory M11
public discovery surfaces.

## 22.2 Ownership boundary

M11 owns discovery, SEO and measurement. Lifecycle/configuration of
Static Public Content and Announcement/Promotion remains M09 or the
applicable authoritative domain.

## 22.3 Public SEO behavior

Public indexability, canonical representation, metadata, sitemap
participation and measurement are shown according to the authoritative
visibility/indexability state. SEO visibility is not authorization.

## 22.4 Analytics

Analytics events are observational and never create business authority.

## 22.5 M11 UI acceptance

-   All ten surfaces are represented in the discovery model.
-   Static Public Content and Announcement/Promotion are not omitted.
-   Public discovery is not used to infer authorization.
-   Measurement remains non-authoritative.

# 23. M12 --- ORGANIZATION UX

## 23.1 Organization context

Organization context is separate from Personal Context. Membership is
not ownership, entitlement, Host, Instructor or management authority.

## 23.2 Members and lifecycle

Organization membership and invitation/join-request flows remain
governed by M12. Acceptance creates membership but does not
automatically create ownership or commercial entitlement.

## 23.3 Lead Exit / closure

The lifecycle is explicitly:

``` text
ACTIVE → CLOSING → CLOSED
```

Lead Exit does not create a Lead Transfer or successor privilege
inheritance model.

## 23.4 Public content

Organization Public Content ownership remains an M12 boundary while M11
owns public discovery/measurement.

## 23.5 Cross-domain dependencies

Organization-aware UI may consume: - M03 Listing ownership/lifecycle; -
M10 authorization; - M11 public discovery; - M14 commercial
entitlement/quota.

It must not create local authorization or quota rules.

## 23.6 M12 UI acceptance

-   Lead Exit visibly resolves through CLOSING before CLOSED.
-   No successor privilege inheritance is implied.
-   Membership does not imply ownership/entitlement/Host/Instructor.
-   Physical `ORG-ADMIN` labels are not presented as a new platform
    Role.

# 24. M13 --- AI BYOK / PROVIDER UX

## 24.1 AI connection

BYOK ownership is Agent/User / OWN. The UI must not present provider
connection existence as proof of authorization to invoke every
capability.

## 24.2 Provider Catalogue

Provider Catalogue mutation is Superadmin-only. Historical
"Admin-curated" wording must not be used as current authority.

## 24.3 Provider lifecycle

Provider connection lifecycle states remain source-bound:

``` text
CREATE → UNVERIFIED → VALID / ACTIVE
                  ↘ INVALID / ERROR
ACTIVE → DISABLED / REVOKED / DISCONNECTED / DELETED
```

Temporary provider outage does not itself transfer ownership or revoke
the connection.

## 24.4 AI Assistant

AI Assistant remains assistive. It cannot create authorization, payment,
completion, qualification, award or other canonical business outcomes.

## 24.5 Responsive and error behavior

Provider lifecycle and error states must be represented separately on
Desktop and Mobile. Raw user credentials/secrets are never exposed.

## 24.6 M13 UI acceptance

-   Provider Catalogue mutation is visibly Superadmin-only.
-   BYOK ownership is Agent/User / OWN.
-   Connection lifecycle states are explicit.
-   Provider outage is not conflated with ownership/revocation.
-   AI remains assistive and non-authoritative.

# 25. M14 --- COMMERCIAL / PAYMENT / ENTITLEMENT / QUOTA UX

## 25.1 Commercial surfaces

Preserve the eight approved commercial surfaces from the current M14
contract while maintaining the separation:

``` text
Product / Offer
→ Order / Checkout
→ Pending Payment
→ Processing
→ Confirmed / Failed / Expired / Cancelled
→ Fulfillment
→ Entitlement
→ Quota / Benefit
→ Reconciliation
```

## 25.2 Payment state

Provider callbacks/evidence are not themselves client-side confirmation.
`confirmed_at` is shown only after trusted verification.

## 25.3 Immutable purchase snapshot

Historical purchases render their purchase snapshot. Current
configuration changes must not silently rewrite historical commercial
outcomes.

## 25.4 Entitlement and quota

Entitlement is not RBAC. Quota/benefit is not a permission. Commercial
state is shown separately from authorization.

## 25.5 Refresh Allowance

M14 owns the configurable commercial allowance value. M03 owns Refresh
action/eligibility/consumption and M10 owns authorization. The UI may
expose the allowance and remaining capacity, but must not move the
Refresh action into M14.

Canonical values: - default = 5 successful Refreshes / Agent /
operational day; - configurable by authorized Superadmin through the
commercial configuration boundary; - Asia/Jakarta operational day; - no
carry-forward; - one successful Refresh per Listing per operational
day; - no regional Refresh quota.

## 25.6 Reconciliation

Reconciliation UI is evidence/case-oriented and authorized operations
only. It does not silently remediate or rewrite historical purchases.

## 25.7 M14 Q boundary

Q01-Q64 remain M14. They must not be represented as M15
qualification/award questions.

## 25.8 M14 UI acceptance

-   Payment, Entitlement and RBAC are distinct.
-   Confirmed state follows trusted verification.
-   Historical purchase snapshot is preserved.
-   Refresh allowance is displayed as commercial capacity while M03
    remains action owner.
-   Q01-Q64 remain within M14 scope.

# 26. M15 --- QUALIFICATION / EVIDENCE / AWARDING / TITLE UX

## 26.1 Title discovery

Title Definition and Award Instance remain distinct.

## 26.2 Qualification

Qualification evaluates governed evidence and applicable Rule Version.
It does not redefine Learning completion.

## 26.3 Developer Learning evidence

The explicit dependency is:

``` text
Developer Learning
      ↓
M04 Learning-owned evidence
      ↓
M15 Qualification Evidence
      ↓
Qualification
      ↓
Award / Title
```

Partner Learning receives an explicit downstream evidence trace but is
not silently converted into Internal Learning Economy state.

## 26.4 Award

Award is distinct from completion, credential and qualification. Award
Instance snapshots the applicable qualification/rule context according
to M15 authority.

## 26.5 Presentation

Presentation may show qualification, evidence, award and title states
without becoming the source of those outcomes.

## 26.6 M15 UI acceptance

-   Developer Learning → M04 evidence → M15 Qualification Evidence is
    traceable.
-   Partner Learning remains distinct from Internal Learning Economy.
-   Title, Qualification, Award and Presentation states remain separate.
-   M15 does not absorb M14 Q01-Q64. \# 27. CROSS-DOMAIN UX CHAINS

## 27.1 Listing → Commercial → Refresh

``` text
M14 allowance / entitlement
        ↓
M03 Listing Refresh eligibility + action
        ↓
M10 authorization
```

The UI keeps commercial capacity, action ownership and authorization
visually distinct.

## 27.2 Payment → Entitlement

``` text
Order → Checkout → Pending/Processing → trusted verification
→ Confirmed → Fulfillment → Entitlement
```

Payment display does not itself grant entitlement.

## 27.3 Payment → LP

Purchased Learning Points follow the same trusted commercial
verification boundary and remain M04 Learning Economy state.

## 27.4 Session → Learning

Session completion/attendance is distinct from Learning Activity
completion. Event does not own Session.

## 27.5 Learning → Awarding

``` text
M04 Learning completion/evidence
→ M15 Qualification Evidence
→ Qualification
→ Award / Title
```

## 27.6 Organization → Listing

Organization context may influence authorized Listing context, but
membership does not itself transfer ownership or entitlement.

## 27.7 Organization → Session

Organization context may support Host/Instructor operations only where
the corresponding capabilities are authorized. Host ≠ Instructor.

## 27.8 Developer Claim → Listing

``` text
M06 Claim
→ Approved Claim
→ Agent-owned Listing initialization
→ M03 Listing lifecycle
```

Claim approval does not grant ordinary Listing
Create/Update/Publish/Refresh.

## 27.9 Public content → Discovery

``` text
M09 / owning domain lifecycle
→ M11 discovery representation
→ SEO / measurement
```

M11 does not own administrative content lifecycle.

## 27.10 Provider / AI

``` text
M13 Provider Catalogue / BYOK
→ M13 AI Assistant
```

AI remains assistive and cannot create canonical authorization, payment,
completion or award outcomes. \# 28. FORM UX STANDARDS

## 28.1 Labels

Every field has a visible label.

Placeholder is not the label.

## 28.2 Validation

Validate:

``` text
client-side
+
server-side
```

Client validation is convenience only.

## 28.3 Error placement

Errors appear:

-   adjacent to field;
-   summary at top for long forms;
-   preserved after server rejection.

## 28.4 Dirty-state protection

For multi-step forms:

``` text
Unsaved changes
→ Save Draft / Leave / Cancel
```

## 28.5 File upload

Show:

``` text
filename
size
upload progress
validation
retry
delete
privacy classification
```

------------------------------------------------------------------------

# 29. TABLE / DATA-DENSE UX

Use tables for operational workflows:

-   Admin queues;
-   Users;
-   Listings;
-   Orders;
-   Payments;
-   Reconciliation;
-   Entitlements;
-   Organization members;
-   Session evidence;
-   Awarding operations.

Mobile behavior:

``` text
table
→ card/list representation
```

Do not force horizontal scrolling when a responsive card representation
is clearer.

------------------------------------------------------------------------

# 30. SEARCH / FILTER UX

## 30.1 Public Listing

Filters use AND logic.

Show active filters as removable chips.

URL query state should be shareable.

## 30.2 Admin

Provide:

``` text
Search
Filter
Sort
Date range
Status
Owner/context
```

## 30.3 Learning

Filters:

``` text
Free/Paid
Level
Type
Progress
Eligibility
```

------------------------------------------------------------------------

# 31. NOTIFICATION UX

## 31.1 Notification center

Categories:

``` text
Account
Listing
Learning
Session
Organization
Commercial
Awarding
System
```

## 31.2 Priority

``` text
Critical
Action required
Informational
```

## 31.3 Notification authority

Notification content must reflect authoritative domain state.

If payment is still pending:

> Pembayaran sedang diproses.

Not:

> Pembayaran berhasil.

------------------------------------------------------------------------

# 32. ACCESSIBILITY

Target:

**WCAG 2.2 AA-oriented UX baseline.**

Requirements:

-   keyboard navigable;
-   visible focus;
-   semantic headings;
-   form labels;
-   error association;
-   accessible names for controls;
-   sufficient contrast;
-   no color-only status;
-   alt text for meaningful images;
-   decorative images ignored by assistive technology;
-   modal focus trapping;
-   escape behavior where appropriate;
-   screen-reader-friendly status updates;
-   reduced-motion support;
-   touch targets sufficiently large;
-   accessible charts with text summaries;
-   accessible map fallback/list view;
-   accessible file-upload feedback.

------------------------------------------------------------------------

# 33. RESPONSIVE DESIGN

## 33.1 Breakpoint behavior

Use content-driven breakpoints rather than device-specific assumptions.

### Desktop

-   sidebar;
-   multi-column dashboards;
-   full tables;
-   side-by-side forms.

### Tablet

-   collapsible sidebar;
-   reduced columns;
-   responsive tables.

### Mobile

-   bottom/top navigation;
-   cards;
-   stacked forms;
-   sticky primary CTA where useful;
-   drawers instead of large desktop modals.

## 33.2 Mobile critical flows

Must remain fully usable:

-   login;
-   registration;
-   listing creation;
-   listing publish/review;
-   WhatsApp CTA;
-   Learning Activity;
-   Session join;
-   Organization invite;
-   commercial checkout;
-   payment status;
-   LP view;
-   DBR;
-   notifications.

------------------------------------------------------------------------

# 34. PERFORMANCE UX

## 34.1 Perceived performance

Use:

-   skeletons;
-   optimistic UI only for non-authoritative cosmetic state;
-   lazy media;
-   progressive image loading;
-   pagination/infinite scroll where appropriate.

## 34.2 Authoritative mutations

Do not optimistically display irreversible business outcomes such as:

``` text
Payment Confirmed
LP Granted
Award Issued
Session Completed
Listing Published
```

until authoritative response is received.

------------------------------------------------------------------------

# 35. SECURITY / PRIVACY UX

Protect:

-   KTP;
-   NPWP;
-   legal documents;
-   payment information;
-   provider credentials;
-   BYOK credentials;
-   private Organization information;
-   private Learning data;
-   private Session evidence;
-   admin data.

Mask sensitive information.

Never expose API keys in UI after secure storage.

Never expose private data through analytics dashboards without
authorized scope.

The current SEO/Analytics baseline explicitly requires protection of
identity documents, credentials, payment information, private
Organization/Learning/Session data and administrative information.

------------------------------------------------------------------------

# 36. ROLE / CONTEXT UX MATRIX

  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Surface / capability     Superadmin        Admin                 Manager               Agent             Developer         Buyer            Partner          Organization context
  ------------------------ ----------------- --------------------- --------------------- ----------------- ----------------- ---------------- ---------------- --------------------
  M01 authentication       governed          governed              governed              own               own               own              own              not determinant

  M02 profile/public CTA   override where    governed moderation   governed moderation   own               own where         own              own              contextual
                           locked                                                                          applicable                                          

  M03 Listing              All governed      governed scope        governed scope        own               domain-specific   view             view             may constrain scope
                           scope                                                                                                                               

  M03 Refresh              bypass where      none                  none                  own               none              none             none             no automatic quota
                           authorized                                                                                                                          

  M04 Learning             governance where  governance where      governed              own               own               own              own              contextual
                           authorized        authorized                                                                                                        

  M05 Event                governance where  governed              governed              own participation governed scope    own              own              contextual
                           authorized                                                                                        participation    participation    

  M06 Marketing Kit        All               All                   View+Download         View+Download     own CRUD          none             none             scope-aware

  M06 Claim                All governed      moderation/override   moderation/override   own               own-project       view where       view where       contextual
                                                                                         create/withdraw   review            allowed          allowed          

  M07 DBR                  governed config   governed config       governed scope        own               own               own              own              contextual

  M08                      projection        projection            projection            projection        projection        projection       projection       visibility-aware
  dashboard/notification                                                                                                                                       

  M09 Administrative       Superadmin-only   none unless           none unless           none              none              none             none             not
  Export                                     separately authorized separately authorized                                                                       membership-derived

  M10 Permission Preset    full governance   none                  Agent-targeted        no management     no management     no management    no management    cannot bypass
                                                                   governance                                                                                  context

  M11 public discovery     view              view                  view                  view              view              view             view             public

  M12 membership           governed          governed              governed              own/contextual    own/contextual    own/contextual   own/contextual   membership ≠
                                                                                                                                                               ownership

  M13 Provider Catalogue   Superadmin-only   none                  none                  none              none              none             none             not
  mutation                                                                                                                                                     membership-derived

  M13 BYOK                 governed where    none                  none                  own               own where         none             none             account-owned
                           authorized                                                                      authorized                                          

  M14 commercial           governance        governed              governed              own               own where         own              own              entitlement separate
                                                                                                           applicable                                          

  M15 qualification/award  governance        governed              governed              own/view          own/view          own/view         own/view         evidence-aware
  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

UI visibility is never a substitute for M10 server authorization/RLS. \#
37. EMPTY / ERROR / EDGE CASE CATALOG

Every module must support:

### No data

``` text
No results
→ reason
→ next action
```

### Unauthorized

``` text
You don't have permission.
```

### Protected non-existence

Do not disclose protected-resource details.

### Expired

``` text
This item is no longer active.
```

### Rejected

Show reason when user is authorized to see it.

### Pending

Explain what is waiting and what user can do.

### Failed

Explain whether retry is safe.

### Duplicate request

Show existing outcome rather than creating a second result.

### Offline / network interruption

Do not claim authoritative mutation success.

------------------------------------------------------------------------

# 38. ANALYTICS INSTRUMENTATION UX RULES

UI events may include:

``` text
page_view
listing_view
listing_filter
listing_share
whatsapp_cta_click
learning_activity_start
learning_activity_complete
session_view
session_join_click
event_registration
commercial_offer_view
checkout_start
payment_provider_return
```

These are observational.

Never equate:

``` text
checkout_start = payment
join_click = attendance
activity_complete_event = authoritative completion
award_view = award creation
```

The current SEO/Analytics baseline explicitly maintains this
observation-only boundary.

------------------------------------------------------------------------

# 39. UI / API / DATA BOUNDARY

UI must consume:

``` text
API contract
→ server authority
→ domain state
```

UI must not invent:

-   IDs;
-   permissions;
-   entitlement;
-   scope;
-   completion;
-   attendance;
-   payment confirmation;
-   LP balance;
-   Award.

The current API v2.0 is the contract authority and explicitly preserves
retry-sensitive idempotency and first-class reconciliation.

------------------------------------------------------------------------

# 40. UI / RLS BOUNDARY

If the backend returns no protected resource, UI must not infer its
existence.

For scoped Organization data:

``` text
current context
+
permission
+
scope
+
RLS
```

must determine visibility.

UI context switcher is not itself a security boundary.

------------------------------------------------------------------------

# 41. LEGACY UX PRESERVATION MATRIX

  Legacy capability      UI preserved Wave 3 synchronization
  -------------------- -------------- ---------------------------------------
  Registration / OTP                ✓ status clarity
  Login                             ✓ role/context
  Profile                           ✓ achievements
  Review                            ✓ moderation/self-review
  Listing                           ✓ Personal/Organization context + quota
  Listing media                     ✓ duplicate-image warning
  Listing search                    ✓ SEO/analytics
  Developer                         ✓ no exclusivity
  Project                           ✓ listing integration
  DBR                               ✓ fixed 10pp bands
  Course                            ✓ Learning Activity
  Lesson                            ✓ Activity completion
  Quiz                              ✓ assessment boundary
  Course Enrollment                 ✓ distinct from Session Enrollment
  Certificate                       ✓ distinct from Award
  Event                             ✓ distinct from Session
  Event Registration                ✓ distinct from Session Enrollment
  Organization                      ✓ context switcher
  Notifications                     ✓ domain states
  Admin                             ✓ expanded Commercial/Awarding/Session
  RBAC                              ✓ Capability + Permission + Scope
  AI BYOK                           ✓ credential isolation
  SEO                               ✓ public/private
  Analytics                         ✓ observation only
  Commercial                      --- synchronized
  Payment                         --- synchronized
  Entitlement/Quota               --- synchronized
  Learning Economy                --- synchronized
  Learning Session                --- synchronized
  Title/Awarding                  --- synchronized

------------------------------------------------------------------------

# 42. ACCEPTANCE CRITERIA

## Global

-   Full integrated UI/UX version, not patch/addendum.
-   Frozen Core v1.3 detail is preserved unless explicitly superseded by
    authoritative M01--M15 evidence.
-   PRD, Functional, User Flow and Technical successor contracts remain
    semantically aligned.
-   UI visibility is not authorization.
-   Physical/runtime gaps are controlled residuals, not silently
    converted into semantic PASS.

## M01

-   OTP success → ACTIVE.
-   Conditional KTP/deferred completion is represented as
    eligibility/requirement.
-   No default Pending Review gate.

## M02

-   Review flow presents AUTO-APPROVE → Published/Viewable where
    governed.
-   Post-publication moderation is separate.
-   Public CTA is explicit opt-in; Superadmin override is
    administrative.

## M03

-   Normal publication has no Pending Review gate.
-   Refresh allowance is visible.
-   Default 5 successful Refreshes/Agent/operational day.
-   Asia/Jakarta reset and no carry-forward are represented.
-   Maximum one successful Refresh/Listing/day.
-   Failed Refresh does not consume allowance.
-   District-local repositioning and deterministic tie-break are
    represented.
-   Refresh remains M03 action authority.

## M04

-   Learning Economy/LP states are represented.
-   Learning completion, redemption, skill, credential and assessment
    states are distinct.
-   M04 remains Learning authority; M15 consumes evidence.

## M05

-   participant_mode is represented without turning it into
    Role/permission/identity.
-   Guest registration and contact destination are distinct from
    canonical identity.
-   Event, Registration and Session Enrollment remain distinct.

## M06

-   company_logo and "Tentang Developer" are represented.
-   Project Media = photo/video.
-   Marketing Kit is separate and has the locked action matrix.
-   Claim lifecycle and Approved Claim → Agent-owned Listing
    initialization are represented.
-   Claim does not grant ordinary M03 Listing authority.

## M07

-   DBR is labeled pre-screening assistance, not lender approval.
-   Bank Master display/configuration semantics are represented where
    applicable.
-   Physical realization remains evidence-gated.

## M08

-   Dashboard and Notification remain projections.
-   Source visibility filtering/redaction is represented.
-   No notification side-channel bypass.

## M09

-   System Configuration is represented as administrative configuration.
-   Administrative Export is Superadmin-only.
-   Review/Escalate/Manual Correction remain distinct.
-   No super-domain authority is implied.

## M10

-   Role, Role Permission and Permission Preset are distinct.
-   Preset targets an existing Role.
-   Preset cannot exceed baseline capabilities.
-   Preset configuration includes validation, effective-permission
    preview, assignment and audit.
-   UI does not claim RLS/runtime proof.

## M11

-   Exactly ten mandatory public discovery surfaces are represented.
-   Static Public Content and Announcement/Promotion are included.
-   M11 owns discovery/measurement; owning domains own
    lifecycle/configuration.
-   Analytics remains observational.

## M12

-   Personal Context and Organization Context are distinct.
-   Membership is not ownership/entitlement/Host/Instructor.
-   Lead Exit → CLOSING → CLOSED is represented.
-   No successor privilege inheritance.
-   ORG-ADMIN terminology does not create a new platform Role.

## M13

-   Provider Catalogue mutation is Superadmin-only.
-   BYOK ownership is Agent/User / OWN.
-   Provider lifecycle and outage states are distinct.
-   AI Assistant remains assistive/non-authoritative.

## M14

-   Commercial lifecycle states are complete and ordered.
-   Payment confirmation follows trusted verification.
-   Historical purchase snapshot is preserved.
-   Entitlement/quota are distinct from RBAC.
-   Refresh Allowance is additive M14 configuration; M03 remains action
    owner.
-   Q01-Q64 remain M14.

## M15

-   Title, Qualification, Evidence, Award and Presentation remain
    distinct.
-   Developer Learning → M04 evidence → M15 Qualification Evidence is
    represented.
-   Partner Learning remains distinct from Internal Learning Economy.
-   M15 does not absorb M14 Q01-Q64.

## 42.9 M14 REFRESH CONFIGURATION UX — EXPLICIT COMMERCIAL PARAMETER
STEP13-E exposes the Refresh allowance as a configurable commercial parameter in the
administrative/commercial configuration surface. The UI label is **Daily Refresh Allowance**;
the value is not hard-coded by the UI and is supplied by the authoritative commercial
configuration. The default semantic value is **5 successful Refreshes per Agent per
Asia/Jakarta operational day**, with no carry-forward. The UI also communicates the
per-Listing limit of one successful Refresh per operational day. M14 owns the commercial
allowance/configuration; M03 owns Listing/Refresh action enforcement; M10 owns
authorization. No physical configuration key, endpoint, table, or runtime proof is
invented here.

## 42.10 M04 LEARNING ECONOMY CAPABILITY AFFORDANCE COVERAGE
Where the current authoritative M04 evidence defines capability-level operations such as
Skill Verify, Skill Issue, Skill Manage, Learning Economy Redemption, LearningPath
Configure/Progression Manage, Credential Issue/Manage, and Learning Reconciliation,
STEP13-E provides the corresponding UI/UX affordance/state concepts while keeping exact
routes and physical identifiers evidence-gated. UI presence is not authorization proof.

# 43. TRACEABILITY

## 43.1 STEP13-E module delta coverage

  -------------------------------------------------------------------------------------------
  Module            Required successor UI/UX delta      Source alignment   Treatment
  ----------------- ----------------------------------- ------------------ ------------------
  M01               Conditional KTP; OTP→ACTIVE; remove STEP13-A/B/C/D +   INTEGRATED
                    default gate                        PRE-00             

  M02               AUTO-APPROVE; post-publication      STEP13-A/B/C/D +   INTEGRATED
                    moderation; CTA override            PRE-00             

  M03               no Pending Review publication; full STEP13-A/B/C/D +   INTEGRATED
                    Refresh UX                          M03 impact         

  M04               Learning Economy, redemption/skill, STEP13-A/B/C/D +   INTEGRATED / exact
                    Learning→evidence boundary          M04 impact         routes
                                                                           evidence-gated

  M05               participant_mode, Guest semantics   STEP13-A/B/C/D +   INTEGRATED
                                                        PRE-00             

  M06               Developer fields, Project/Media,    M06 v1.5 +         INTEGRATED
                    Marketing Kit, Claim                STEP13-A/B/C/D     

  M07               DBR boundary, Bank Master           M07 impact +       INTEGRATED /
                    display/config                      STEP13-A/B/C/D     physical residual

  M08               projection/redaction/notification   M08 impact +       INTEGRATED
                    boundary                            STEP13-A/B/C/D     

  M09               System Config, Admin Export,        M09 impact +       INTEGRATED
                    moderation boundaries               STEP13-A/B/C/D     

  M10               Permission Preset UX                M10 impact +       INTEGRATED /
                                                        STEP12 +           physical residual
                                                        STEP13-A/B/C/D     

  M11               ten mandatory public surfaces       M11 impact +       INTEGRATED
                                                        PRE-00 +           
                                                        STEP13-A/B/C/D     

  M12               Lead Exit/closure,                  M12 impact +       INTEGRATED
                    context/membership boundaries       STEP13-A/B/C/D     

  M13               Provider Catalogue Superadmin-only, M13 impact +       INTEGRATED /
                    BYOK ownership/lifecycle            STEP13-A/B/C/D     physical/runtime
                                                                           residual

  M14               commercial lifecycle, Refresh       M14 impact +       INTEGRATED
                    Allowance, Q01-Q64                 STEP13-A/B/C/D     

  M15               Developer Learning evidence         M15 impact +       INTEGRATED
                    dependency                          STEP13-A/B/C/D     
  -------------------------------------------------------------------------------------------

## 43.2 Screen ↔ Flow ↔ Capability ↔ Authorization matrix

  ----------------------------------------------------------------------------------------
  UI family             Flow dependency   Capability boundary            Authorization
                                                                         source
  --------------------- ----------------- ------------------------------ -----------------
  Registration / OTP    M01               Authentication                 M01 + M10

  Profile / Public      M02               Profile visibility/CTA         M02 + M10
  Profile                                                                

  Listing               M03               Listing lifecycle              M03 + M10

  Listing Refresh       M03 + M14         Refresh action/allowance       M03 + M10

  Learning / LP         M04               Learning Activity/Economy      M04 + M10

  Event / Registration  M05               Event capability               M05 + M10

  Developer / Project   M06               Project/Developer              M06 + M10

  Marketing Kit         M06               resource-specific CRUD/view    M06 + M10

  Claim                 M06               Claim lifecycle                M06 + M10

  DBR                   M07               pre-screening                  M07 + M10

  Dashboard /           M08               projection                     source domain +
  Notification                                                           M10

  Admin                 M09               configuration/audit/export     M09 + M10

  Permission Preset     M10               preset governance              M10

  Public discovery      M11               SEO/measurement                M11 + source
                                                                         visibility

  Organization          M12               membership/context             M12 + M10

  AI / Provider         M13               BYOK/provider governance       M13 + M10

  Commercial            M14               payment/entitlement/quota      M14 + M10

  Qualification/Award   M15               evidence/qualification/award   M15 + M10
  ----------------------------------------------------------------------------------------

## 43.3 State / interaction coverage

Every consequential screen must cover, where applicable:
`loading → populated → empty → unauthorized → validation error → domain error → retry → success → destructive confirmation → authoritative result`.

Domain-specific state transitions are governed by the M01--M15 module
tables above.

## 43.4 Core v1.3 preservation

Core v1.3 remains immutable. This document is a successor candidate
derived from Core v1.3 plus approved M01--M15 reconciliation evidence;
it does not mutate the Core artifact. \# 44. CONTROLLED UX RESIDUAL
REGISTER

  --------------------------------------------------------------------------------------------------
  ID                Residual                                     Classification    STEP13-E
                                                                                   treatment
  ----------------- -------------------------------------------- ----------------- -----------------
  E-R01             M04 exact Skill Verify/Issue/Manage route    CONTROLLED API    UI capability
                    identifiers not evidenced                    residual          semantics
                                                                                   integrated; no
                                                                                   route invented

  E-R02             M04 exact Learning Economy Redemption route  CONTROLLED API    UI flow
                    identifier not evidenced                     residual          integrated; route
                                                                                   remains
                                                                                   evidence-gated

  E-R03             Other M04 exact route identifiers for        CONTROLLED API    capability states
                    Path/Progression/Credential/Reconciliation   residual          integrated; no
                    not evidenced                                                  identifiers
                                                                                   invented

  E-R04             M10 Permission Preset physical tables/route  CONTROLLED        full UX model
                    identifiers not fully evidenced              physical/API      integrated; no
                                                                 residual          physical object
                                                                                   invented

  E-R05             M07 Bank Master physical representation not  CONTROLLED        UI semantics
                    evidenced                                    physical residual integrated
                                                                                   without physical
                                                                                   claim

  E-R06             M06 Marketing Kit/Claim physical realization CONTROLLED        semantic UI
                    not evidenced                                physical residual integrated; no
                                                                                   schema invented

  E-R07             M13 Provider OAuth/webhook/deployment exact  CONTROLLED        lifecycle UI
                    bindings not fully evidenced                 API/runtime       integrated; no
                                                                 residual          route invented

  E-R08             M12 exact Invitation Revoke / Join Request   CONTROLLED API    semantic UI
                    Cancel / closure-confirm-OTP / Organization  residual          integrated; no
                    Settings route identifiers not fully                           route invented
                    evidenced                                                      

  E-R09             Runtime authorization/RLS correctness        NOT VERIFIED      UI never claims
                                                                                   runtime
                                                                                   enforcement

  E-R10             RLS policy-row completeness on some current  CONTROLLED        no semantic UI
                    physical surfaces                            readiness         blocker
                                                                 residual          

  E-R11             Core package internal path/version label     CONTROLLED        successor
                    drift                                        provenance        manifest records
                                                                                   source identity;
                                                                                   frozen Core
                                                                                   untouched
  --------------------------------------------------------------------------------------------------

No residual above is treated as permission to invent endpoints, tables,
SQL, production authorization or runtime proof. \# 45. HISTORICAL WAVE 3
UI/UX HANDOFF --- PROVENANCE ONLY

Step 3.11 must consume this document as the current UI/UX authority.

It must not:

-   remove unaffected legacy flows;
-   merge distinct domain states;
-   turn payment UI into authorization;
-   infer Host from Instructor;
-   infer entitlement from role;
-   infer completion from analytics;
-   infer attendance from provider callback alone;
-   infer Award from Certificate;
-   infer Session Enrollment from Event Registration;
-   expose private resources through SEO;
-   expose credentials;
-   introduce automatic provider failover;
-   invent new Owner decisions.

Recommended downstream order:

``` text
W3-10 UI/UX
      ↓
W3-11 Technical Specification
      ↓
W3-12 Cross-Artifact Reconciliation
      ↓
W3-13 Implementation / Migration Readiness
      ↓
W3-14 Controlled Execution
```

------------------------------------------------------------------------

# 46. HISTORICAL WAVE 3 STEP 3.10 GATE --- PROVENANCE ONLY

## Result

**Historical result: GREEN --- FULL UI/UX CONSOLIDATION /
SYNCHRONIZATION COMPLETE**

### Gate checklist

-   [x] PRD v2.0 consumed.
-   [x] User Flow v2.0 consumed.
-   [x] Entity Mapping v2.0 consumed.
-   [x] ERD v2.0 consumed as downstream structural constraint.
-   [x] Database Dictionary v2.1 consumed as data presentation
    constraint.
-   [x] API v2.0 consumed as interaction boundary.
-   [x] RBAC/RLS v2.0 consumed.
-   [x] SEO/Analytics v2.0 consumed.
-   [x] Legacy UX preserved.
-   [x] MAEP/AEP UX synchronized.
-   [x] Commercial/Payment synchronized.
-   [x] Learning Economy synchronized.
-   [x] Learning Session synchronized.
-   [x] Organization synchronized.
-   [x] Title/Awarding synchronized.
-   [x] Authorization boundaries synchronized.
-   [x] Public/private/SEO boundary synchronized.
-   [x] Accessibility baseline included.
-   [x] Responsive/mobile behavior included.
-   [x] Loading/error/empty/edge states included.
-   [x] Historical/provenance UX included.
-   [x] No current Owner-level MADCR/OD unresolved.
-   [x] No stale decision reopened.
-   [x] No production implementation authorization implied.
-   [x] Full replacement-level master, not patch.

------------------------------------------------------------------------

# 47. HISTORICAL WAVE 3 CHECKPOINT --- PROVENANCE ONLY

``` text
W3-01 PRD                  🟢
W3-02 User Flow            🟢
W3-03 Entity Mapping       🟢
W3-04 ERD                  🟢
W3-05 Database Dictionary  🟢
W3-06 API                  🟢
W3-07 RBAC / RLS           🟢
W3-08 SEO / Analytics      🟢
W3-09 Functional           🟢
W3-10 UI / UX              🟢 COMPLETE
────────────────────────────────────
NEXT → W3-11 TECHNICAL SPECIFICATION
```

------------------------------------------------------------------------

# 48. HISTORICAL WAVE 3 CANONICAL CHAIN --- PROVENANCE ONLY

``` text
OWNER DECISION / BR
        ↓
PRD v2.0
        ↓
USER FLOW v2.0
        ↓
ENTITY MAPPING v2.0
        ↓
ERD v2.0
        ↓
DATABASE DICTIONARY v2.1
        ↓
API v2.0
        ↓
RBAC / PERMISSION / RLS v2.0
        ↓
SEO / ANALYTICS v2.0
        ↓
FUNCTIONAL SPECIFICATION v2.0
        ↓
UI / UX SPECIFICATION v2.0
        ↓
W3-11 TECHNICAL SPECIFICATION
```

**END OF HISTORICAL RUMAHAGEN UI / UX SPECIFICATION v2.0 --- WAVE 3 STEP
3.10**

# 49. STEP13-E CURRENT INTERFACE RECONCILIATION

## 49.1 Current semantic updates propagated

The successor UI/UX now explicitly carries all identified M01--M15
deltas from the uploaded reconciliation chain, including the previously
absent or stale Core UI/UX areas: - M01 Conditional KTP / OTP→ACTIVE; -
M02 AUTO-APPROVE and post-publication moderation; - M03
no-Pending-Review publication and complete Refresh presentation; - M04
Learning Economy / redemption / skill and evidence boundary; - M05
participant_mode; - M06 company_logo / Tentang Developer / Project Media
/ Marketing Kit / Claim; - M07 DBR and Bank Master presentation
boundary; - M08 projection/redaction; - M09 Administrative Export and
System Configuration; - M10 Permission Preset; - M11 ten public
discovery surfaces; - M12 Lead Exit → CLOSING → CLOSED; - M13 Provider
Catalogue and BYOK authority; - M14 commercial lifecycle and additive
Refresh Allowance; - M15 Developer Learning → M04 evidence → M15
Qualification Evidence.

## 49.2 Core v1.3 preservation

The uploaded Core v1.3 package is treated as immutable/reference. This
successor specification preserves the unaffected Core UX and supersedes
only the current successor-candidate wording that is contradicted or
incomplete according to authoritative M01--M15 evidence.

## 49.3 No authority inversion

M01--M15 ownership remains unchanged. UI paths expose capability but do
not create capability.

## 49.4 No physical/runtime overclaim

No UI statement in this successor specification is evidence of executed
schema migration, RLS policy enforcement, provider credentials,
production deployment or runtime authorization. \# 50. WIREFRAME /
VISUAL ARTIFACT BOUNDARY

UI/UX Specification is the **interface behavior authority**. Wireframes,
high-fidelity mockups and visual prototypes are derived representations
of this contract.

Rules:

1.  A wireframe may clarify layout, hierarchy, navigation and
    interaction, but may not change business semantics.
2.  A wireframe may not create a new role, permission, entity, API
    resource, state or provider authority.
3.  Wireframes may be organized by screen family and
    journey/work-package, while the system remains one integrated
    M01--M15 application.
4.  Shared global shell, design-system components, state patterns,
    accessibility and responsive rules remain reusable across module
    screens.
5.  A screen exists because a governed user journey or operational
    capability needs a surface; a new screen does not imply a new
    module.
6.  Visual details such as exact colors, typography, spacing and copy
    remain implementation/design-system details unless explicitly frozen
    by a governing artifact.
7.  Before implementation, any wireframe must be checked against this
    6.20 contract and the current PRD/User
    Flow/Functional/Technical/API/RBAC sources.

## 50.1 Screen-family decomposition

``` text
Global Shell / Navigation / Context
├─ M01 Identity & Authentication
├─ M02 Agent Profile & Reviews
├─ M03 Listing & Discovery
├─ M04 Learning Core / Economy / Session
├─ M05 Event Calendar
├─ M06 Developer / Project
├─ M07 DBR / KPR
├─ M08 Dashboard / Notifications
├─ M09 Admin / Configuration / Audit
├─ M10 Authorization / Permission Operations
├─ M11 Public SEO / Analytics
├─ M12 Organization
├─ M13 AI BYOK
├─ M14 Commercial / Payment / Entitlement / Quota
└─ M15 Title / Awarding
```

This decomposition is an execution/design organization only. It does not
create independent applications or duplicate authorities.

## 50.2 Required wireframe states

Every stateful screen family must account for, where applicable:

``` text
Loading
Empty
Ready
Pending
Success / Confirmed
Rejected
Failed
Expired
Unauthorized
Protected non-existence
Retry / recovery
Offline / interrupted
```

The authoritative server state remains the source of truth.

# 51. CARRY-FORWARD AUDIT --- W4-02A.6.20

  -----------------------------------------------------------------------------------------------------------------------------
  Field                               Result
  ----------------------------------- -----------------------------------------------------------------------------------------
  Predecessor artifact                `RUMAHAGEN_UI_UX_SPECIFICATION_v2.0_WAVE3_STEP3.10_FULL_CONSOLIDATED_SYNCHRONIZED.md`

  New artifact                        `RUMAHAGEN_W4-02A.6.20_UI_UX_SPECIFICATION_CURRENT_INTERFACE_BEHAVIOR_CONTRACT_v2.1.md`

  Content units reviewed              48 numbered predecessor sections, including subsections, screen families, interaction
                                      patterns, state rules, matrices, acceptance criteria, traceability, residuals, handoff
                                      and gate

  CARRY FORWARD                       All valid predecessor UX principles, information architecture, app shell, design
                                      foundation, component library, state presentation, M01--M15 UX, cross-domain chains,
                                      form/table/search/notification/accessibility/responsive/performance/security rules,
                                      matrices, acceptance criteria and historical boundaries

  UPDATE                              Current W4-02A.6.10--6.19 authority chain; current PRD/User
                                      Flow/API/RBAC/ERD/Dictionary/Functional/Technical versions; current Session
                                      taxonomy/lifecycle; current Commercial/Payment/Midtrans closure; current Host/Instructor
                                      and Organization boundaries; current runtime boundary; W4 gate

  SUPERSEDE                           Wave 3 v2.0 current-state/version labels as current authority

  HISTORICAL / PROVENANCE             Wave 3 Step 3.10 chronology and older AEP/UX states remain historical where retained;
                                      stale OPEN/DEFERRED wording is not current authority

  REMOVED                             0 valid predecessor content intentionally removed

  Missing valid content               0 identified

  Untraced new substantive content    0

  Material conflict                   0 unresolved

  Owner decision required             0

  Audit result                        **PASS**
  -----------------------------------------------------------------------------------------------------------------------------

### 51.1 Carry-forward completeness statement

The predecessor was treated as a complete UX master, not a delta source.
No valid screen family, UX principle, interaction state, accessibility
rule, responsive rule, security/privacy rule, acceptance criterion or
cross-domain boundary was removed merely because it was unaffected by
the current W4 synchronization. New material is limited to
current-source reconciliation, the wireframe/interface-authority
boundary, current screen-family decomposition and the mandatory W4
audit/gate.

# 52. INTERNAL CONFLICT SCAN / RECONCILIATION

## Result

**PASS WITH CONTROLLED RESIDUALS**

### Resolved current conflicts

-   M01 default Pending Review activation wording removed.
-   M02 Buyer review Pending moderation gate removed from current
    semantics.
-   M03 normal publication Pending Review gate removed.
-   M13 Admin-curated Provider Catalogue wording replaced by
    Superadmin-only mutation.
-   M13 BYOK ownership normalized to Agent/User / OWN.
-   M14 Refresh allowance moved to commercial entitlement/configuration
    without moving Refresh action ownership.
-   M15 evidence dependency added without moving Learning authority from
    M04.
-   M14 Q01-Q64 boundary preserved.

### Method control

Literal-string absence is not treated as proof of semantic absence.
Findings are evaluated against the uploaded M01--M15 Core Impact and
STEP13-A/B/C/D evidence, then reflected in this full successor contract.

# 53. CROSS-DOMAIN DEPENDENCY VERIFICATION

  Dependency                                      Result
  ----------------------------------------------- --------
  M01 → M02                                       PASS
  M02 → M03 public profile/listing presentation   PASS
  M14 → M03 Refresh allowance/action              PASS
  M03 → M11 discovery                             PASS
  M04 → M15 evidence                              PASS
  M05 → Session                                   PASS
  M06 Claim → M03 Listing                         PASS
  M08 → source-domain visibility/M10              PASS
  M09 → M11 content lifecycle/discovery           PASS
  M10 → all protected UI actions                  PASS
  M12 → M03/M10/M11/M14                           PASS
  M13 → AI/provider                               PASS
  M14 → entitlement/quota                         PASS
  M15 → evidence/award/title                      PASS

# 54. STEP13-E SECOND DEEP-SCAN GATE

## Scope

The second pass scans the rebuilt full document for: 1. all M01--M15
required successor deltas; 2. stale current-state contradictions; 3.
authority inversion; 4. missing mandatory M11 surfaces; 5. M14 Q01-Q64
boundary drift; 6. unsupported endpoint/table/runtime claims; 7.
accidental loss of preserved Core concepts; 8. state/interaction
coverage.

## Gate result

**PASS WITH CONTROLLED RESIDUALS --- SECOND FULL DEEP SCAN CLEAN**

No blocking semantic finding remains.

# 55. FINAL CURRENT UI/UX CHAIN

``` text
Frozen Core v1.3
      +
STEP13-00 currentness/authority gate
      +
STEP13-A PRD v3.7
      +
STEP13-B Functional v2.3
      +
STEP13-C User Flow v1.1
      +
STEP13-D Technical v1.3
      +
M01–M15 current reconciliation / Core Impact evidence
      ↓
STEP13-E Successor Integrated UI/UX v3.0
      ↓
STEP13-F SEO / Analytics
```

# 56. FINAL DECLARATION

STEP13-E v3.0 is a **FULL REBUILD** of the UI/UX successor
specification. It is not a patch, append-only delta, or isolated screen
correction.

The rebuild: - preserves valid Core v1.3 UI/UX; - integrates the
required M01--M15 changes within STEP13-E scope; - reconciles UI paths
with Functional/User Flow/Technical successor contracts; - provides
Screen ↔ Flow ↔ Capability ↔ Authorization traceability; - provides
state/interaction coverage; - records controlled API/physical/runtime
residuals without inventing evidence; - keeps Core v1.3 immutable; -
requires a second deep scan after correction.

**Final status: PASS WITH CONTROLLED RESIDUALS --- STEP13-E FULL REBUILD
v3.0 / SECOND FULL DEEP SCAN CLEAN**
