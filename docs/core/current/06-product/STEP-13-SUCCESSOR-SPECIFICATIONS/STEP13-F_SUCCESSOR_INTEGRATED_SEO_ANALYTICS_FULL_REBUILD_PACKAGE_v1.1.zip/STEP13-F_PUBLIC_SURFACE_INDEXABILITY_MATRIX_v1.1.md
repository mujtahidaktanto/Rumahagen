# STEP13-F — PUBLIC SURFACE / INDEXABILITY MATRIX

| Surface | Public? | Indexability | Canonical | Lifecycle owner | Discovery owner | Measurement |
|---|---|---|---|---|---|---|
| Homepage | Yes | Yes | One canonical | M09/applicable | M11 | Discovery/view/CTA |
| Listing | Conditional public | Published/eligible only | One canonical | M03 | M11 | View/search/filter/CTA |
| Agent | Conditional public | When public visibility permits | One canonical | M02 | M11 | View/engagement |
| Organization | Conditional public | When public representation permits | One canonical | M12 | M11 | Discovery/view |
| Developer/Project | Conditional public | When public | One canonical | M06 | M11 | Discovery/view/CTA |
| Event | Conditional public | Policy-permitted public Event | One canonical | M05 | M11 | Discovery/registration interaction |
| Learning | Conditional | Policy-permitted public catalog/path | One canonical | M04 | M11 | Catalog/path/activity |
| Learning Session | Conditional | Policy-permitted public representation | One canonical | M04 | M11 | Discovery/join UX |
| Static Public Content | Published/public | Eligible published only | One canonical | M09/applicable | M11 | View/discovery/CTA |
| Announcement/Promotion | Active/public | Policy-dependent | One canonical where indexable | M09/applicable | M11 | Impression/view/CTA |
