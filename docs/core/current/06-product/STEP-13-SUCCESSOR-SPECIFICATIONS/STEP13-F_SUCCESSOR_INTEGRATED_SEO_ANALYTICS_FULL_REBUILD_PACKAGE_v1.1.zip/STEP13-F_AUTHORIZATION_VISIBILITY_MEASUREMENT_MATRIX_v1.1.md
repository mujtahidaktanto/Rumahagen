# STEP13-F — AUTHORIZATION / VISIBILITY MEASUREMENT MATRIX

| Decision | Upstream authority | M11 behavior | Forbidden behavior |
|---|---|---|---|
| Public visibility | Owning domain | Measure visible public interaction | Do not widen visibility |
| RBAC | M10 | Measure authorized reporting/interaction | Do not assign role |
| Organization membership | M12 + M10 | Measure permitted public/context interaction | Do not create membership |
| Listing ownership | M03 | Measure eligible public Listing interaction | Do not transfer ownership |
| Refresh authorization | M10 | Observe permitted UX/outcome | Do not authorize or consume |
| Refresh allowance | M14 | Observe allowance-related presentation | Do not configure allowance |
| Learning access | M04 + M10 | Measure permitted interaction | Do not grant access |
| Learning completion/LP | M04 | Observe after canonical state | Do not create completion/LP |
| Qualification/Award | M15 | Observe public presentation | Do not qualify/award |
| Payment | M14 | Observe funnel | Do not confirm payment |
| Entitlement | M14 | Observe established entitlement | Do not grant entitlement |
| Private data | Owner + M10 | Exclude from public analytics | Do not leak |
| Admin reporting | M09 + M10 | Authorized reporting only | UI hiding is not runtime proof |
