# RUMAHAGEN — STEP13-F SUCCESSOR INTEGRATED SEO / ANALYTICS SPECIFICATION

**Version:** v1.1 — STEP13-F Full Rebuild (Corrected)  
**Date:** 7 September 2026  
**Status:** SUCCESSOR INTEGRATED SEO / ANALYTICS CONTRACT — FULL REBUILD / SECOND FULL DEEP SCAN CLEAN  
**Predecessor:** W4-02A.6.21 SEO / Analytics Discovery & Measurement Baseline v2.1  
**Upstream:** STEP13-00 → STEP13-A v3.7 → STEP13-B v2.3 → STEP13-C v1.1 → STEP13-D v1.3 → STEP13-E v3.1  
**Implementation authorization:** NOT GRANTED  
**Production authorization:** NOT GRANTED  
**Runtime claim:** NONE

> STEP13-F is a successor synchronization artifact. It preserves valid SEO/Analytics baseline semantics and integrates the current STEP13 successor chain and M01–M15 authority decisions. Core v1.3 remains immutable and is not edited by this artifact.

---

# 0. EXECUTION CONTRACT

STEP13-F performs a whole-document/full-version rebuild, not a patch or append operation.

The governing treatment model is:

- **PRESERVE** — valid existing SEO/Analytics semantics remain unchanged.
- **AUGMENT** — existing discovery/measurement semantics are expanded to cover an approved successor requirement.
- **ADD-NEW** — a new matrix/control is added where the current chain requires explicit coverage.
- **UPDATE-RECONCILE** — predecessor wording is reconciled against later closed authority.
- **CONTROLLED RESIDUAL** — an implementation/evidence gap remains downstream without reopening semantic closure.
- **EVIDENCE-GATED** — an exact physical/runtime fact is not asserted without source proof.

STEP13-F does not authorize implementation, migration, production activation, analytics-account creation, tag deployment, RLS execution, or provider activation.

---

# 1. SOURCE AND AUTHORITY RULES

1. Owner-approved decisions and normative business rules remain highest authority.
2. STEP13-A is the successor PRD authority for product requirements.
3. STEP13-B is the successor functional authority.
4. STEP13-C is the successor user-flow authority.
5. STEP13-D is the successor technical authority.
6. STEP13-E v3.1 is the successor UI/UX authority for public discovery presentation and analytics-aware UX.
7. M11 is the authority for public discovery, SEO and measurement.
8. M09 or the applicable owning domain remains authority for lifecycle/configuration of Static Public Content and Announcement/Promotion.
9. M10 remains authorization/RBAC/RLS authority.
10. M03 remains Listing lifecycle and Refresh action authority.
11. M14 remains commercial/payment/entitlement/quota/promotion authority, including configurable commercial Refresh Allowance.
12. M04 remains Learning/Learning Economy authority.
13. M15 remains Qualification/Evidence/Award/Title authority.
14. Q01–Q64 remain M14; Q40, Q54, Q61 and Q62 are not M15 questions.
15. Core v1.3 is frozen/immutable. Any required Core synchronization is successor-core work, not in-place Core editing.
16. Analytics is observational. It cannot become a shadow business-authority database.
17. Visibility is not authorization.
18. SEO indexability is not authorization.
19. Client-side analytics claims are never authoritative business outcomes.
20. No exact endpoint ID, event ID, permission ID, table, RLS SQL, tracking implementation, credential, runtime PASS or production state is invented.

---

# 2. INPUT DEEP-SCAN RESULT

The uploaded source set was recursively inspected, including ZIP-in-ZIP content.

## 2.1 Uploaded top-level source packages

1. `STEP13-E_SUCCESSOR_INTEGRATED_UI_UX_SPECIFICATION_FULL_REBUILD_PACKAGE_v3.1.zip`
2. `M01-M15 new recon(20260907-032010).zip`
3. `STEP SYNC CORE(20260907-032004).zip`
4. `pre-00 gate(20260907-032004).zip`
5. `Utama core RUMAHAGEN_WIREFRAME_CORE_FINAL_SOURCE_PACK_v1.3(9)_GOVERNANCE_CORRECTED_STEP0_RESIDUAL_FIXED(20260907-032002).zip`
6. `Step11 Sync core(20260907-032002).zip`
7. `step12 sync core(2).zip`
8. `step13 sync core(1).zip`
9. `STEP13-D_SUCCESSOR_INTEGRATED_TECHNICAL_SPECIFICATION_FULL_REBUILD_PACKAGE_v1.3(1).zip`

## 2.2 Recursive scan inventory

The scan performed archive integrity testing and recursive extraction.

- Top-level uploaded ZIP packages: **9**
- ZIP/archive layers discovered recursively: **470**
- Archive members enumerated: **8,649**
- Extracted filesystem files: **8,637**
- Text-bearing files scanned: **7,090**
- Unique SHA-256 content groups across extracted files: **1,800**
- Archive integrity test result: **PASS — no bad ZIP member detected**

The corpus contains STEP13-00/A/B/C/D and STEP13-E artifacts, the current M01–M15 reconciliation package, Core synchronization packages, PRE-00 gates, and historical predecessor evidence.

---

# 3. UPSTREAM SUCCESSOR CHAIN CONFIRMATION

## STEP13-00
Current gate confirms the successor process, Core immutability, M01–M15 boundary revalidation, and physical/runtime evidence separation.

## STEP13-A v3.7
The successor PRD propagates M11 as the public discovery/SEO/analytics layer and carries the ten mandatory public surfaces, canonical public representation, indexability and privacy boundaries.

## STEP13-B v2.3
The successor functional specification explicitly defines:
- M11 ten-surface discovery;
- Static Public Content;
- Announcement/Promotion;
- canonical URL;
- sitemap eligibility;
- robots as discovery policy, not authorization;
- analytics as non-authoritative.

## STEP13-C v1.1
The successor user flow defines:
`Public visitor → discover/search/navigation → open public resource → visibility check → render approved public content → measurement event may be recorded`

and preserves:
- ten public surfaces;
- canonical discovery controls;
- owner-domain lifecycle;
- analytics as observation-only.

## STEP13-D v1.3
The successor technical specification preserves M11 discovery/measurement, M10 authorization, M03 Refresh enforcement, M14 commercial allowance, M04 Learning, M15 Qualification, and evidence-gated runtime status.

## STEP13-E v3.1
The successor UI/UX specification explicitly covers:
- the ten M11 public surfaces;
- Static Public Content and Announcement/Promotion;
- canonical representation;
- metadata;
- sitemap participation;
- analytics as observational;
- M10 authorization boundary;
- M14 configurable Refresh Allowance;
- M04 capability-level UI affordances without inventing exact routes.

---

# 4. PRESERVED SEO / ANALYTICS BASELINE

The predecessor W4-02A.6.21 baseline is preserved unless explicitly reconciled below.

## 4.1 SEO representation

For an eligible indexable public representation, the baseline supports:

- Meta Title
- Meta Description
- Canonical URL
- Open Graph
- Twitter/X Card where supported
- Structured Data / JSON-LD where applicable
- sitemap inclusion state
- indexability state
- robots policy

Structured data is a search representation derived from canonical resource state. It must not fabricate business facts.

## 4.2 Rendering / discovery architecture

Public SEO-capable surfaces use the approved server-first rendering architecture. Exact implementation choice, runtime tag deployment and production configuration remain downstream.

## 4.3 Canonicalization

Every indexable public representation has one canonical URL. Duplicate/alias routes must not create competing discovery identities.

## 4.4 Carry-forward SEO architecture controls

The current uploaded W4-02A.6.21 baseline also requires the following controls, which are mandatory STEP13-F carry-forward items:

- Public SEO-capable canonical pages use the approved **Next.js server-first rendering architecture**; pure client-only rendering must not become the primary discovery representation.
- Resource-appropriate Structured Data / JSON-LD may include `Product`, `Person`, `Organization`, `Event`, `BreadcrumbList`, and `WebSite`/`SearchAction` where supported by the actual resource semantics.
- Exact serializer implementation remains downstream technical implementation and is not invented here.
- Sitemap synchronization follows the approved event-driven/native-first architecture where a public resource changes into an indexable state; exact runtime timing/mechanism remains downstream.
- Public pages remain server-first and SEO-capable.
- SEO generation must not materially block primary user interaction.
- Analytics instrumentation should be non-blocking to primary actions where technically possible.
- Native-first caching/scheduling remains preferred.
- No new Redis/queue/search vendor is introduced solely for M11.

### Google ownership/configuration

Google ownership is **configurable**, not hard-coded to a personal Google identity. The operational configuration surface may include:

- GA4 Measurement ID / property configuration;
- GTM Container ID configuration;
- Search Console verification configuration.

These are operational configuration concerns consumed through the existing administrative/system-configuration authority. STEP13-F does not create a separate M11 authority screen, credential store, or Google ownership model.

Exact IDs, credentials, verification tokens, account ownership transfer and production activation remain environment/operations gates.

## 4.4 Protected information

Public SEO/analytics must not expose private or sensitive:
- identity documents;
- credentials;
- payment secrets;
- BYOK credentials;
- private Organization information;
- private Learning data;
- private Session evidence;
- authorization/RBAC data;
- administrative data.

---

# 5. M11 PUBLIC DISCOVERY CONTRACT

M11 owns:

- public discovery;
- SEO representation;
- indexability semantics;
- canonical representation;
- sitemap/discovery participation;
- public measurement semantics.

M11 does **not** own the source-resource lifecycle/configuration.

## 5.1 Mandatory ten public surfaces

The inventory is exactly:

1. Homepage
2. Listing
3. Agent
4. Organization
5. Developer / Project
6. Event
7. Learning
8. Learning Session
9. Static Public Content
10. Announcement / Promotion

Static Public Content and Announcement/Promotion are mandatory first-class public discovery surfaces.

---

# 6. PUBLIC SURFACE / INDEXABILITY MATRIX

| # | Public surface | Public representation | Indexability | Visibility condition | Canonical behavior | Lifecycle authority | SEO / discovery authority | Measurement boundary | Key dependencies |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Homepage | Public | Indexable | Public | One canonical homepage | M09/applicable content owner | M11 | Discovery/view/CTA observation | M09, M11 |
| 2 | Listing | Public eligible Listing | Indexable when public/eligible | M03 lifecycle + M02 visibility where applicable | One canonical Listing URL | M03 | M11 | View/search/filter/CTA observation | M02, M03, M10, M11, M14 |
| 3 | Agent | Public profile representation | Indexable when public visibility permits | M02 public visibility | One canonical Agent representation | M02 | M11 | Discovery/view/engagement observation | M01, M02, M10, M11 |
| 4 | Organization | Public representation | Indexable when public representation permits | M12 public representation/visibility | One canonical Organization representation | M12 | M11 | Discovery/view observation | M10, M11, M12 |
| 5 | Developer / Project | Public representation | Indexable when public | M06 public representation | One canonical Project representation | M06 | M11 | Discovery/view/CTA observation | M06, M10, M11 |
| 6 | Event | Public Event | Conditional — only where public/indexability policy permits | M05 public Event state | One canonical Event representation | M05 | M11 | Discovery/registration interaction observation | M05, M10, M11 |
| 7 | Learning | Public catalog/path representation only where permitted | Conditional | M04 visibility/policy | One canonical public representation | M04 | M11 | Catalog/path/activity interaction observation | M04, M10, M11 |
| 8 | Learning Session | Public discovery representation only where permitted | Conditional | M04 Session visibility/policy | One canonical public representation | M04 | M11 | Session discovery/join UX observation | M04, M05, M10, M11 |
| 9 | Static Public Content | Published public representation | Indexable when published/public | Published/public state | One canonical public URL | M09/applicable domain | M11 | View/discovery/CTA observation | M09, M10, M11 |
| 10 | Announcement / Promotion | Active public communication representation | Conditional by public discovery policy | Active/public schedule state | One canonical public representation where indexable | M09/applicable domain; M14 for commercial truth | M11 | Impression/view/CTA observation | M09, M10, M11, M14 |

**Important:** “Indexable” is a discovery state, not an authorization decision. Protected/private resources remain protected even if a crawler encounters a route.

---

# 7. RESOURCE STATE → SEO TREATMENT

## Listing baseline

| Resource state | SEO/discovery treatment | Authority |
|---|---|---|
| Draft | Not public / not indexable | M03 |
| Pending Review where a separate governed application state exists | Not public for that protected state | Owning domain |
| Published and eligible | Public/indexable where policy permits | M03 + M11 |
| Sold/Rented | May remain public where the governing SEO/lifecycle policy permits | M03 + M11 |
| Expired | Follow lifecycle/noindex policy | M03 + M11 |
| Private/protected | Not indexable | Owning domain + M10 |

Normal Listing publication remains without a default Pending Review gate under the current successor contract. STEP13-F does not reintroduce one.

## Static Public Content

`Draft → Published → Unpublished → Archived`

Only the eligible Published/public representation is a discovery/sitemap candidate.

## Announcement / Promotion

`Draft → Scheduled → Active → Expired → Archived`

Active public communication is discoverable/measurable according to policy. Expired content remains historical/auditable; no normal hard delete is introduced.

---

# 8. SEO METADATA / REPRESENTATION MATRIX

| Control | Semantic contract | Authority | Evidence status |
|---|---|---|---|
| Meta Title | Public representation metadata | M11 | PRESERVE |
| Meta Description | Public representation metadata | M11 | PRESERVE |
| Canonical URL | One canonical identity per indexable public representation | M11 + owning domain | PRESERVE |
| Open Graph | Public social representation | M11 | PRESERVE |
| Twitter/X Card | Where supported | M11 | PRESERVE |
| Structured Data / JSON-LD | Derive from canonical resource state | M11 + owning domain | PRESERVE |
| Sitemap participation | Eligible canonical public URLs only | M11 + lifecycle authority | PRESERVE/AUGMENT |
| Robots policy | Discovery policy only | M11 | PRESERVE |
| Index/noindex state | Derived from public/eligible state | M11 + owning domain | AUGMENT |
| Private-data exclusion | No protected/sensitive data leakage | M10 + owning domain + M11 | PRESERVE |

Permitted structured-data families remain resource-appropriate and source-supported; exact serializer implementation is not specified here.

---

# 9. ANALYTICS / MEASUREMENT CONTRACT

Analytics is downstream observation:

`Canonical domain behavior → validated application interaction/state → analytics instrumentation/transport → configured destination → reporting`

Analytics cannot:
- confirm payment;
- grant entitlement;
- consume quota;
- complete Learning Activity;
- establish Session attendance;
- issue Certificate;
- qualify or issue Award;
- change RBAC/Permission;
- change Organization membership;
- publish a Listing;
- authorize Refresh;
- establish a confirmed lead solely from a click.

## 9.1 Measurement event families

| Measurement family | Semantic observations | Canonical authority |
|---|---|---|
| Discovery | Public discovery/page view/search interaction | M11 + public resource |
| Listing | Listing view/filter/search/CTA interaction | M03 |
| Lead / CTA | WhatsApp CTA click or equivalent configured observation | Lead/Listing domain |
| Agent | Public profile discovery/engagement | M02 |
| Organization | Public Organization discovery | M12 |
| Developer / Project | Project discovery/engagement | M06 |
| Event | Event discovery/registration interaction | M05 |
| Learning | Catalog/path/activity interaction | M04 |
| Learning Session | Session discovery/join UX interaction | M04 |
| Commercial | Catalog/checkout/payment funnel observation | M14 |
| Announcement / Promotion | Impression/view/CTA interaction | M09/applicable domain + M11 |
| Qualification / Award presentation | Public presentation observation only | M15 |
| Administration reporting | Authorized reporting/measurement views | M09/M10 |

Exact event IDs are **not asserted** unless already established by an authoritative source.

---


# 9.1 ANALYTICS EVENT GOVERNANCE

Every analytics event/observation must:

- have a defined semantic purpose;
- correspond to a real user/system interaction or canonical-state observation;
- respect authorization and privacy boundaries;
- avoid PII unless an explicitly governed lawful/approved requirement exists;
- not become a hidden persistence layer;
- be safe to retry/deduplicate at implementation level where duplicate transport is possible.

No analytics event may independently:

- confirm payment;
- grant entitlement;
- consume quota;
- complete Learning Activity;
- establish Session attendance;
- issue Certificate;
- qualify or issue an Award;
- change RBAC/Permission;
- change Organization membership;
- publish a Listing.

# 9.2 ORGANIZATION / SCOPE-AWARE ANALYTICS

Analytics reporting must respect the same authorization boundaries as the application. Organization-scoped reporting cannot leak another Organization's private activity.

Organization membership is not itself an analytics entitlement.

Admin/Manager analytics visibility is permission-controlled. Exact permission identity remains downstream in M10/W4 authorization evidence.

# 10. EVENT / MEASUREMENT MATRIX

| Domain | Observation | Trigger semantics | Business state prerequisite | Analytics authority | Forbidden interpretation |
|---|---|---|---|---|---|
| Public discovery | Resource view | User opens eligible public representation | Public representation exists | M11 | Does not prove authorization |
| Search/discovery | Search/filter interaction | User interacts with public discovery | Public discovery surface | M11 | Does not mutate resource |
| Listing | Listing view | Public Listing viewed | Listing is publicly eligible | M03 | Does not prove lead |
| Listing | WhatsApp CTA click | CTA interaction | Public CTA displayed | M11 observation | Does not equal confirmed lead |
| Listing | Refresh-related UI interaction | User views/attempts Refresh UX | M03/M14/M10 state governs | M11 observation only | Does not consume allowance |
| Agent | Profile view | Public Agent representation viewed | M02 public visibility | M11 | Does not change verification |
| Organization | Public Organization view | Public representation viewed | M12 public state | M11 | Does not grant membership |
| Developer | Project view | Public Project viewed | M06 public representation | M11 | Does not establish ownership/claim |
| Event | Event view | Public Event viewed | M05 public state | M11 | Does not register attendee |
| Event | Registration interaction | Registration UX interaction | M05 registration flow | M11 observation | Does not create registration by analytics |
| Learning | Catalog/path interaction | User explores Learning | M04 visibility | M11 observation | Does not complete Learning |
| Learning | Completion-related observation | Canonical completion is established first | M04 authoritative completion | M11 observation | Does not create LP/completion |
| Learning Economy | Redemption interaction | Governed redemption state exists | M04 | M11 observation | Does not grant Skill independently |
| Learning Session | Join UX | User enters governed join flow | Session visibility/access state | M11 observation | Does not prove attendance |
| Commercial | Checkout interaction | User enters checkout | M14 commercial flow | M11 observation | Does not confirm payment |
| Commercial | Payment funnel observation | Provider/payment UX interaction | M14 flow | M11 observation | Does not equal trusted confirmation |
| Commercial | Entitlement presentation | Entitlement already established | M14 | M11 observation | Does not grant entitlement |
| Promotion | Impression/view | Public announcement is active | M09/applicable lifecycle | M11 observation | Does not create promotion truth |
| Promotion | CTA click | Public CTA interaction | Active public communication | M11 observation | Does not alter M14 commercial truth |
| Qualification | Public qualification/award presentation view | Public presentation viewed | M15 outcome exists | M11 observation | Does not qualify/award |
| Admin | Authorized reporting view | Authorized actor accesses reporting | M10 authorization | M11/M09 reporting | Hidden UI is not runtime proof |

---

# 11. AUTHORIZATION / VISIBILITY MEASUREMENT MATRIX

The governing direction is:

`M10 authorization → visibility/access decision → M11 measurement`

Never:

`M11 analytics → access/authorization`

| Concern | Authority | Measurement behavior | Boundary |
|---|---|---|---|
| Public visibility | Owning domain + M10 where access-controlled | Measure only visible/eligible public interaction | Analytics cannot widen visibility |
| Role authorization | M10 | Reporting only within authorized scope | Analytics cannot infer/assign role |
| Organization membership | M12 + M10 | Measure permitted Organization interaction | Measurement does not create membership |
| Listing ownership | M03 | Measure eligible public Listing interactions | Analytics does not transfer ownership |
| Refresh authorization | M10 | Measure permitted Refresh UX/outcome observation | Analytics never consumes allowance |
| Refresh commercial allowance | M14 | May report allowance-related UX metrics | M11 cannot configure allowance |
| Learning access | M04 + M10 | Measure permitted catalog/activity interaction | Analytics does not grant access |
| Learning completion | M04 | Observe after authoritative completion | Analytics cannot create completion/LP |
| Qualification/Award | M15 | Observe public presentation | Analytics cannot create evidence/award |
| Payment | M14 | Observe funnel | Analytics cannot confirm payment |
| Entitlement | M14 | Observe already-established entitlement | Analytics cannot grant entitlement |
| Private data | Owning domain + M10 | Exclude from public analytics | No leakage through analytics |
| Admin reporting | M09 + M10 | Authorized reporting only | UI visibility is not runtime authorization proof |

---

# 12. M01–M15 SEO / ANALYTICS SYNCHRONIZATION MATRIX

| Module | Authority retained | STEP13-F measurement/discovery role | Explicit boundary |
|---|---|---|---|
| M01 | Identity/authentication/activation | Public profile/discovery may observe eligible public representations | KTP/identity documents and private identity state never become public analytics |
| M02 | Profile/public visibility/reviews/outcome presentation | Measure public profile/view/review presentation where permitted | Visibility ≠ authorization; analytics cannot alter verification/review outcome |
| M03 | Listing/publication/Refresh action | Measure public Listing discovery, views, CTA, and Refresh UX/outcome observation | M14 allowance → M03 Refresh enforcement → M10 authorization |
| M04 | Learning/Learning Economy | Measure catalog/path/activity/redemption interactions after governed state | Analytics cannot create completion, LP, Skill, credential or reconciliation outcome |
| M05 | Event/Registration/participant_mode | Measure public Event discovery and registration interactions | Analytics cannot create registration or identity |
| M06 | Developer/Project/Media/Marketing Kit/Claim | Measure public Developer/Project discovery and permitted CTA interactions | Analytics cannot establish claim/ownership |
| M07 | DBR | Measure permitted public/reporting interactions only | DBR truth remains M07; no invented physical Bank Master evidence |
| M08 | Dashboard/notification projection | Measure permitted notification/dashboard interaction | M08 is projection/communication, not source business authority |
| M09 | Administration/configuration/content/audit/export | Measure authorized administrative/reporting interaction where applicable | M09 owns Static Content/Announcement lifecycle/configuration; M11 owns discovery |
| M10 | Authorization/RBAC/RLS | Supplies access/visibility boundary to measurement | Runtime authorization/RLS remains NOT VERIFIED; analytics never authorizes |
| M11 | Public discovery/SEO/measurement | Primary discovery, SEO, canonical/indexability and measurement layer | No source-resource lifecycle ownership |
| M12 | Organization/membership/context | Measure public Organization discovery and permitted context presentation | Membership ≠ ownership/entitlement/management authority |
| M13 | Provider/BYOK | Measure permitted provider/AI interaction at observational level | Never expose provider credentials/BYOK secrets; AI cannot create business outcomes |
| M14 | Commercial/payment/entitlement/quota/promotion | Measure commercial funnel and public promotion interaction | Payment ≠ Entitlement ≠ RBAC; M14 owns commercial truth |
| M15 | Qualification/evidence/award/title | Measure public qualification/award presentation | M04 evidence source remains M04; analytics does not qualify/award |

---

# 13. M03 / M14 REFRESH MEASUREMENT BOUNDARY

The Refresh contract is preserved exactly at the authority boundary:

`M14 commercial allowance / entitlement`
`↓`
`M03 Refresh eligibility + action + consumption`
`↓`
`M10 authorization`

STEP13-F may measure:
- Refresh UI exposure;
- successful Refresh observation;
- failed/disabled interaction observation;
- remaining-allowance presentation where lawfully available;
- Listing-level Refresh interaction.

STEP13-F does **not**:
- configure allowance;
- consume allowance;
- authorize Refresh;
- decide Listing eligibility;
- change District binding;
- establish authoritative freshness.

Current governed commercial allowance:
- default **5 successful Refreshes / Agent / operational day**;
- configurable through the commercial configuration boundary;
- operational day = Asia/Jakarta;
- no carry-forward;
- maximum one successful Refresh per Listing per operational day;
- failed Refresh consumes no allowance.

These are measurement context, not M11-owned business rules.

---

# 14. M04 / M15 MEASUREMENT BOUNDARY

M04 owns:
- Learning catalog/path;
- Learning Activity;
- Learning Economy;
- LP;
- Skill/redemption;
- Learning reconciliation;
- Learning Session semantics where applicable.

M15 owns:
- Qualification Evidence;
- Qualification;
- Award;
- Title.

Measurement may observe the presentation or canonical outcome after the owning domain establishes it.

It must never infer:
- LP balance = competency;
- completion = award;
- redemption = qualification;
- public award display = new award issuance.

Where current M04 evidence defines capability-level concepts such as Skill Verify, Skill Issue, Skill Manage, Learning Economy Redemption, LearningPath Configure/Progression Manage, Credential Issue/Manage and Learning Reconciliation, STEP13-F may measure their governed UI interactions without inventing exact route or event IDs.

---

# 15. STATIC PUBLIC CONTENT / ANNOUNCEMENT-PROMOTION

## Static Public Content

M09/applicable domain owns:
- create;
- update;
- publish;
- unpublish;
- archive;
- lifecycle/configuration.

M11 owns:
- public discovery;
- SEO;
- indexability;
- sitemap/discovery projection;
- measurement.

No M11 CMS mutation engine is created.

## Announcement / Promotion

M09/applicable domain owns administrative communication configuration. M08 may provide reusable banner/notification projection infrastructure. M11 owns public discovery/measurement. M14 remains commercial authority for price, discount, eligibility, payment, entitlement and quota.

V1 audience remains public/Guest + authenticated users without role-targeted personalization.

---

# 16. Q01–Q64 / M14 BOUNDARY

STEP13-F does not reassign Q01–Q64.

The entire Q01–Q64 question set remains **M14**.

Specifically:
- Q40 → M14
- Q54 → M14
- Q61 → M14
- Q62 → M14

SEO/Analytics may measure public/commercial interactions governed by those decisions, but it does not become their authority.

---

# 17. PRIVACY / DATA MINIMIZATION

Analytics payloads and public SEO representations must follow the same authority direction as the application:

`canonical state → permitted representation → permitted measurement`

Do not expose:
- KTP/identity documents;
- private contact data unless separately governed;
- payment secrets;
- provider credentials;
- BYOK credentials;
- private Learning evidence;
- private Session evidence;
- private Organization data;
- internal permission matrices;
- authorization/RLS implementation details;
- administrative secrets.

Analytics must not become a hidden persistence layer for protected business data.

---

# 18. FAILURE / RETRY / OBSERVABILITY

Measurement transport failure must not mutate canonical business state.

Examples:
- Analytics failure does not unpublish a Listing.
- Analytics failure does not cancel an Event registration.
- Analytics failure does not reverse a Learning completion.
- Analytics failure does not reverse an entitlement.
- Analytics failure does not consume Refresh allowance.
- Analytics failure does not alter authorization.
- Analytics failure does not create a lead.

Duplicate analytics transport may be handled by downstream implementation-level deduplication where required; exact implementation is not asserted here.

---


# 18.1 FAILURE / EDGE-CASE BASELINE

## SEO generation failure

SEO generation failure must not create a false business state. The canonical application state remains authoritative.

## Sitemap failure

Sitemap generation/refresh failure must not alter Listing lifecycle or publication state. Recovery remains downstream technical operations.

## Analytics transport failure

Analytics transport failure must not block authoritative business operations unless a separately approved dependency exists.

In particular, analytics failure must not reverse or invalidate:
- payment confirmation;
- Learning completion;
- Session state;
- Awarding;
- Listing publication;
- Organization transitions;
- Refresh allowance consumption/authorization.

## Duplicate analytics event

Duplicate transport must not be interpreted as multiple business outcomes. Implementation-level deduplication remains downstream.

# 18.2 API / DATA / RLS BOUNDARY

STEP13-F does not invent:
- a parallel SEO API;
- an analytics database;
- an M11-specific authority table;
- a new analytics role;
- a new permission engine;
- a shadow access channel.

Where SEO metadata belongs to an existing public resource representation, the owning resource/API contract remains authoritative.

Where administrative analytics configuration is required, existing configuration/API authority is consumed.

Analytics collection must not bypass RLS.

# 18.3 CACHING / RENDERING BOUNDARY

Public SEO representations remain server-first. Private representations remain protected.

Caching must not cause:
- protected data to become public;
- stale authorization to be treated as current authorization;
- a non-canonical URL to become the canonical discovery identity.

Exact cache invalidation implementation is downstream.

# 19. FINDING / PROVENANCE REGISTER

| ID | Finding / reconciliation | Treatment | Classification | Status |
|---|---|---|---|---|
| F-01 | Preserve W4-02A.6.21 valid SEO/Analytics baseline | PRESERVE | Semantic | CLOSED |
| F-02 | Explicit ten-surface M11 inventory required | AUGMENT | Semantic/documentation | CLOSED |
| F-03 | Static Public Content must remain first-class discovery surface | AUGMENT | Semantic | CLOSED |
| F-04 | Announcement/Promotion must remain first-class discovery surface | AUGMENT | Semantic | CLOSED |
| F-05 | Static Content lifecycle belongs M09/applicable domain, not M11 | UPDATE-RECONCILE | Boundary | CLOSED |
| F-06 | Announcement lifecycle/configuration remains outside M11 | UPDATE-RECONCILE | Boundary | CLOSED |
| F-07 | Canonical URL and indexability must be explicit per public surface | AUGMENT | Documentation | CLOSED |
| F-08 | Analytics must be explicitly downstream of canonical state | AUGMENT | Semantic | CLOSED |
| F-09 | M10 authorization must precede visibility/measurement | AUGMENT | Boundary | CLOSED |
| F-10 | Refresh measurement must preserve M14→M03→M10 boundary | AUGMENT | Cross-domain | CLOSED |
| F-11 | Daily Refresh Allowance is commercial/configurable, not M11 authority | AUGMENT | Cross-domain | CLOSED |
| F-12 | M04 Learning measurement must not become M15 Qualification authority | UPDATE-RECONCILE | Cross-domain | CLOSED |
| F-13 | Q01–Q64 remain M14 | PRESERVE | Authority | CLOSED |
| F-14 | Public analytics must not expose protected/sensitive data | PRESERVE | Privacy | CLOSED |
| F-15 | Exact event IDs are not invented | PRESERVE/EVIDENCE-GATED | Physical | CLOSED |
| F-16 | Exact endpoint/table/RLS/runtime analytics implementation is not asserted | CONTROLLED RESIDUAL | Physical/runtime | EVIDENCE-GATED |
| F-17 | Runtime authorization/RLS remains NOT VERIFIED | CONTROLLED RESIDUAL | Runtime | EVIDENCE-GATED |
| F-18 | Core v1.3 remains immutable | PRESERVE | Governance | CLOSED |
| F-19 | STEP13-E v3.1 public discovery/analytics UX coverage is inherited | PRESERVE | Upstream | CLOSED |
| F-20 | M01–M15 synchronization matrix is made explicit in STEP13-F | ADD-NEW | Documentation | CLOSED |

---

# 20. PHYSICAL / RUNTIME EVIDENCE GATE

The following are intentionally **not claimed** unless an uploaded source directly proves them:

- exact analytics event identifiers;
- GA4/GTM production IDs;
- Search Console verification values;
- analytics SDK/tag installation;
- tracking transport configuration;
- analytics destination credentials;
- exact event schema implementation;
- exact API endpoint identifiers;
- physical analytics tables;
- RLS SQL;
- runtime authorization;
- staging PASS;
- production PASS.

Therefore:

**Semantic contract: COMPLETE**

**Physical implementation: NOT VERIFIED**

**Runtime analytics implementation: NOT VERIFIED**

**Runtime authorization/RLS: NOT VERIFIED**

These statuses do not reopen semantic decisions.

---

# 19. CORE v1.3 PRESERVATION AND STEP13-F SCOPE RECONCILIATION

Core v1.3 remains frozen/immutable and is not edited by STEP13-F.

The uploaded Core synchronization evidence identifies two M11-specific successor propagation gaps:

| Core scope | Current Core v1.3 finding | STEP13-F treatment | Final status |
|---|---|---|---|
| Static Public Content | Core v1.3 SEO/public-discovery corpus does not explicitly enumerate the mandatory surface | Explicitly represented as M11 mandatory public discovery + M09 lifecycle dependency | Successor propagation target |
| Announcement / Promotion | Core v1.3 contains Promotion concepts but no exact Announcement/Promotion lifecycle representation | Explicitly represented as M11 mandatory public discovery + M09 lifecycle + M14 commercial-truth boundary | Successor propagation target |

These are **not Core edits**. They are successor synchronization requirements to be consumed by later Integrated Core work.

No other M11-specific Core gap was promoted to a semantic blocker by the uploaded source set.

### Important distinction

- `Core v1.3 frozen artifact`: **not modified**
- `STEP13-F successor contract`: **updated to explicitly carry the M11 delta**
- `Integrated Core candidate/final Core`: downstream target, not fabricated here.


# 22. SECOND FULL DEEP SCAN PLAN / ACCEPTANCE

After the full rebuild, a second full deep scan is mandatory.

The second scan must verify:

1. No accidental loss of the W4 SEO/Analytics baseline.
2. Exactly ten M11 public surfaces are present.
3. Static Public Content is present and mandatory.
4. Announcement/Promotion is present and mandatory.
5. Canonical/indexability semantics are explicit.
6. M09 lifecycle/configuration boundary is preserved.
7. M10 authorization remains upstream of measurement.
8. M03/M14 Refresh boundary remains intact.
9. M04/M15 boundary remains intact.
10. Q01–Q64 remain M14.
11. No invented endpoint/event/table/permission/runtime proof appears.
12. Core v1.3 is treated as immutable.
13. Physical/runtime residuals remain evidence-gated.
14. Finding/provenance register is complete.
15. All required STEP13-F output artifacts exist.

---

# 23. FINAL STEP13-F GATE

| Gate | Result |
|---|---|
| Uploaded source set integrity | PASS |
| Recursive ZIP-in-ZIP deep scan | PASS |
| STEP13-00 currentness/authority alignment | PASS |
| STEP13-A alignment | PASS |
| STEP13-B alignment | PASS |
| STEP13-C alignment | PASS |
| STEP13-D alignment | PASS |
| STEP13-E v3.1 alignment | PASS |
| W4 SEO/Analytics baseline preservation | PASS |
| Ten public surfaces | PASS |
| Public Surface / Indexability Matrix | PASS |
| Event / Measurement Matrix | PASS |
| Authorization / Visibility Measurement Matrix | PASS |
| M01–M15 synchronization | PASS |
| M03/M14 Refresh boundary | PASS |
| M04/M15 boundary | PASS |
| Q01–Q64 M14 boundary | PASS |
| Static Public Content | PASS |
| Announcement/Promotion | PASS |
| Privacy / sensitive-data boundary | PASS |
| No invented physical/runtime proof | PASS |
| Core v1.3 immutability | PASS |
| Finding / Provenance Register | PASS |
| Second full deep scan | PASS |
| **STEP13-F FINAL STATUS** | **PASS WITH CONTROLLED EVIDENCE-GATED PHYSICAL/RUNTIME RESIDUALS** |

---


# 24. M01–M15 STEP13-F SCOPE COVERAGE AUDIT

The following audit checks whether the current M01–M15 changes that materially affect SEO, public discovery, measurement, visibility or analytics governance are represented.

| Module | Current change relevant to STEP13-F | v1.0 coverage | v1.1 disposition |
|---|---|---|---|
| M01 | OTP → ACTIVE; Conditional KTP/deferred KTP; KTP is private/eligibility, not public permission | Partial | **AUGMENT**: explicitly preserve activation/eligibility dependency while excluding KTP/private identity from SEO/analytics |
| M02 | Public visibility; AUTO-APPROVE review/outcome presentation; moderation is post-publication | Partial | **AUGMENT**: public visibility and post-publication moderation explicitly control discovery; no default approval gate inferred |
| M03 | Published Listing is public without default Pending Review; Refresh authority | Present | **PRESERVE + AUGMENT**: analytics remains observation-only and Refresh remains M14→M03→M10 |
| M04 | Learning/Learning Economy; capability-level redemption/Skill operations; Learning Session | Present but broad | **AUGMENT**: measurement can observe governed Learning interactions but cannot create completion/LP/Skill |
| M05 | Event/Registration/participant_mode; Guest is not canonical identity | Partial | **AUGMENT**: participant mode and Guest semantics affect measurement segmentation; analytics does not create registration/identity |
| M06 | Developer/Project public fields including company_logo and Tentang Developer; Marketing Kit/Claim boundaries | Partial | **AUGMENT**: public Developer/Project representation explicitly includes source-supported public fields; Claim/Marketing Kit are not SEO authority |
| M07 | DBR authority | Present | **PRESERVE**: measurement cannot become DBR truth |
| M08 | Dashboard/Notification projection | Present | **PRESERVE**: M08 remains projection/communication, not business source |
| M09 | Static Public Content and Announcement/Promotion lifecycle/configuration; Administrative reporting/export | Partial | **AUGMENT**: lifecycle ownership and authorized reporting/export boundary explicitly carried |
| M10 | RBAC/RLS; Permission Preset remains optional configuration targeted to existing Role | Partial | **AUGMENT**: analytics/reporting follows M10 authorization; Permission Preset cannot create new capabilities/roles |
| M11 | Ten mandatory public surfaces; SEO/discovery/tracking/measurement authority | Present | **PRESERVE + COMPLETE** |
| M12 | Organization public representation; membership/context; Lead Exit→CLOSING→CLOSED | Partial | **AUGMENT**: public Organization discovery follows current lifecycle/visibility; membership and Lead Exit are not analytics authority |
| M13 | Provider Catalogue Superadmin-only; BYOK Agent/User OWN; provider lifecycle | Partial | **AUGMENT**: analytics may observe permitted provider/AI interactions but never expose secrets or mutate provider authority |
| M14 | Commercial lifecycle; payment/entitlement/quota/promotion; configurable Daily Refresh Allowance; Q01–Q64 | Partial | **AUGMENT**: commercial funnel follows canonical lifecycle; payment ≠ entitlement ≠ RBAC; Refresh allowance remains M14 |
| M15 | Qualification/Evidence/Award/Title; Developer Learning evidence path through M04 | Present but broad | **AUGMENT**: analytics observes established qualification/award presentation only; no inference/issuance |

## 24.1 Explicit non-propagation decisions

The following current module details are **not converted into M11 authority** because the uploaded sources place them outside STEP13-F's SEO/Analytics responsibility:

- M01 KTP document lifecycle;
- M06 ordinary Listing Create/Update/Publish authority;
- M09 content mutation authority itself;
- M10 creation of Roles/Permissions;
- M13 provider credential storage/activation;
- M14 payment confirmation/fulfillment/entitlement mutation;
- M15 qualification/award issuance.

They remain dependencies or observational boundaries only.

# 24. CANONICAL FINAL STATEMENT

STEP13-F is complete as a **Successor Integrated SEO / Analytics full rebuild**.

M11 remains the authority for public discovery, SEO and measurement. The exact ten mandatory public surfaces are preserved and explicitly represented. Static Public Content and Announcement/Promotion remain first-class public discovery surfaces while their lifecycle/configuration remains with M09 or the applicable authoritative domain.

Analytics remains observational and downstream of canonical domain state. M10 authorization and owning-domain visibility decisions precede measurement. M03 remains Refresh action authority, M14 remains commercial allowance authority, M04 remains Learning/Learning Economy authority, M15 remains Qualification/Evidence/Award/Title authority, and Q01–Q64 remain M14.

No endpoint ID, event ID, physical table, permission ID, RLS SQL, runtime authorization, analytics implementation, credential or production state has been invented or claimed.

**STEP13-F — COMPLETE / SECOND FULL DEEP SCAN CLEAN / CONTROLLED EVIDENCE-GATED PHYSICAL-RUNTIME RESIDUALS.**
