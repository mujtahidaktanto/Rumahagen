# STEP13-F — FINDING / PROVENANCE REGISTER v1.1

| ID | Treatment | Classification | Finding | Result |
|---|---|---|---|---|
| F-01 | PRESERVE | Semantic | W4-02A.6.21 valid SEO/Analytics baseline | CLOSED |
| F-02 | AUGMENT | Semantic | Explicit ten-surface M11 inventory | CLOSED |
| F-03 | AUGMENT | Semantic | Static Public Content is mandatory M11 discovery | CLOSED |
| F-04 | AUGMENT | Semantic | Announcement/Promotion is mandatory M11 discovery | CLOSED |
| F-05 | UPDATE-RECONCILE | Boundary | M09/applicable domain retains lifecycle/configuration | CLOSED |
| F-06 | UPDATE-RECONCILE | Boundary | Announcement lifecycle/config remains outside M11 | CLOSED |
| F-07 | AUGMENT | Documentation | Canonical/indexability explicit per surface | CLOSED |
| F-08 | AUGMENT | Semantic | Analytics downstream of canonical state | CLOSED |
| F-09 | AUGMENT | Authorization | M10 → visibility/access → M11 measurement | CLOSED |
| F-10 | AUGMENT | Cross-domain | M14 → M03 → M10 Refresh boundary | CLOSED |
| F-11 | AUGMENT | Cross-domain | Daily Refresh Allowance is commercial/configurable | CLOSED |
| F-12 | UPDATE-RECONCILE | Cross-domain | M04 Learning vs M15 Qualification | CLOSED |
| F-13 | PRESERVE | Authority | Q01–Q64 remain M14 | CLOSED |
| F-14 | PRESERVE | Privacy | Protected data excluded | CLOSED |
| F-15 | EVIDENCE-GATED | Physical | Exact event IDs not invented | CLOSED |
| F-16 | CONTROLLED RESIDUAL | Physical/runtime | Exact implementation/physical identifiers not asserted | EVIDENCE-GATED |
| F-17 | CONTROLLED RESIDUAL | Runtime | Runtime authorization/RLS not verified | EVIDENCE-GATED |
| F-18 | PRESERVE | Governance | Core v1.3 immutable | CLOSED |
| F-19 | PRESERVE | Upstream | STEP13-E v3.1 public discovery/analytics UX inherited | CLOSED |
| F-20 | ADD-NEW | Documentation | Explicit M01–M15 synchronization matrix | CLOSED |
| F-21 | AUGMENT | SEO architecture | SSR/SSG/ISR/server-first rendering boundary was underrepresented in v1.0 | CLOSED |
| F-22 | AUGMENT | Operations/configuration | Configurable Google ownership (GA4/GTM/Search Console) was underrepresented in v1.0 | CLOSED |
| F-23 | AUGMENT | Analytics governance | PII avoidance, scope-aware analytics, retry/dedup and business-outcome prohibitions were incomplete in v1.0 | CLOSED |
| F-24 | AUGMENT | Technical boundary | API/data/RLS, caching, performance and failure/edge-case controls were incomplete in v1.0 | CLOSED |
| F-25 | AUGMENT | M01 | Activation/eligibility dependency and private KTP exclusion needed explicit STEP13-F treatment | CLOSED |
| F-26 | AUGMENT | M02 | Public visibility + AUTO-APPROVE/post-publication moderation impact needed explicit STEP13-F treatment | CLOSED |
| F-27 | AUGMENT | M05 | participant_mode/Guest semantics needed explicit measurement treatment | CLOSED |
| F-28 | AUGMENT | M06 | company_logo and Tentang Developer as public Project/Developer representation fields needed explicit propagation | CLOSED |
| F-29 | AUGMENT | M09/M10 | Authorized administrative reporting/export and Permission Preset authorization boundary needed explicit treatment | CLOSED |
| F-30 | AUGMENT | M12 | Organization lifecycle/public representation impact needed explicit treatment | CLOSED |
| F-31 | AUGMENT | M13 | Provider Catalogue/BYOK measurement and secret boundary needed explicit treatment | CLOSED |
| F-32 | AUGMENT | M14 | Commercial lifecycle/payment/entitlement/quota/promotion relationship needed explicit treatment | CLOSED |
| F-33 | AUGMENT | M15 | Developer Learning evidence → M04 evidence → M15 qualification presentation chain needed explicit treatment | CLOSED |
| F-34 | CONTROLLED RESIDUAL | Core v1.3 | Core v1.3 does not explicitly enumerate Static Public Content | SUCCESSOR PROPAGATION TARGET; DO NOT MODIFY FROZEN CORE |
| F-35 | CONTROLLED RESIDUAL | Core v1.3 | Core v1.3 lacks exact Announcement/Promotion lifecycle representation | SUCCESSOR PROPAGATION TARGET; DO NOT MODIFY FROZEN CORE |
| F-36 | PRESERVE | Governance | Core v1.3 remains immutable; STEP13-F cannot claim Core update | CLOSED |
