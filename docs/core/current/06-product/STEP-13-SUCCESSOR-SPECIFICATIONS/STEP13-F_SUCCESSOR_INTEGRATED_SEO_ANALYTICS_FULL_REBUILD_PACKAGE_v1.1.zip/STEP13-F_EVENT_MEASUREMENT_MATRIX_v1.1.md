# STEP13-F — EVENT / MEASUREMENT MATRIX

| Family | Semantic event/observation | Required canonical state | Authority | Exact ID |
|---|---|---|---|---|
| Discovery | Public resource view | Eligible public representation | M11 + owner | Not asserted |
| Discovery | Search/filter interaction | Public discovery surface | M11 | Not asserted |
| Listing | Listing view | Public eligible Listing | M03 | Not asserted |
| Listing | WhatsApp CTA click / equivalent | Public CTA interaction | Listing/Lead domain + M11 observation | Not asserted beyond source baseline semantics |
| Refresh | Refresh UX/outcome observation | M03/M14/M10 governed state | M03/M14/M10 | Not asserted |
| Agent | Public profile view | Public profile visibility | M02 | Not asserted |
| Organization | Public Organization view | Public Organization representation | M12 | Not asserted |
| Project | Public Project view | Public Project representation | M06 | Not asserted |
| Event | Event view | Public Event | M05 | Not asserted |
| Event | Registration interaction | Governed registration UX | M05 | Not asserted |
| Learning | Catalog/path interaction | Permitted Learning visibility | M04 | Not asserted |
| Learning | Completion-related observation | Canonical completion first | M04 | Not asserted |
| Learning Economy | Redemption interaction | Governed redemption state | M04 | Not asserted |
| Session | Join UX | Permitted Session access | M04 | Not asserted |
| Commercial | Checkout interaction | Commercial checkout flow | M14 | Not asserted |
| Commercial | Payment funnel observation | Commercial flow | M14 | Not asserted |
| Promotion | Impression/view | Active public communication | M09/applicable + M11 | Not asserted |
| Promotion | CTA click | Active public CTA | M11 observation | Not asserted |
| Qualification | Public outcome presentation | M15 outcome exists | M15 | Not asserted |
| Admin | Authorized reporting view | M10-authorized reporting | M09/M10 | Not asserted |
