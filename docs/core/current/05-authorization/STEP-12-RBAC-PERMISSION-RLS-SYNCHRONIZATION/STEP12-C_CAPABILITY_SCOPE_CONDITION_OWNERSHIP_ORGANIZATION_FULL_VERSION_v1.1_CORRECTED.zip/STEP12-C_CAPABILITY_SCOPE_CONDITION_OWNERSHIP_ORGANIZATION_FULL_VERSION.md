# RUMAHAGEN R01 / WF03 — STEP12-C
## Capability / Scope / Condition / Ownership / Organization
### FULL VERSION v1.1 CORRECTED

**Final Gate:** PASS WITH CONTROLLED PHYSICAL / RUNTIME RESIDUALS — STEP12-D READY

## Source Boundary
Only the 8 uploaded ZIPs in this execution were used. No web/external source.

## Full Deep Scan — Source Set
- Recursive archive member instances: 3056
- Nested ZIP archives: 109
- Extracted text characters: 39653527 (source-manifest methodology retained from the prior controlled scan)
- Core v1.3: IMMUTABLE / FROZEN
- Runtime/RLS implementation: NOT CLAIMED

## Correction Trigger
A full deep scan of the uploaded sources identified a C-stage coverage gap: the prior STEP12-C graph represented five M10 authorization-infrastructure rows but did not explicitly materialize the current M10 Permission Preset semantic family M10-R06..R11 established by STEP12-01 and STEP12-B. The source evidence also contains a scope-expression inconsistency: Manager is shown as NONE in the STEP12-01 M10-R06..R11 rows while STEP12-B explicitly grants Manager Agent-only preset operations.

## Full-Rebuild Correction
This package is a complete rebuild, not a patch or append.
- Added six M10 Permission Preset capability rows to the C capability/scope/condition/ownership/organization chain.
- Added six rows to each dependent C register and 42 role-specific graph rows.
- Reconciled Manager preset delegation as `OWN` plus explicit `Manager → Agent target-role` condition. `OWN` here means the authorized preset-configuration context; it does not mean ownership of business resources and does not bypass hard ownership.
- Added explicit Core v1.3 successor augmentation treatment for Permission Preset effective authorization. Frozen Core v1.3 itself was not edited.
- Preserved exact physical Permission IDs, endpoint IDs, SQL, migration and runtime proof as controlled downstream residuals.

## Authorization Graph
Role → Role Permission → Capability → Scope → Condition → Ownership → Organization → Authorization Decision → RLS Requirement (semantic only)

## Locked Controls
- M10 remains authorization authority.
- Domain modules retain domain business truth.
- Platform granted_scope = ALL / OWN / NONE only.
- Contextual/organization/resource/assigned terms are not new platform scope enums.
- Hard ownership cannot be bypassed by ALL.
- Organization membership does not automatically create management/provider/Host/Instructor authority.
- Host ≠ Instructor; no Host role.
- Entitlement ≠ RBAC.
- Qualification/Awarding authority ≠ operational permission.
- Visibility ≠ authorization.
- Permission Preset is optional, targets an existing Role, starts from the target Role baseline, and cannot create authority outside that baseline.
- Manager preset operations are Agent-targeted and condition-bound.
- Physical condition engine is not claimed.
- No RLS SQL, migration, runtime proof, final physical IDs, or endpoint IDs are invented.

## M01-M15 Coverage
All 15 modules have explicit C-scope coverage. M01 remains an explicit identity/authentication boundary with NO-PROPAGATION. M02-M15 retain their accepted domain authorities. M10 now explicitly includes its current Permission Preset family M10-R06..R11 in the C-stage authorization graph.

## Core v1.3
The frozen Core is not edited. C-relevant Core semantics are classified PRESERVE/AUGMENT/RECONCILE/CONTROLLED and routed to successor/integrated Core treatment only. Permission Preset effective authorization is an explicit successor augmentation; Core v1.3 remains immutable.

## Reconciled M10 Permission Preset Semantics
- M10-R06 View: Superadmin ALL; Manager OWN under Agent-targeted/governed condition.
- M10-R07 Create: Superadmin ALL; Manager OWN under Agent-targeted/governed condition.
- M10-R08 Edit/Rename/Modify: Superadmin ALL; Manager OWN under Agent-targeted/governed condition.
- M10-R09 Delete: Superadmin ALL; Manager OWN under Agent-targeted/lifecycle condition.
- M10-R10 Assign/Replace: Superadmin ALL; Manager OWN under Agent-targeted/compatibility condition.
- M10-R11 Role + Preset Change: Superadmin ALL; Manager OWN under Agent-targeted/atomic compatibility condition.
- Admin, Agent, Developer Partner, Buyer and Instructor receive no preset-management authority.
- Preset does not create a Role, does not create permissions/capabilities outside the baseline, and does not transfer business-resource ownership.

## Findings
S12-C-006 and S12-C-007 were identified during the source deep scan and corrected through this full rebuild. The second deep scan of the rebuilt package found:
- 0 new material findings
- 0 blocking semantic authorization conflicts
- 0 invalid platform scope values
- 0 invented Permission IDs
- 0 RLS SQL / migration / runtime-proof claims
- 0 Core v1.3 mutations

## Final Counts
- Capability / Scope / Condition / Ownership / Organization matrix: 57 rows
- Authorization graph: 399 rows
- M01-M15 impact coverage: 15/15
- Core C-scope inheritance register: 12 items
- Physical/runtime residuals: controlled downstream only

## Handoff
**STEP12-C PASS → STEP12-D READY**
