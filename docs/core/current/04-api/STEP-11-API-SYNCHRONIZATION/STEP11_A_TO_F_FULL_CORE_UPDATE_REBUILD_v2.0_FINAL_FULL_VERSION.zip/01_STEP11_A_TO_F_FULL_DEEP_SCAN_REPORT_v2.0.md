# STEP11 A→F FULL DEEP SCAN REPORT v2.0

## Executive result

**PASS WITH CONTROLLED DOWNSTREAM RESIDUALS — STEP11-G READY**

This is a full rebuild, not a patch or append.

The central correction is that STEP11 A→F is an **API/Core synchronization pipeline** whose output must feed the next Integrated Core candidate. Core v1.3 is frozen as the source baseline only; it is not a semantic lock.

## Source boundary

Only the six user-uploaded archives supplied in this execution were used:

- STEP11-F v1.1: SHA256 `f43f504ca0159825426b2efc9b23a17844f2f570abd6d1362e5ebe6d05f92160`
- M01-M15 current recon: SHA256 `91354375da7c57257a7c4ef7da0aae3e26fc832f424d55d78dde8956dc7a54d7`
- STEP SYNC CORE: SHA256 `0474fe3e7f2461e2d68217838075741f27f01b411ab084c33db0a9d196425872`
- Core v1.3 source pack: SHA256 `7c491ce312a42f7d4debd77a4533a895dd35a71ad7464053c0bfe61639ba72e6`
- PRE-00 gate: SHA256 `f241d2cc281168a25767d938b954c3fd84ab9e51dbfeb072116449f2507b8751`
- STEP11 A-E package: SHA256 `e7d23eee07f3ccd0a9adaa67e5857e7fa67ab1ec70694426f8a4a3dd3f211b9f`

No superseded source package is included in the output package.

## Reconciled semantic baseline

STEP04 current synchronization matrix: **223 M01–M15 findings**.

Classification:
- PRESERVE: 114
- AUGMENT: 46
- ADD-NEW: 20
- RECONCILE: 7
- CONTROLLED: 32
- NO-PROPAGATION: 4

Therefore **73 semantic deltas are explicit Core-propagation candidates** and must not be blocked merely because physical/runtime evidence is incomplete.

## Module coverage

- M01: 14 STEP04 records
- M02: 17 STEP04 records
- M03: 21 STEP04 records
- M04: 17 STEP04 records
- M05: 10 STEP04 records
- M06: 18 STEP04 records
- M07: 19 STEP04 records
- M08: 18 STEP04 records
- M09: 6 STEP04 records
- M10: 17 STEP04 records
- M11: 10 STEP04 records
- M12: 10 STEP04 records
- M13: 4 STEP04 records
- M14: 20 STEP04 records
- M15: 22 STEP04 records

All M01–M15 are represented.

## STEP11 API baseline

STEP11-A current inventory contains **239 normalized method+route records**:
- API-001–API-236: current Core API v2.1 baseline
- API-237: POST /listings/{id}/refresh
- API-238: GET /admin/config/system
- API-239: PUT /admin/config/system

API-238/239 are method normalization of the combined system-config contract, not an invented Core capability.

## Core propagation rule

The following are now required behavior:

1. Valid semantic/API changes from M01–M15 propagate into the Integrated Core candidate.
2. Core v1.3 remains preserved byte-for-byte as the source baseline.
3. A physical/runtime gap may remain CONTROLLED without blocking semantic propagation.
4. `NO-PROPAGATION` is allowed only where the target is genuinely outside the Core/API scope or the source is historical/superseded — not merely because runtime proof is absent.
5. A controlled endpoint gap remains a controlled gap, but the semantic capability may still be propagated to the candidate if the Core contract requires it.
6. No permission ID, RLS policy, runtime result, or exact endpoint may be invented.

## Important current Core propagation targets

### M11 public discovery
Current M11 evidence contains valid AUGMENT deltas for:
- Static Public Content → M11 discovery
- Announcement/Promotion → M11 discovery/measurement

These are semantic Core-scope updates and must propagate to the Integrated Core candidate. No authoring route is invented.

### M03 Refresh
API-237 is an exact current route and M03 remains the Refresh action authority. Its semantic/API contract must be carried into the Integrated Core candidate. Physical/runtime realization remains downstream.

### M01 activation
Current M01 authority resolves the Core activation lifecycle contradiction. The resolved semantic/API consequence is a Core update; runtime proof is not required to establish the semantic rule.

### M10 / authorization
Current authorization authority remains M10. Authorization wording/contract corrections can propagate semantically into the candidate without inventing permission IDs or claiming deployed RLS.

### M04 / M12 / M13 / M14 / M15
Current semantic/API deltas remain in the propagation register. Where exact route evidence is missing, no route is invented; the semantic requirement is still carried when it is a valid Core contract requirement.

## Data-layer reconciliation

Accepted STEP10 baseline is consumed:
94 / 862 / 149 and 86 / 86 / 111.

No ERD, Dictionary, or Schema rebuild is performed by F.

A physical implementation gap does not invalidate a valid semantic Core update.

## Final interpretation

The previous F v1.1 rule that effectively treated “Core v1.3 immutable” as “do not propagate semantic changes into Core until later” is rejected.

The correct state is:

**Core v1.3 frozen baseline → approved M01–M15/API deltas → Integrated Core candidate → downstream physical/runtime realization → runtime verification.**
