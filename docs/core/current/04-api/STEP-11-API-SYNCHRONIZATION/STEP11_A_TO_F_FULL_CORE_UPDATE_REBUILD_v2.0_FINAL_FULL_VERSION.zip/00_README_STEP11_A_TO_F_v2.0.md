# RUMAHAGEN R01 / WF03 — STEP11 A→F FULL CORE-UPDATE REBUILD v2.0

**Status:** FULL REBUILD — CORE-UPDATE GOVERNED  
**Execution date:** 2026-09-06  
**Last accepted API stage:** STEP11-E v1.2  
**Current rebuilt stage:** STEP11-F / STEP11 A→F integrated governance v2.0

## Critical governance correction

This rebuild establishes the following rule as authoritative for STEP11 A→F:

> **Core v1.3 is immutable only as the frozen source baseline and must never be modified in-place. It is NOT a semantic freeze and is NOT the final Core. Valid M01–M15 changes within STEP11 API scope MUST propagate into the subsequent Integrated Core candidate/version according to PRESERVE, AUGMENT, ADD-NEW, RECONCILE, CONTROLLED, or justified NO-PROPAGATION classification.**

**Physical/runtime proof is NOT a prerequisite for semantic Core propagation.**

Physical realization and runtime verification remain separate downstream evidence states. Lack of runtime proof may keep a physical/runtime item CONTROLLED, but it must not block an otherwise valid semantic/API update to the Integrated Core candidate.

## STEP11 A→F purpose

A through F are one Core-update pipeline:

- **A** — preserve the existing API baseline and identify exact current API deltas that must be propagated.
- **B1–B10** — reconcile each module/API family and carry valid current changes into the Integrated Core API/contract candidate.
- **C** — synchronize cross-cutting HTTP/API semantics into the candidate.
- **D** — reconcile cross-module API authority/dependencies and carry approved authority/contract changes.
- **E** — carry webhook, idempotency, concurrency, replay and state-transition semantics into the candidate; runtime proof remains separate.
- **F** — perform the final cross-document reconciliation and verify that every valid STEP11 API-scope delta has a Core propagation disposition.

## Explicit prohibitions

No destructive overwrite of the Core baseline; no endpoint invention; no permission-ID invention; no RLS SQL; no runtime/production proof invention; no schema rebuild in F.

## Accepted data baseline consumed by F

94 logical entities / 862 valid attributes / 149 relationships  
86 physical tables / 86 RLS-enabled tables / 111 policies

F consumes this accepted baseline. It does not rebuild ERD, Dictionary, or Schema.

## Key semantic rule

A semantic requirement can be propagated into the Integrated Core candidate even when its physical implementation or runtime behavior is not yet verified.

Example:
`M11 Static Public Content` and `Announcement/Promotion` are valid M11 discovery/measurement scope deltas and therefore require Core propagation at the semantic/API-contract level. Their authoring lifecycle remains owned by M09/applicable authoritative domains.

## Result

This package supersedes the prior STEP11-F v1.1 interpretation that treated Core v1.3 immutability as a barrier to semantic propagation.

**Final gate:** PASS WITH CONTROLLED DOWNSTREAM RESIDUALS — STEP11-G READY
