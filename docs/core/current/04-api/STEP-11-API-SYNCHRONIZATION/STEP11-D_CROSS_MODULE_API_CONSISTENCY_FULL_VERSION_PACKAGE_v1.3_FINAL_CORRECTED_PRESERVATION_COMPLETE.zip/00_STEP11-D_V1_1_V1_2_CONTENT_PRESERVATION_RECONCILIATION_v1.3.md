# STEP11-D v1.3 — Content Preservation Reconciliation

## Rule

The final STEP11-D v1.3 package contains **one canonical v1.3 artifact per artifact family**. Prior v1.1/v1.2 duplicate files are intentionally not shipped so downstream STEP11 steps do not read duplicate historical versions.

This is **not** permission to lose content.

The preservation requirement is:

> All substantive v1.1 and v1.2 content must remain represented in the canonical v1.3 artifacts, except items explicitly corrected/superseded by the current authoritative evidence.

## Explicit historical corrections

- **v1.2 R-01:** corrected because the M01–M15 dependency baseline was rebuilt/expanded; current v1.3 dependency artifacts are canonical.
- **v1.2 R-02 / v1.1 API-237-related residual:** corrected/resolved after API-237 was registered upstream; current v1.3 must not preserve the obsolete claim that API-237 is an unregistered current endpoint.
- Historical finding IDs that remain applicable are mapped into the current v1.3 Controlled Finding Register through the `Historical Source IDs` column rather than duplicated as separate live findings.

## Preservation approach

- Dependency matrices: historical non-conflicting rows are incorporated into the v1.3 canonical matrix.
- API dependency and authority matrices: historical dependency/authority relationships remain represented; current v1.3 formulations are canonical where wording was corrected.
- Shared resource/configuration matrix: historical configuration relationships remain represented.
- Legacy reconciliation: historical compatibility/provenance entries remain represented.
- Controlled findings: continuing findings are represented under current v1.3 IDs with historical source IDs.
- Deep-rescan/provenance evidence: historical scan/provenance records are consolidated into the single v1.3 JSON artifacts.
- SHA/artifact manifests: current v1.3 package has its own canonical manifest; historical provenance is represented in the consolidated provenance record.

## Final rule

No prior v1.1/v1.2 artifact is required to be shipped as a duplicate. The test is **content preservation**, not filename preservation.
